#!/bin/bash
# FleetFlex Multi-Service Logistics Platform Installation Script
# Usage: curl -fsSL https://raw.githubusercontent.com/yourusername/fleetflex/main/install.sh | bash

set -e

echo "🚀 FleetFlex Platform Installation Started"
echo "Multi-Service Logistics Platform"
echo "=================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo -e "${RED}This script should not be run as root${NC}"
   exit 1
fi

# Check system requirements
echo -e "${YELLOW}Checking system requirements...${NC}"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}Node.js is not installed. Please install Node.js 18+${NC}"
    echo "Install Node.js: https://nodejs.org/"
    exit 1
fi

# Check MongoDB
if ! command -v mongod &> /dev/null; then
    echo -e "${YELLOW}Installing MongoDB...${NC}"
    # Ubuntu/Debian
    if command -v apt &> /dev/null; then
        sudo apt update
        sudo apt install -y mongodb
    # CentOS/RHEL
    elif command -v yum &> /dev/null; then
        sudo yum install -y mongodb-org
    # macOS
    elif command -v brew &> /dev/null; then
        brew install mongodb-community
    else
        echo -e "${RED}Please install MongoDB manually${NC}"
        exit 1
    fi
fi

# Check Redis
if ! command -v redis-server &> /dev/null; then
    echo -e "${YELLOW}Installing Redis...${NC}"
    # Ubuntu/Debian
    if command -v apt &> /dev/null; then
        sudo apt install -y redis-server
    # CentOS/RHEL
    elif command -v yum &> /dev/null; then
        sudo yum install -y redis
    # macOS
    elif command -v brew &> /dev/null; then
        brew install redis
    else
        echo -e "${RED}Please install Redis manually${NC}"
        exit 1
    fi
fi

# Create project directory
PROJECT_DIR="fleetflex-platform"
if [ -d "$PROJECT_DIR" ]; then
    echo -e "${YELLOW}Directory $PROJECT_DIR already exists. Updating...${NC}"
    cd $PROJECT_DIR
else
    echo -e "${GREEN}Creating project directory...${NC}"
    mkdir -p $PROJECT_DIR
    cd $PROJECT_DIR
fi

# Install backend dependencies
echo -e "${GREEN}Installing backend dependencies...${NC}"
cd backend
npm install

# Install frontend dependencies
echo -e "${GREEN}Installing frontend dependencies...${NC}"
cd ../frontend
npm install

# Create .env files
echo -e "${GREEN}Creating environment files...${NC}"
cd ../backend

if [ ! -f .env ]; then
    cat > .env << EOF
# Server Configuration
NODE_ENV=development
PORT=5000
HOST=localhost

# Database Configuration
MONGODB_URI=mongodb://localhost:27017/fleetflex
REDIS_URL=redis://localhost:6379

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_EXPIRES_IN=7d

# Stripe Configuration
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here

# Google Maps API
GOOGLE_MAPS_API_KEY=your-google-maps-api-key

# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password

# Admin Configuration
ADMIN_EMAIL=admin@fleetflex.app
ADMIN_PASSWORD=Bigship247$$
EOF
    echo -e "${GREEN}Created backend .env file${NC}"
fi

# Setup database
echo -e "${GREEN}Setting up database...${NC}"
cd ../backend
node scripts/setup-database.js

# Start services
echo -e "${GREEN}Starting services...${NC}"

# Start MongoDB
if command -v systemctl &> /dev/null; then
    sudo systemctl start mongod
    sudo systemctl start redis
elif command -v service &> /dev/null; then
    sudo service mongod start
    sudo service redis start
fi

# Start backend in background
echo -e "${GREEN}Starting backend server...${NC}"
cd backend
npm start &

# Wait for backend to start
sleep 5

# Start frontend
echo -e "${GREEN}Starting frontend development server...${NC}"
cd ../frontend
npm run dev &

echo -e "${GREEN}✅ Installation Complete!${NC}"
echo ""
echo "🎯 Access Your Platform:"
echo "Frontend: http://localhost:5173"
echo "Backend: http://localhost:5000"
echo ""
echo "🔑 Admin Login:"
echo "Email: admin@fleetflex.app"
echo "Password: Bigship247$$"
echo ""
echo "📱 Services Available:"
echo "- Food Delivery 🍕"
echo "- Rideshare 🚗"
echo "- Package Shipping 📦"
echo "- Moving Services 🏠"
echo "- Freight Transport 🚛"
echo ""
echo "🚀 Your platform is ready to compete with Uber, DoorDash, and industry leaders!"