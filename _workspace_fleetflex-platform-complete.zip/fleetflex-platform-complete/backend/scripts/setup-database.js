const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const ServiceProvider = require('../models/ServiceProvider');

const seedDatabase = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/fleetflex');

    // Create admin user
    const adminExists = await User.findOne({ email: 'admin@fleetflex.app' });
    if (!adminExists) {
      const admin = new User({
        email: 'admin@fleetflex.app',
        password: 'Bigship247$$',
        firstName: 'Administrator',
        lastName: 'FleetFlex',
        phone: '+1-555-ADMIN',
        roles: ['admin', 'customer'],
        isActive: true,
        isVerified: true
      });
      
      await admin.save();
      console.log('✅ Admin user created: admin@fleetflex.app / Bigship247$$');
    }

    // Create demo users
    const demoUsers = [
      {
        email: 'customer@demo.com',
        password: 'demo123',
        firstName: 'Demo',
        lastName: 'Customer',
        roles: ['customer']
      },
      {
        email: 'driver@demo.com',
        password: 'demo123',
        firstName: 'Demo',
        lastName: 'Driver',
        roles: ['driver']
      }
    ];

    for (const userData of demoUsers) {
      const exists = await User.findOne({ email: userData.email });
      if (!exists) {
        const user = new User(userData);
        await user.save();
        console.log(`✅ Demo user created: ${userData.email}`);
      }
    }

    console.log('✅ Database seeding complete!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Database seeding error:', error);
    process.exit(1);
  }
};

module.exports = seedDatabase;

// Run if called directly
if (require.main === module) {
  seedDatabase();
}