const express = require('express');
const MovingJob = require('../models/MovingJob');
const MovingEquipment = require('../models/MovingEquipment');
const { auth } = require('../middleware/auth');
const router = express.Router();

// Request moving quote
router.post('/quote-request', auth, async (req, res) => {
  try {
    const {
      jobType,
      origin,
      destination,
      inventory,
      services,
      scheduling
    } = req.body;
    
    const pricing = calculateMovingPricing(jobType, inventory, services);
    
    const job = new MovingJob({
      customerId: req.user._id,
      jobType,
      origin,
      destination,
      inventory,
      services,
      scheduling,
      pricing,
      status: 'quote-requested'
    });
    
    await job.save();
    
    res.status(201).json({
      success: true,
      data: job
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get moving quotes
router.get('/quotes', auth, async (req, res) => {
  try {
    const { jobId } = req.query;
    
    const job = await MovingJob.findById(jobId)
      .populate('quotes.moverId', 'firstName lastName phone');
    
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    if (job.customerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    res.json({
      success: true,
      data: job.quotes
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Book moving job
router.post('/book', auth, async (req, res) => {
  try {
    const { jobId, moverId, quoteId } = req.body;
    
    const job = await MovingJob.findById(jobId);
    
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    if (job.customerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    // Find the selected quote
    const quote = job.quotes.id(quoteId);
    if (!quote) {
      return res.status(404).json({ message: 'Quote not found' });
    }
    
    job.moverIds = [moverId];
    job.status = 'booked';
    await job.save();
    
    res.json({
      success: true,
      data: job
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user's moving jobs
router.get('/jobs', auth, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    
    let query = { customerId: req.user._id };
    if (status) {
      query.status = status;
    }
    
    const jobs = await MovingJob.find(query)
      .populate('moverIds', 'firstName lastName phone')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);
    
    const total = await MovingJob.countDocuments(query);
    
    res.json({
      success: true,
      count: jobs.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: jobs
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get moving job by ID
router.get('/jobs/:id', auth, async (req, res) => {
  try {
    const job = await MovingJob.findById(req.params.id)
      .populate('customerId', 'firstName lastName phone')
      .populate('moverIds', 'firstName lastName phone');
    
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    // Check permissions
    const canView = job.customerId._id.toString() === req.user._id.toString() ||
                   job.moverIds.some(mover => mover._id.toString() === req.user._id.toString());
    
    if (!canView) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    res.json({
      success: true,
      data: job
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update job status
router.put('/jobs/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    
    const job = await MovingJob.findById(req.params.id);
    
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    // Check permissions
    const isCustomer = job.customerId.toString() === req.user._id.toString();
    const isMover = job.moverIds.some(mover => mover.toString() === req.user._id.toString());
    
    if (!isCustomer && !isMover) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    job.status = status;
    await job.save();
    
    res.json({
      success: true,
      data: job
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Mover routes
// Get mover jobs
router.get('/provider/jobs', auth, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    
    let query = { moverIds: { $in: [req.user._id] } };
    if (status) {
      query.status = status;
    }
    
    const jobs = await MovingJob.find(query)
      .populate('customerId', 'firstName lastName phone')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);
    
    const total = await MovingJob.countDocuments(query);
    
    res.json({
      success: true,
      count: jobs.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: jobs
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Submit quote
router.post('/provider/quote', auth, async (req, res) => {
  try {
    const { jobId, amount, message, estimatedStartTime, estimatedDuration } = req.body;
    
    const job = await MovingJob.findById(jobId);
    
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    job.quotes.push({
      moverId: req.user._id,
      amount,
      message,
      estimatedStartTime,
      estimatedDuration
    });
    
    await job.save();
    
    res.json({
      success: true,
      data: job
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Accept job
router.put('/provider/jobs/:id/accept', auth, async (req, res) => {
  try {
    const job = await MovingJob.findById(req.params.id);
    
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    if (job.moverIds.includes(req.user._id)) {
      return res.status(400).json({ message: 'Job already accepted' });
    }
    
    job.moverIds.push(req.user._id);
    job.status = 'booked';
    await job.save();
    
    res.json({
      success: true,
      data: job
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Equipment management
router.get('/equipment', auth, async (req, res) => {
  try {
    const equipment = await MovingEquipment.find({
      moverProviderId: req.user._id,
      isActive: true
    });
    
    res.json({
      success: true,
      count: equipment.length,
      data: equipment
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Add equipment
router.post('/equipment', auth, async (req, res) => {
  try {
    const equipmentData = {
      moverProviderId: req.user._id,
      ...req.body
    };
    
    const equipment = new MovingEquipment(equipmentData);
    await equipment.save();
    
    res.status(201).json({
      success: true,
      data: equipment
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Helper functions
function calculateMovingPricing(jobType, inventory, services) {
  const baseRates = {
    'local-move': 100,
    'long-distance': 200,
    'labor-only': 50,
    'packing': 75,
    'storage': 25
  };
  
  const hourlyRates = {
    'local-move': 50,
    'long-distance': 75,
    'labor-only': 30,
    'packing': 40,
    'storage': 20
  };
  
  // Calculate based on inventory weight and services
  let totalWeight = 0;
  let totalItems = 0;
  
  for (const item of inventory) {
    totalWeight += item.weight || 0;
    totalItems += item.quantity || 0;
  }
  
  const baseRate = baseRates[jobType];
  const hourlyRate = hourlyRates[jobType];
  const materials = services.packing ? totalItems * 5 : 0;
  const travel = totalWeight * 0.1;
  const storage = services.storage ? totalWeight * 0.2 : 0;
  const insurance = totalWeight * 0.05;
  const total = baseRate + hourlyRate + materials + travel + storage + insurance;
  
  return {
    baseRate,
    hourlyRate,
    materials,
    travel,
    storage,
    insurance,
    total
  };
}

module.exports = router;