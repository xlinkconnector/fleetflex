const express = require('express');
const ShippingOrder = require('../models/ShippingOrder');
const { auth } = require('../middleware/auth');
const router = express.Router();

// Get shipping quote
router.post('/quote', async (req, res) => {
  try {
    const { pickup, delivery, packageInfo, serviceType } = req.body;
    
    const distance = calculateDistance(
      pickup.lat, pickup.lng,
      delivery.lat, delivery.lng
    );
    
    const pricing = calculateShippingPricing(packageInfo, distance, serviceType);
    
    res.json({
      success: true,
      data: {
        distance,
        pricing,
        estimatedDelivery: new Date(Date.now() + pricing.estimatedHours * 60 * 60 * 1000)
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create shipping order
router.post('/create', auth, async (req, res) => {
  try {
    const {
      recipientInfo,
      packageInfo,
      pickup,
      delivery,
      serviceType,
      payment
    } = req.body;
    
    const distance = calculateDistance(
      pickup.lat, pickup.lng,
      delivery.lat, delivery.lng
    );
    
    const pricing = calculateShippingPricing(packageInfo, distance, serviceType);
    
    const order = new ShippingOrder({
      senderId: req.user._id,
      recipientInfo,
      packageInfo,
      pickup,
      delivery,
      serviceType,
      distance,
      pricing,
      payment: {
        method: payment.method,
        status: 'pending'
      },
      timeline: [{
        status: 'created',
        timestamp: new Date()
      }]
    });
    
    await order.save();
    
    res.status(201).json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user's shipping orders
router.get('/orders', auth, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    
    let query = { senderId: req.user._id };
    if (status) {
      query.status = status;
    }
    
    const orders = await ShippingOrder.find(query)
      .populate('driverId', 'firstName lastName phone')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);
    
    const total = await ShippingOrder.countDocuments(query);
    
    res.json({
      success: true,
      count: orders.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: orders
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get shipping order by tracking number
router.get('/:trackingNumber', async (req, res) => {
  try {
    const order = await ShippingOrder.findOne({ trackingNumber: req.params.trackingNumber })
      .populate('senderId', 'firstName lastName phone')
      .populate('driverId', 'firstName lastName phone');
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Driver routes
// Get available shipping orders
router.get('/driver/available', auth, async (req, res) => {
  try {
    const { lat, lng, radius = 25 } = req.query;
    
    let query = { status: 'pickup-scheduled', driverId: null };
    
    const orders = await ShippingOrder.find(query)
      .populate('senderId', 'firstName lastName phone')
      .sort({ createdAt: 1 });
    
    // Filter by distance if location provided
    let filteredOrders = orders;
    if (lat && lng) {
      const driverLat = parseFloat(lat);
      const driverLng = parseFloat(lng);
      const radiusKm = parseFloat(radius);
      
      filteredOrders = orders.filter(order => {
        const distance = calculateDistance(
          driverLat, driverLng,
          order.pickup.lat, order.pickup.lng
        );
        return distance <= radiusKm;
      });
    }
    
    res.json({
      success: true,
      count: filteredOrders.length,
      data: filteredOrders
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Accept shipping order
router.post('/driver/accept', auth, async (req, res) => {
  try {
    const { trackingNumber } = req.body;
    
    const order = await ShippingOrder.findOne({ trackingNumber });
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    if (order.driverId) {
      return res.status(400).json({ message: 'Order already accepted' });
    }
    
    order.driverId = req.user._id;
    order.status = 'picked-up';
    order.timeline.push({
      status: 'picked-up',
      timestamp: new Date()
    });
    
    await order.save();
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update pickup complete
router.put('/pickup-complete', auth, async (req, res) => {
  try {
    const { trackingNumber } = req.body;
    
    const order = await ShippingOrder.findOne({ trackingNumber });
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    if (order.driverId?.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    order.status = 'in-transit';
    order.timeline.push({
      status: 'in-transit',
      timestamp: new Date()
    });
    
    await order.save();
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update delivery complete
router.put('/delivery-complete', auth, async (req, res) => {
  try {
    const { trackingNumber, signature } = req.body;
    
    const order = await ShippingOrder.findOne({ trackingNumber });
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    if (order.driverId?.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    order.status = 'delivered';
    order.timeline.push({
      status: 'delivered',
      timestamp: new Date(),
      signature
    });
    
    await order.save();
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Add signature
router.post('/signature', auth, async (req, res) => {
  try {
    const { trackingNumber, signature } = req.body;
    
    const order = await ShippingOrder.findOne({ trackingNumber });
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    order.timeline.push({
      status: 'delivered',
      timestamp: new Date(),
      signature
    });
    
    await order.save();
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Helper functions
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
           Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
           Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function calculateShippingPricing(packageInfo, distance, serviceType) {
  const baseRates = {
    'same-day': 15,
    'next-day': 10,
    'standard': 5,
    'express': 20
  };
  
  const weightRates = {
    'same-day': 0.5,
    'next-day': 0.3,
    'standard': 0.2,
    'express': 0.7
  };
  
  const baseFee = baseRates[serviceType];
  const weightFee = packageInfo.weight * weightRates[serviceType];
  const distanceFee = distance * 0.5;
  const serviceFee = Math.round((baseFee + weightFee + distanceFee) * 0.1 * 100) / 100;
  const insurance = packageInfo.value * 0.01;
  const total = baseFee + weightFee + distanceFee + serviceFee + insurance;
  
  const estimatedHours = {
    'same-day': 4,
    'next-day': 24,
    'standard': 48,
    'express': 2
  };
  
  return {
    baseFee,
    weightFee,
    distanceFee,
    serviceFee,
    insurance,
    total,
    estimatedHours: estimatedHours[serviceType]
  };
}

module.exports = router;