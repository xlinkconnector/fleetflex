const express = require('express');
const FreightJob = require('../models/FreightJob');
const FreightVehicle = require('../models/FreightVehicle');
const { auth } = require('../middleware/auth');
const router = express.Router();

// Post a load
router.post('/post-load', auth, async (req, res) => {
  try {
    const {
      freightType,
      cargo,
      pickup,
      delivery,
      pricing
    } = req.body;
    
    const distance = calculateDistance(
      pickup.lat, pickup.lng,
      delivery.lat, delivery.lng
    );
    
    const estimatedTransitTime = Math.round(distance / 50 * 60); // 50 mph average
    
    const job = new FreightJob({
      shipperId: req.user._id,
      freightType,
      cargo,
      pickup,
      delivery,
      distance,
      estimatedTransitTime,
      pricing,
      status: 'posted'
    });
    
    await job.save();
    
    res.status(201).json({
      success: true,
      data: job
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all loads
router.get('/loads', async (req, res) => {
  try {
    const { status, freightType, origin, destination, page = 1, limit = 10 } = req.query;
    
    let query = {};
    
    if (status) {
      query.status = status;
    }
    
    if (freightType) {
      query.freightType = freightType;
    }
    
    const loads = await FreightJob.find(query)
      .populate('shipperId', 'firstName lastName company')
      .populate('carrierId', 'firstName lastName company')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);
    
    const total = await FreightJob.countDocuments(query);
    
    res.json({
      success: true,
      count: loads.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: loads
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get load by ID
router.get('/loads/:id', async (req, res) => {
  try {
    const load = await FreightJob.findById(req.params.id)
      .populate('shipperId', 'firstName lastName phone company')
      .populate('carrierId', 'firstName lastName phone company')
      .populate('bids.carrierId', 'firstName lastName phone company');
    
    if (!load) {
      return res.status(404).json({ message: 'Load not found' });
    }
    
    res.json({
      success: true,
      data: load
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Submit bid
router.post('/bid', auth, async (req, res) => {
  try {
    const { loadId, amount, estimatedPickup, estimatedDelivery, equipment, message } = req.body;
    
    const load = await FreightJob.findById(loadId);
    
    if (!load) {
      return res.status(404).json({ message: 'Load not found' });
    }
    
    if (load.status !== 'posted' && load.status !== 'bid') {
      return res.status(400).json({ message: 'Load is no longer accepting bids' });
    }
    
    load.bids.push({
      carrierId: req.user._id,
      amount,
      estimatedPickup,
      estimatedDelivery,
      equipment,
      message
    });
    
    await load.save();
    
    res.json({
      success: true,
      data: load
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user's loads
router.get('/my-loads', auth, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    
    let query = { shipperId: req.user._id };
    if (status) {
      query.status = status;
    }
    
    const loads = await FreightJob.find(query)
      .populate('carrierId', 'firstName lastName phone company')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);
    
    const total = await FreightJob.countDocuments(query);
    
    res.json({
      success: true,
      count: loads.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: loads
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user's bids
router.get('/my-bids', auth, async (req, res) => {
  try {
    const loads = await FreightJob.find({
      'bids.carrierId': req.user._id
    })
    .populate('shipperId', 'firstName lastName phone company')
    .sort({ createdAt: -1 });
    
    res.json({
      success: true,
      count: loads.length,
      data: loads
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Carrier routes
// Get available loads
router.get('/carrier/available-loads', auth, async (req, res) => {
  try {
    const { lat, lng, radius = 100 } = req.query;
    
    let query = { status: { $in: ['posted', 'bid'] } };
    
    const loads = await FreightJob.find(query)
      .populate('shipperId', 'firstName lastName phone company')
      .sort({ createdAt: 1 });
    
    // Filter by distance if location provided
    let filteredLoads = loads;
    if (lat && lng) {
      const carrierLat = parseFloat(lat);
      const carrierLng = parseFloat(lng);
      const radiusKm = parseFloat(radius);
      
      filteredLoads = loads.filter(load => {
        const distance = calculateDistance(
          carrierLat, carrierLng,
          load.pickup.lat, load.pickup.lng
        );
        return distance <= radiusKm;
      });
    }
    
    res.json({
      success: true,
      count: filteredLoads.length,
      data: filteredLoads
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update carrier location
router.put('/carrier/location', auth, async (req, res) => {
  try {
    const { lat, lng } = req.body;
    
    // Update carrier's current location
    // In a real app, this would be stored in Redis or a separate collection
    
    res.json({
      success: true,
      message: 'Location updated'
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Vehicle management
router.post('/carrier/vehicle', auth, async (req, res) => {
  try {
    const vehicleData = {
      carrierId: req.user._id,
      ...req.body
    };
    
    const vehicle = new FreightVehicle(vehicleData);
    await vehicle.save();
    
    res.status(201).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update vehicle
router.put('/carrier/vehicle/:id', auth, async (req, res) => {
  try {
    const vehicle = await FreightVehicle.findOneAndUpdate(
      { _id: req.params.id, carrierId: req.user._id },
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }
    
    res.json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Helper functions
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
           Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
           Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

module.exports = router;