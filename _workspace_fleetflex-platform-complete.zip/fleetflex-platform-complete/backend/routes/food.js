const express = require('express');
const Restaurant = require('../models/Restaurant');
const MenuItem = require('../models/MenuItem');
const FoodOrder = require('../models/FoodOrder');
const User = require('../models/User');
const { auth, authorize } = require('../middleware/auth');
const router = express.Router();

// Get all restaurants
router.get('/restaurants', async (req, res) => {
  try {
    const { lat, lng, radius = 5, cuisine, search } = req.query;
    
    let query = { 'settings.acceptingOrders': true };
    
    // Add cuisine filter if provided
    if (cuisine) {
      query.cuisine = { $in: [cuisine] };
    }
    
    // Add search filter if provided
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { cuisine: { $regex: search, $options: 'i' } }
      ];
    }
    
    let restaurants = await Restaurant.find(query);
    
    // Filter by distance if location provided
    if (lat && lng) {
      const userLat = parseFloat(lat);
      const userLng = parseFloat(lng);
      const radiusKm = parseFloat(radius);
      
      restaurants = restaurants.filter(restaurant => {
        const distance = calculateDistance(
          userLat, userLng,
          restaurant.address.lat, restaurant.address.lng
        );
        return distance <= radiusKm;
      });
    }
    
    res.json({
      success: true,
      count: restaurants.length,
      data: restaurants
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get restaurant by ID
router.get('/restaurants/:id', async (req, res) => {
  try {
    const restaurant = await Restaurant.findById(req.params.id);
    
    if (!restaurant) {
      return res.status(404).json({ message: 'Restaurant not found' });
    }
    
    res.json({
      success: true,
      data: restaurant
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get restaurant menu
router.get('/restaurants/:id/menu', async (req, res) => {
  try {
    const menuItems = await MenuItem.find({ 
      restaurantId: req.params.id,
      isAvailable: true 
    });
    
    res.json({
      success: true,
      count: menuItems.length,
      data: menuItems
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create food order
router.post('/orders', auth, async (req, res) => {
  try {
    const {
      restaurantId,
      items,
      delivery,
      payment,
      tip = 0
    } = req.body;
    
    // Calculate pricing
    const menuItems = await MenuItem.find({ 
      _id: { $in: items.map(item => item.menuItemId) } 
    });
    
    let subtotal = 0;
    const orderItems = [];
    
    for (const item of items) {
      const menuItem = menuItems.find(mi => mi._id.toString() === item.menuItemId);
      if (!menuItem) {
        return res.status(404).json({ message: `Menu item ${item.menuItemId} not found` });
      }
      
      let itemTotal = menuItem.price * item.quantity;
      
      // Add modifier costs
      if (item.modifiers && item.modifiers.length > 0) {
        for (const modifier of item.modifiers) {
          itemTotal += modifier.additionalCost;
        }
      }
      
      subtotal += itemTotal;
      
      orderItems.push({
        menuItemId: menuItem._id,
        name: menuItem.name,
        price: menuItem.price,
        quantity: item.quantity,
        modifiers: item.modifiers || [],
        itemTotal
      });
    }
    
    // Get restaurant for pricing
    const restaurant = await Restaurant.findById(restaurantId);
    if (!restaurant) {
      return res.status(404).json({ message: 'Restaurant not found' });
    }
    
    const deliveryFee = restaurant.settings.deliveryFee;
    const serviceFee = Math.round(subtotal * 0.1 * 100) / 100;
    const tax = Math.round(subtotal * 0.08 * 100) / 100;
    const total = subtotal + deliveryFee + serviceFee + tax + tip;
    
    const order = new FoodOrder({
      customerId: req.user._id,
      restaurantId,
      items: orderItems,
      pricing: {
        subtotal,
        deliveryFee,
        serviceFee,
        tax,
        tip,
        total
      },
      delivery,
      payment: {
        method: payment.method,
        status: 'pending'
      },
      tracking: [{
        status: 'pending',
        timestamp: new Date()
      }]
    });
    
    await order.save();
    
    // Populate order with restaurant and items details
    await order.populate([
      { path: 'restaurantId', select: 'name address' },
      { path: 'items.menuItemId', select: 'name image' }
    ]);
    
    res.status(201).json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user's food orders
router.get('/orders', auth, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    
    let query = { customerId: req.user._id };
    if (status) {
      query.status = status;
    }
    
    const orders = await FoodOrder.find(query)
      .populate('restaurantId', 'name address')
      .populate('driverId', 'firstName lastName')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);
    
    const total = await FoodOrder.countDocuments(query);
    
    res.json({
      success: true,
      count: orders.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: orders
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get order by ID
router.get('/orders/:id', auth, async (req, res) => {
  try {
    const order = await FoodOrder.findById(req.params.id)
      .populate('restaurantId', 'name address contact')
      .populate('customerId', 'firstName lastName phone')
      .populate('driverId', 'firstName lastName phone')
      .populate('items.menuItemId');
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    // Check if user owns this order or is the restaurant owner/driver
    const canView = order.customerId._id.toString() === req.user._id.toString() ||
                   order.restaurantId.serviceProviderId?.toString() === req.user._id.toString() ||
                   order.driverId?._id.toString() === req.user._id.toString();
    
    if (!canView) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update order status
router.put('/orders/:id/status', auth, async (req, res) => {
  try {
    const { status, notes } = req.body;
    
    const order = await FoodOrder.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    // Check permissions based on user role
    const isCustomer = order.customerId.toString() === req.user._id.toString();
    const isRestaurantOwner = order.restaurantId.serviceProviderId?.toString() === req.user._id.toString();
    const isDriver = order.driverId?.toString() === req.user._id.toString();
    
    if (!isCustomer && !isRestaurantOwner && !isDriver) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    order.status = status;
    order.tracking.push({
      status,
      timestamp: new Date(),
      notes
    });
    
    await order.save();
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Search restaurants
router.get('/restaurants/search', async (req, res) => {
  try {
    const { query, lat, lng, radius = 5 } = req.query;
    
    if (!query) {
      return res.status(400).json({ message: 'Search query is required' });
    }
    
    let searchQuery = {
      'settings.acceptingOrders': true,
      $or: [
        { name: { $regex: query, $options: 'i' } },
        { description: { $regex: query, $options: 'i' } },
        { cuisine: { $regex: query, $options: 'i' } }
      ]
    };
    
    let restaurants = await Restaurant.find(searchQuery);
    
    // Filter by distance if location provided
    if (lat && lng) {
      const userLat = parseFloat(lat);
      const userLng = parseFloat(lng);
      const radiusKm = parseFloat(radius);
      
      restaurants = restaurants.filter(restaurant => {
        const distance = calculateDistance(
          userLat, userLng,
          restaurant.address.lat, restaurant.address.lng
        );
        return distance <= radiusKm;
      });
    }
    
    res.json({
      success: true,
      count: restaurants.length,
      data: restaurants
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get food categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await Restaurant.distinct('cuisine');
    res.json({
      success: true,
      data: categories
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Helper function to calculate distance between two points
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
           Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
           Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

module.exports = router;