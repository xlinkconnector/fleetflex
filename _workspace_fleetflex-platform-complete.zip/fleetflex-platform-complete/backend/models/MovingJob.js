const mongoose = require('mongoose');

const movingJobSchema = new mongoose.Schema({
  jobNumber: {
    type: String,
    required: true,
    unique: true
  },
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  moverIds: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  jobType: {
    type: String,
    enum: ['local-move', 'long-distance', 'labor-only', 'packing', 'storage'],
    required: true
  },
  origin: {
    address: {
      type: String,
      required: true
    },
    lat: {
      type: Number,
      required: true
    },
    lng: {
      type: Number,
      required: true
    },
    propertyType: {
      type: String,
      enum: ['apartment', 'house', 'office', 'storage'],
      required: true
    },
    floor: {
      type: Number,
      default: 1
    },
    elevator: {
      type: Boolean,
      default: false
    },
    parkingDistance: {
      type: Number,
      default: 0
    }
  },
  destination: {
    address: {
      type: String,
      required: true
    },
    lat: {
      type: Number,
      required: true
    },
    lng: {
      type: Number,
      required: true
    },
    propertyType: {
      type: String,
      enum: ['apartment', 'house', 'office', 'storage'],
      required: true
    },
    floor: {
      type: Number,
      default: 1
    },
    elevator: {
      type: Boolean,
      default: false
    },
    parkingDistance: {
      type: Number,
      default: 0
    }
  },
  inventory: [{
    category: {
      type: String,
      enum: ['furniture', 'boxes', 'appliances', 'electronics', 'miscellaneous']
    },
    item: {
      type: String,
      required: true
    },
    quantity: {
      type: Number,
      required: true
    },
    weight: Number,
    dimensions: String,
    special: {
      type: Boolean,
      default: false
    }
  }],
  services: {
    packing: {
      type: Boolean,
      default: false
    },
    unpacking: {
      type: Boolean,
      default: false
    },
    disassembly: {
      type: Boolean,
      default: false
    },
    reassembly: {
      type: Boolean,
      default: false
    },
    cleaning: {
      type: Boolean,
      default: false
    },
    storage: {
      type: Boolean,
      default: false
    }
  },
  scheduling: {
    preferredDate: {
      type: Date,
      required: true
    },
    alternateDate: Date,
    timeWindow: {
      start: {
        type: String,
        required: true
      },
      end: {
        type: String,
        required: true
      }
    },
    estimatedDuration: {
      type: Number,
      required: true
    }
  },
  pricing: {
    baseRate: {
      type: Number,
      required: true
    },
    hourlyRate: {
      type: Number,
      required: true
    },
    materials: {
      type: Number,
      default: 0
    },
    travel: {
      type: Number,
      default: 0
    },
    storage: {
      type: Number,
      default: 0
    },
    insurance: {
      type: Number,
      default: 0
    },
    total: {
      type: Number,
      required: true
    }
  },
  status: {
    type: String,
    enum: ['quote-requested', 'quoted', 'booked', 'in-progress', 'completed', 'cancelled'],
    default: 'quote-requested'
  },
  quotes: [{
    moverId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    amount: Number,
    message: String,
    estimatedStartTime: Date,
    estimatedDuration: Number,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  payment: {
    method: {
      type: String,
      enum: ['card', 'cash', 'wallet'],
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'pending'
    },
    transactionId: String,
    stripePaymentIntentId: String
  },
  rating: {
    customer: {
      rating: Number,
      review: String
    },
    mover: {
      rating: Number,
      review: String
    }
}, {
  timestamps: true
});

// Generate job number before saving
movingJobSchema.pre('save', function(next) {
  if (this.isNew) {
    this.jobNumber = 'MV' + Date.now().toString().slice(-8) + Math.random().toString(36).substr(2, 4).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('MovingJob', movingJobSchema);