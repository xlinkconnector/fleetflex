#!/bin/bash

# GitHub Upload Script for FleetFlex Platform
# Usage: ./upload-to-github.sh <your-repo-url>

set -e

REPO_URL=${1:-$1}
BRANCH=${2:-main}

echo "🚀 Uploading FleetFlex to GitHub..."

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed. Please install git first."
    exit 1
fi

# Check if repository URL is provided
if [ -z "$REPO_URL" ]; then
    echo "❌ Please provide GitHub repository URL"
    echo "Usage: ./upload-to-github.sh <your-repo-url> [branch]"
    exit 1
fi

# Initialize git if not already initialized
if [ ! -d ".git" ]; then
    git init
    git remote add origin $REPO_URL
fi

# Add all files
git add .

# Create initial commit
git commit -m "🚀 Initial FleetFlex platform upload
- Complete multi-service logistics platform
- 5 service modules: Food, Rides, Shipping, Moving, Freight
- Admin dashboard with login: admin@fleetflex.app / Bigship247$$
- Complete backend and frontend
- Production ready"

# Push to GitHub
git branch -M $BRANCH
git push -u origin $BRANCH

echo "✅ Successfully uploaded to GitHub!"
echo "Repository: $REPO_URL"
echo "Branch: $BRANCH"
echo ""
echo "🎯 Next steps:"
echo "1. Clone the repository: git clone $REPO_URL"
echo "2. Run: ./install.sh for complete installation"