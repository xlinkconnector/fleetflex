import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { DollarSign, Package, Users, Clock, Star, TrendingUp } from 'lucide-react';
import api from '../../services/api';

const ProviderDashboard = () => {
  const { user } = useSelector(state => state.auth);
  const [stats, setStats] = useState({});
  const [activeJobs, setActiveJobs] = useState([]);
  const [earnings, setEarnings] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProviderData();
  }, []);

  const fetchProviderData = async () => {
    try {
      // Fetch provider-specific data based on role
      const providerStats = await Promise.all([
        // Food provider
        user?.roles?.includes('restaurant-owner') && api.get('/food/restaurant/orders'),
        // Driver
        user?.roles?.includes('driver') && api.get('/rides/driver/requests'),
        // Mover
        user?.roles?.includes('mover') && api.get('/moving/provider/jobs'),
        // Freight carrier
        user?.roles?.includes('freight-carrier') && api.get('/freight/carrier/active-jobs')
      ]);

      setStats({
        totalOrders: 45,
        totalEarnings: 2847.50,
        averageRating: 4.8,
        activeJobs: 12
      });

      setLoading(false);
    } catch (error) {
      console.error('Error fetching provider data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const providerStats = [
    {
      title: 'Total Earnings',
      value: '$2,847.50',
      icon: DollarSign,
      color: 'bg-green-500',
      description: 'This month'
    },
    {
      title: 'Completed Jobs',
      value: '156',
      icon: Package,
      color: 'bg-blue-500',
      description: 'All time'
    },
    {
      title: 'Average Rating',
      value: '4.8⭐',
      icon: Star,
      color: 'bg-yellow-500',
      description: 'Based on 234 reviews'
    },
    {
      title: 'Active Jobs',
      value: '12',
      icon: Clock,
      color: 'bg-purple-500',
      description: 'Currently active'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Provider Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage your services and earnings</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {providerStats.map((stat) => (
            <div key={stat.title} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500">{stat.description}</p>
                </div>
                <stat.icon className={`h-8 w-8 ${stat.color} text-white rounded p-1`} />
              </div>
            </div>
          ))}
        </div>

        {/* Service Management */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Active Jobs */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Active Jobs</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">Food Order #1234</p>
                  <p className="text-sm text-gray-600">In Progress</p>
                </div>
                <span className="text-green-600 font-semibold">$47.50</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">Ride Request #5678</p>
                  <p className="text-sm text-gray-600">Accepted</p>
                </div>
                <span className="text-blue-600 font-semibold">$32.00</span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
                Update Availability
              </button>
              <button className="w-full bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700">
                View Earnings Report
              </button>
              <button className="w-full bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700">
                Manage Profile
              </button>
            </div>
          </div>
        </div>

        {/* Service-Specific Sections */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Earnings Chart */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Weekly Earnings</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">This Week</span>
                <span className="font-semibold">$847.50</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Last Week</span>
                <span className="font-semibold">$723.20</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Growth</span>
                <span className="text-green-600 font-semibold">+17%</span>
              </div>
            </div>
          </div>

          {/* Rating Summary */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Performance Metrics</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">On-time Delivery</span>
                <span className="font-semibold">98%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Customer Satisfaction</span>
                <span className="font-semibold">4.8/5</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Repeat Customers</span>
                <span className="font-semibold">73%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProviderDashboard;