import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import FoodDelivery from './pages/Customer/FoodDelivery';
import Rideshare from './pages/Customer/Rideshare';
import Shipping from './pages/Customer/Shipping';
import Moving from './pages/Customer/Moving';
import Freight from './pages/Customer/Freight';
import CustomerDashboard from './pages/Dashboard/CustomerDashboard';
import ProviderDashboard from './pages/Dashboard/ProviderDashboard';
import AdminDashboard from './pages/Dashboard/AdminDashboard';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <>
      <Toaster position="top-right" />
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/food" element={<FoodDelivery />} />
          <Route path="/rides" element={<Rideshare />} />
          <Route path="/shipping" element={<Shipping />} />
          <Route path="/moving" element={<Moving />} />
          <Route path="/freight" element={<Freight />} />
          
          <Route path="/dashboard" element={<ProtectedRoute />}>
            <Route path="customer" element={<CustomerDashboard />} />
            <Route path="provider" element={<ProviderDashboard />} />
            <Route path="admin" element={<AdminDashboard />} />
          </Route>
        </Route>
      </Routes>
    </>
  );
}

export default App;