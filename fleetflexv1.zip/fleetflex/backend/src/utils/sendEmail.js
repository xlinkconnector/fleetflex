const nodemailer = require('nodemailer');
const logger = require('./logger');

// Create transporter
const transporter = nodemailer.createTransporter({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Verify transporter
transporter.verify((error, success) => {
  if (error) {
    logger.error('SMTP verification error:', error);
  } else {
    logger.info('SMTP server is ready to take messages');
  }
});

const sendEmail = async (options) => {
  try {
    // Base email template
    const baseTemplate = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${options.subject}</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 10px 10px 0 0;
          }
          .content {
            padding: 30px;
            background: #f9f9f9;
            border-radius: 0 0 10px 10px;
          }
          .button {
            display: inline-block;
            padding: 12px 30px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px 0;
          }
          .footer {
            text-align: center;
            margin-top: 30px;
            color: #666;
            font-size: 14px;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>FleetFlex</h1>
        </div>
        <div class="content">
          ${getTemplateContent(options.template, options.data)}
          <div class="footer">
            <p>Thank you for choosing FleetFlex!</p>
            <p>If you didn't request this, please ignore this email.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"FleetFlex" <${process.env.FROM_EMAIL}>`,
      to: options.email,
      subject: options.subject,
      html: baseTemplate,
    };

    const info = await transporter.sendMail(mailOptions);
    logger.info(`Email sent: ${info.messageId}`);
    return info;
  } catch (error) {
    logger.error('Email sending error:', error);
    throw error;
  }
};

const getTemplateContent = (template, data) => {
  switch (template) {
    case 'email-verification':
      return `
        <h2>Welcome to FleetFlex!</h2>
        <p>Hi ${data.firstName},</p>
        <p>Thank you for registering with FleetFlex. To complete your registration, please verify your email address by clicking the button below:</p>
        <div style="text-align: center;">
          <a href="${data.verifyUrl}" class="button" style="color: white;">Verify Email Address</a>
        </div>
        <p>If the button doesn't work, copy and paste this link into your browser:</p>
        <p>${data.verifyUrl}</p>
        <p>This link will expire in 24 hours.</p>
      `;

    case 'password-reset':
      return `
        <h2>Password Reset Request</h2>
        <p>Hi ${data.firstName},</p>
        <p>We received a request to reset your FleetFlex password. Click the button below to reset it:</p>
        <div style="text-align: center;">
          <a href="${data.resetUrl}" class="button" style="color: white;">Reset Password</a>
        </div>
        <p>If the button doesn't work, copy and paste this link into your browser:</p>
        <p>${data.resetUrl}</p>
        <p>This link will expire in 10 minutes.</p>
        <p>If you didn't request this, please ignore this email. Your password will remain unchanged.</p>
      `;

    case 'order-confirmation':
      return `
        <h2>Order Confirmation</h2>
        <p>Hi ${data.firstName},</p>
        <p>Thank you for your order! Your order ${data.orderNumber} has been confirmed.</p>
        <h3>Order Details:</h3>
        <p><strong>Service:</strong> ${data.serviceType}</p>
        <p><strong>Total:</strong> $${data.total}</p>
        <p><strong>Estimated Time:</strong> ${data.estimatedTime} minutes</p>
        <p>You can track your order at: ${data.trackingUrl}</p>
      `;

    case 'order-delivered':
      return `
        <h2>Order Delivered</h2>
        <p>Hi ${data.firstName},</p>
        <p>Great news! Your order ${data.orderNumber} has been delivered successfully.</p>
        <p>We hope you enjoyed your experience with FleetFlex. We'd love to hear your feedback!</p>
        <div style="text-align: center;">
          <a href="${data.reviewUrl}" class="button" style="color: white;">Leave Feedback</a>
        </div>
      `;

    default:
      return `<p>${data.content || 'Thank you for using FleetFlex!'}</p>`;
  }
};

module.exports = sendEmail;