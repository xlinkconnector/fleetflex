const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  orderNumber: {
    type: String,
    unique: true,
    required: true,
  },
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true,
  },
  serviceType: {
    type: String,
    enum: ['food', 'ride', 'shipping', 'moving', 'freight'],
    required: true,
  },
  // Food delivery specific
  restaurant: {
    type: mongoose.Schema.ObjectId,
    ref: 'Restaurant',
  },
  items: [{
    itemId: mongoose.Schema.ObjectId,
    name: String,
    quantity: Number,
    price: Number,
    options: [{
      name: String,
      choice: String,
      price: Number,
    }],
    specialInstructions: String,
  }],
  // Ride specific
  driver: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
  },
  pickupLocation: {
    address: String,
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  dropoffLocation: {
    address: String,
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  rideType: {
    type: String,
    enum: ['economy', 'comfort', 'premium', 'xl'],
  },
  // Shipping specific
  packageDetails: {
    weight: Number,
    dimensions: {
      length: Number,
      width: Number,
      height: Number,
    },
    description: String,
    value: Number,
    fragile: Boolean,
  },
  // Moving specific
  movingDetails: {
    propertySize: String,
    inventory: [{
      item: String,
      quantity: Number,
      fragile: Boolean,
    }],
    services: [String],
    specialRequirements: String,
  },
  // Freight specific
  freightDetails: {
    loadType: String,
    weight: Number,
    volume: Number,
    pickupDate: Date,
    deliveryDate: Date,
  },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'in_progress', 'completed', 'cancelled', 'refunded'],
    default: 'pending',
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed', 'refunded'],
    default: 'pending',
  },
  paymentMethod: {
    type: String,
    enum: ['card', 'paypal', 'cash', 'wallet'],
  },
  paymentIntent: String,
  subtotal: {
    type: Number,
    required: true,
  },
  tax: {
    type: Number,
    default: 0,
  },
  serviceFee: {
    type: Number,
    default: 0,
  },
  deliveryFee: {
    type: Number,
    default: 0,
  },
  discount: {
    type: Number,
    default: 0,
  },
  total: {
    type: Number,
    required: true,
  },
  estimatedTime: Number,
  actualTime: Number,
  tracking: [{
    status: String,
    timestamp: {
      type: Date,
      default: Date.now,
    },
    location: {
      lat: Number,
      lng: Number,
    },
    description: String,
  }],
  notes: String,
  rating: {
    type: Number,
    min: 1,
    max: 5,
  },
  review: String,
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Indexes
orderSchema.index({ orderNumber: 1 });
orderSchema.index({ user: 1 });
orderSchema.index({ restaurant: 1 });
orderSchema.index({ driver: 1 });
orderSchema.index({ status: 1 });
orderSchema.index({ createdAt: -1 });
orderSchema.index({ 'pickupLocation.coordinates': '2dsphere' });
orderSchema.index({ 'dropoffLocation.coordinates': '2dsphere' });

// Generate order number
orderSchema.pre('save', async function(next) {
  if (!this.isNew) return next();
  
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  
  const count = await this.constructor.countDocuments();
  const sequence = String(count + 1).padStart(6, '0');
  
  this.orderNumber = `FF${year}${month}${day}${sequence}`;
  next();
});

// Update updatedAt on save
orderSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Order', orderSchema);