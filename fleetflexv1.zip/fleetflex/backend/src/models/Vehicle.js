const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema({
  driver: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true,
  },
  type: {
    type: String,
    enum: ['car', 'bike', 'truck', 'van', 'bus', 'motorcycle'],
    required: true,
  },
  make: {
    type: String,
    required: true,
  },
  model: {
    type: String,
    required: true,
  },
  year: {
    type: Number,
    required: true,
  },
  color: {
    type: String,
    required: true,
  },
  licensePlate: {
    type: String,
    required: true,
    unique: true,
  },
  images: [{
    type: String,
    required: true,
  }],
  capacity: {
    passengers: Number,
    weight: Number, // in kg
    volume: Number, // in cubic meters
  },
  features: [{
    type: String,
  }],
  insurance: {
    provider: String,
    policyNumber: String,
    expiry: Date,
    image: String,
  },
  registration: {
    number: String,
    expiry: Date,
    image: String,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  rating: {
    type: Number,
    default: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Indexes
vehicleSchema.index({ driver: 1 });
vehicleSchema.index({ licensePlate: 1 });
vehicleSchema.index({ type: 1 });
vehicleSchema.index({ isActive: 1 });

// Update updatedAt on save
vehicleSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Vehicle', vehicleSchema);