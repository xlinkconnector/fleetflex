#!/bin/bash

# FleetFlex Multi-Service Logistics Platform Installation Script
# This script will install and configure the entire platform

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   error "This script should not be run as root for security reasons"
   exit 1
fi

# Check system requirements
check_requirements() {
    log "Checking system requirements..."
    
    # Check Node.js
    if ! command -v node &> /dev/null; then
        error "Node.js is not installed. Please install Node.js 16+"
        exit 1
    fi
    
    # Check npm
    if ! command -v npm &> /dev/null; then
        error "npm is not installed. Please install npm"
        exit 1
    fi
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        warning "Docker is not installed. Installing Docker..."
        curl -fsSL https://get.docker.com -o get-docker.sh
        sh get-docker.sh
        sudo usermod -aG docker $USER
    fi
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        warning "Docker Compose is not installed. Installing Docker Compose..."
        sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        sudo chmod +x /usr/local/bin/docker-compose
    fi
    
    log "System requirements check completed"
}

# Install dependencies
install_dependencies() {
    log "Installing dependencies..."
    
    # Backend dependencies
    log "Installing backend dependencies..."
    cd backend
    npm install
    
    # Frontend dependencies
    log "Installing frontend dependencies..."
    cd ../frontend
    npm install
    
    # Admin dependencies
    log "Installing admin dependencies..."
    cd ../admin
    npm install
    
    # Mobile dependencies
    log "Installing mobile dependencies..."
    cd ../mobile
    npm install
    
    cd ..
    log "Dependencies installed successfully"
}

# Setup environment files
setup_environment() {
    log "Setting up environment files..."
    
    # Copy environment files if they don't exist
    if [ ! -f backend/.env ]; then
        cp backend/.env.example backend/.env
        log "Backend .env file created. Please configure it."
    fi
    
    if [ ! -f frontend/.env ]; then
        cp frontend/.env.example frontend/.env
        log "Frontend .env file created. Please configure it."
    fi
    
    if [ ! -f admin/.env ]; then
        cp admin/.env.example admin/.env
        log "Admin .env file created. Please configure it."
    fi
    
    if [ ! -f mobile/.env ]; then
        cp mobile/.env.example mobile/.env
        log "Mobile .env file created. Please configure it."
    fi
}

# Setup database
setup_database() {
    log "Setting up database..."
    
    # Start MongoDB
    docker-compose up -d mongodb
    
    # Wait for MongoDB to be ready
    log "Waiting for MongoDB to be ready..."
    sleep 10
    
    # Run database migrations
    log "Running database migrations..."
    cd backend
    npm run migrate
    
    # Seed database with sample data
    log "Seeding database with sample data..."
    npm run seed
    
    cd ..
    log "Database setup completed"
}

# Build applications
build_applications() {
    log "Building applications..."
    
    # Build backend
    log "Building backend..."
    cd backend
    npm run build
    
    # Build frontend
    log "Building frontend..."
    cd ../frontend
    npm run build
    
    # Build admin
    log "Building admin..."
    cd ../admin
    npm run build
    
    cd ..
    log "Applications built successfully"
}

# Setup SSL certificates
setup_ssl() {
    log "Setting up SSL certificates..."
    
    # Create SSL directory
    mkdir -p nginx/ssl
    
    # Generate self-signed certificates for development
    if [ ! -f nginx/ssl/server.crt ]; then
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout nginx/ssl/server.key \
            -out nginx/ssl/server.crt \
            -subj "/C=US/ST=State/L=City/O=FleetFlex/CN=localhost"
        
        log "SSL certificates generated for development"
    fi
}

# Setup monitoring
setup_monitoring() {
    log "Setting up monitoring..."
    
    # Create log directories
    mkdir -p logs/backend
    mkdir -p logs/nginx
    
    # Setup log rotation
    sudo logrotate -f /etc/logrotate.conf
    
    log "Monitoring setup completed"
}

# Start services
start_services() {
    log "Starting services..."
    
    # Start all services with Docker Compose
    docker-compose up -d
    
    # Wait for services to be ready
    log "Waiting for services to be ready..."
    sleep 30
    
    # Check service health
    log "Checking service health..."
    
    # Check backend health
    if curl -f http://localhost:5000/health > /dev/null 2>&1; then
        log "Backend service is healthy"
    else
        error "Backend service is not responding"
    fi
    
    # Check frontend
    if curl -f http://localhost:3000 > /dev/null 2>&1; then
        log "Frontend service is healthy"
    else
        error "Frontend service is not responding"
    fi
    
    # Check admin
    if curl -f http://localhost:3001 > /dev/null 2>&1; then
        log "Admin service is healthy"
    else
        error "Admin service is not responding"
    fi
    
    log "All services started successfully"
}

# Create systemd services
create_systemd_services() {
    log "Creating systemd services..."
    
    # Create systemd service file for FleetFlex
    sudo tee /etc/systemd/system/fleetflex.service > /dev/null <<EOF
[Unit]
Description=FleetFlex Multi-Service Platform
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=$(pwd)
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down

[Install]
WantedBy=multi-user.target
EOF
    
    sudo systemctl daemon-reload
    sudo systemctl enable fleetflex.service
    
    log "Systemd services created"
}

# Main installation function
main() {
    log "Starting FleetFlex installation..."
    
    check_requirements
    
    # Update system packages
    log "Updating system packages..."
    sudo apt update && sudo apt upgrade -y
    
    # Install required packages
    log "Installing required packages..."
    sudo apt install -y curl wget git nginx nodejs npm docker.io docker-compose
    
    install_dependencies
    setup_environment
    setup_ssl
    setup_monitoring
    
    # Build and start services
    build_applications
    setup_database
    start_services
    
    create_systemd_services
    
    log "FleetFlex installation completed successfully!"
    log "Services are now running:"
    log "- Backend API: http://localhost:5000"
    log "- Frontend: http://localhost:3000"
    log "- Admin Dashboard: http://localhost:3001"
    log "- MongoDB: localhost:27017"
    log "- Redis: localhost:6379"
    
    log "To stop services: docker-compose down"
    log "To start services: docker-compose up -d"
    log "To view logs: docker-compose logs -f"
}

# Run installation
main "$@"