import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useQuery } from 'react-query';
import { MapPin, Clock, Shield, DollarSign, Users, Package, Truck, Car } from 'lucide-react';

import HeroSlider from '../components/HeroSlider';
import ServiceCard from '../components/ServiceCard';
import StatsSection from '../components/StatsSection';
import TestimonialCarousel from '../components/TestimonialCarousel';
import DownloadSection from '../components/DownloadSection';
import Footer from '../components/Footer';
import { api } from '../services/api';

const Home: React.FC = () => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const { data: stats } = useQuery('stats', api.stats.getStats);

  const services = [
    {
      id: 'food',
      title: 'Food Delivery',
      description: 'Order from your favorite restaurants and get food delivered to your doorstep',
      icon: Package,
      color: 'bg-red-500',
      features: ['Real-time tracking', 'Multiple cuisines', 'Contactless delivery'],
      link: '/restaurants',
    },
    {
      id: 'rideshare',
      title: 'Rideshare',
      description: 'Get reliable rides to anywhere you need to go with professional drivers',
      icon: Car,
      color: 'bg-blue-500',
      features: ['Safe rides', 'Transparent pricing', '24/7 availability'],
      link: '/services/rideshare',
    },
    {
      id: 'shipping',
      title: 'Shipping',
      description: 'Send packages anywhere with real-time tracking and secure delivery',
      icon: Truck,
      color: 'bg-green-500',
      features: ['Fast delivery', 'Package insurance', 'Real-time tracking'],
      link: '/services/shipping',
    },
    {
      id: 'moving',
      title: 'Moving Services',
      description: 'Professional moving services for homes and businesses',
      icon: Users,
      color: 'bg-purple-500',
      features: ['Professional movers', 'Full-service packing', 'Storage solutions'],
      link: '/services/moving',
    },
    {
      id: 'freight',
      title: 'Freight',
      description: 'Heavy-duty freight services for large shipments and cargo',
      icon: Truck,
      color: 'bg-orange-500',
      features: ['Heavy cargo', 'Cross-country shipping', 'Bulk transport'],
      link: '/services/freight',
    },
  ];

  const testimonials = [
    {
      id: 1,
      name: 'Sarah Johnson',
      role: 'Regular Customer',
      content: 'FleetFlex has completely transformed how I order food. The app is intuitive, delivery is always on time, and the customer service is exceptional.',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
    },
    {
      id: 2,
      name: 'Michael Chen',
      role: 'Business Owner',
      content: 'As a restaurant owner, FleetFlex has helped us reach more customers and increase our revenue. The platform is reliable and the support team is fantastic.',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      role: 'Driver',
      content: 'Driving for FleetFlex has been a great experience. The app is easy to use, the pay is fair, and I love the flexibility to work when I want.',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    },
  ];

  const fadeInUp = {
    initial: { opacity: 0, y: 60 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 },
  };

  const staggerChildren = {
    animate: {
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  if (!mounted) return null;

  return (
    <>
      <Helmet>
        <title>FleetFlex - Multi-Service Logistics Platform</title>
        <meta
          name="description"
          content="FleetFlex provides food delivery, rideshare, shipping, moving, and freight services all in one platform. Get reliable services at your fingertips."
        />
        <meta
          name="keywords"
          content="food delivery, rideshare, shipping, moving, freight, logistics, delivery services"
        />
        <meta property="og:title" content="FleetFlex - Multi-Service Logistics Platform" />
        <meta
          property="og:description"
          content="All your delivery and logistics needs in one platform"
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://fleetflex.com" />
        <meta property="og:image" content="https://fleetflex.com/og-image.jpg" />
      </Helmet>

      <div className="min-h-screen">
        {/* Hero Section */}
        <HeroSlider />

        {/* Services Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                All Your Needs, One Platform
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                From food delivery to freight shipping, FleetFlex connects you with reliable services
                for everything you need.
              </p>
            </motion.div>

            <motion.div
              variants={staggerChildren}
              initial="initial"
              animate="animate"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {services.map((service) => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </motion.div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                How It Works
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Getting started with FleetFlex is simple and straightforward
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {[
                {
                  step: 1,
                  title: 'Sign Up',
                  description: 'Create your account in minutes',
                  icon: Users,
                },
                {
                  step: 2,
                  title: 'Choose Service',
                  description: 'Select from our range of services',
                  icon: Package,
                },
                {
                  step: 3,
                  title: 'Place Order',
                  description: 'Book your service with ease',
                  icon: Clock,
                },
                {
                  step: 4,
                  title: 'Track & Enjoy',
                  description: 'Track in real-time and enjoy',
                  icon: MapPin,
                },
              ].map((item, index) => (
                <motion.div
                  key={item.step}
                  variants={fadeInUp}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                  <div className="mt-4 text-2xl font-bold text-blue-500">
                    {item.step}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <StatsSection stats={stats} />

        {/* Testimonials Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                What Our Customers Say
              </h2>
              <p className="text-xl text-gray-600">
                Join thousands of satisfied customers
              </p>
            </motion.div>

            <TestimonialCarousel testimonials={testimonials} />
          </div>
        </section>

        {/* Download Section */}
        <DownloadSection />

        {/* Footer */}
        <Footer />
      </div>
    </>
  );
};

export default Home;