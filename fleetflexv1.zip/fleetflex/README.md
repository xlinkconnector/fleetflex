# FleetFlex Multi-Service Logistics Platform

FleetFlex is a comprehensive multi-service logistics platform that provides food delivery, rideshare, shipping, moving, and freight services all in one unified platform.

## 🚀 Features

### Services
- **Food Delivery**: Order from restaurants with real-time tracking
- **Rideshare**: Book rides with professional drivers
- **Shipping**: Send packages with insurance and tracking
- **Moving Services**: Professional moving with full-service options
- **Freight**: Heavy-duty cargo and freight shipping

### Platform Components
- **Web Application**: Modern React frontend with PWA support
- **Mobile Apps**: Cross-platform React Native apps (iOS/Android)
- **Admin Dashboard**: Complete management system
- **Driver App**: Dedicated driver application
- **Restaurant Portal**: Restaurant management system

### Key Features
- Real-time tracking and notifications
- Secure payment processing (Stripe integration)
- Multi-language support
- Advanced analytics and reporting
- KYC verification system
- Rating and review system
- Loyalty program
- Referral system
- 24/7 customer support

## 🏗️ Architecture

### Technology Stack

#### Backend
- **Framework**: Node.js with Express.js
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT with refresh tokens
- **Real-time**: Socket.io
- **Caching**: Redis
- **File Storage**: Cloudinary
- **Payment**: Stripe
- **Email**: Nodemailer
- **Queue**: Bull Queue
- **Monitoring**: Winston logging

#### Frontend
- **Framework**: React 18 with TypeScript
- **State Management**: Redux Toolkit
- **Styling**: Tailwind CSS
- **Routing**: React Router v6
- **Charts**: Recharts
- **Maps**: Google Maps
- **Forms**: React Hook Form
- **HTTP**: Axios
- **PWA**: Service workers

#### Mobile
- **Framework**: React Native
- **Navigation**: React Navigation
- **State**: Redux Toolkit
- **Maps**: React Native Maps
- **Payments**: Stripe SDK
- **Notifications**: Firebase

## 📦 Installation

### Prerequisites
- Node.js 16+
- MongoDB 6+
- Redis 7+
- Docker & Docker Compose

### Quick Start

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-org/fleetflex.git
   cd fleetflex
   ```

2. **Run the installation script**
   ```bash
   ./install.sh
   ```

3. **Manual Installation**
   ```bash
   # Install dependencies
   npm run install:all

   # Setup environment variables
   cp backend/.env.example backend/.env
   cp frontend/.env.example frontend/.env
   cp admin/.env.example admin/.env

   # Start services
   docker-compose up -d
   ```

### Environment Variables

#### Backend (.env)
```bash
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/fleetflex
JWT_SECRET=your-jwt-secret
JWT_EXPIRE=30d
STRIPE_SECRET_KEY=your-stripe-secret
CLOUDINARY_URL=your-cloudinary-url
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

#### Frontend (.env)
```bash
REACT_APP_API_URL=http://localhost:5000
REACT_APP_STRIPE_PUBLISHABLE_KEY=your-stripe-publishable-key
REACT_APP_GOOGLE_MAPS_API_KEY=your-google-maps-key
```

## 🚀 Development

### Backend Development
```bash
cd backend
npm run dev
```

### Frontend Development
```bash
cd frontend
npm run dev
```

### Mobile Development
```bash
cd mobile
npm run ios  # For iOS
npm run android  # For Android
```

### Admin Development
```bash
cd admin
npm run dev
```

## 🧪 Testing

### Backend Tests
```bash
cd backend
npm test
npm run test:coverage
```

### Frontend Tests
```bash
cd frontend
npm test
npm run test:coverage
```

### End-to-End Tests
```bash
npm run test:e2e
```

## 📊 Database Schema

### Users
```javascript
{
  email: String,
  password: String,
  firstName: String,
  lastName: String,
  phone: String,
  role: Enum['customer', 'driver', 'restaurant', 'admin'],
  isActive: Boolean,
  isVerified: Boolean,
  profile: {
    avatar: String,
    address: Object,
    preferences: Object
  },
  kyc: {
    status: Enum['pending', 'approved', 'rejected'],
    documents: Array
  }
}
```

### Restaurants
```javascript
{
  owner: ObjectId,
  name: String,
  cuisine: [String],
  address: Object,
  menu: [{
    category: String,
    items: [{
      name: String,
      price: Number,
      image: String
    }]
  }],
  rating: Number,
  isActive: Boolean
}
```

### Orders
```javascript
{
  orderNumber: String,
  user: ObjectId,
  serviceType: Enum['food', 'ride', 'shipping', 'moving', 'freight'],
  status: Enum['pending', 'confirmed', 'in_progress', 'completed', 'cancelled'],
  items: Array,
  total: Number,
  tracking: Array,
  payment: Object
}
```

## 🔧 API Documentation

### Authentication Endpoints
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `POST /api/auth/refresh` - Refresh token
- `POST /api/auth/forgotpassword` - Forgot password
- `PUT /api/auth/resetpassword/:token` - Reset password

### User Endpoints
- `GET /api/users/me` - Get current user
- `PUT /api/users/updatedetails` - Update user details
- `PUT /api/users/updatepassword` - Update password
- `POST /api/users/uploadavatar` - Upload avatar

### Restaurant Endpoints
- `GET /api/restaurants` - Get all restaurants
- `GET /api/restaurants/:id` - Get restaurant by ID
- `POST /api/restaurants` - Create restaurant
- `PUT /api/restaurants/:id` - Update restaurant
- `DELETE /api/restaurants/:id` - Delete restaurant

### Order Endpoints
- `GET /api/orders` - Get user orders
- `POST /api/orders` - Create order
- `GET /api/orders/:id` - Get order by ID
- `PUT /api/orders/:id/status` - Update order status
- `POST /api/orders/:id/cancel` - Cancel order

## 📱 Mobile App Features

### Customer App
- User registration and authentication
- Service selection and booking
- Real-time tracking
- Payment processing
- Order history
- Rating and reviews
- Push notifications
- Offline support

### Driver App
- Driver registration and verification
- Trip requests and acceptance
- Navigation and routing
- Earnings tracking
- Rating system
- Document upload
- Availability toggle

### Restaurant App
- Restaurant registration
- Menu management
- Order management
- Analytics dashboard
- Revenue tracking
- Customer communication

## 🎯 Admin Features

### Dashboard
- Real-time statistics
- User management
- Order management
- Revenue analytics
- Performance metrics
- System health monitoring

### User Management
- User CRUD operations
- KYC verification
- Document review
- Account suspension/reactivation
- Role management

### Content Management
- Restaurant approval
- Menu management
- Category management
- Promotional content
- Static pages

### Financial Management
- Transaction monitoring
- Payout management
- Commission settings
- Refund processing
- Revenue reports

## 🔐 Security Features

- JWT authentication with refresh tokens
- Role-based access control (RBAC)
- Input validation and sanitization
- Rate limiting
- CORS configuration
- Helmet security headers
- MongoDB injection prevention
- XSS protection
- SQL injection prevention
- File upload security
- HTTPS enforcement

## 📈 Performance Optimization

- Database indexing
- Redis caching
- CDN integration
- Image optimization
- Lazy loading
- Code splitting
- Compression
- Minification
- Service worker caching
- Database connection pooling

## 🚨 Monitoring & Logging

### Application Monitoring
- Winston logging with rotation
- Error tracking and alerting
- Performance monitoring
- Health checks
- Uptime monitoring

### Infrastructure Monitoring
- Docker container monitoring
- Database performance monitoring
- Redis monitoring
- Server resource monitoring

## 🔧 Troubleshooting

### Common Issues

#### Database Connection Issues
```bash
# Check MongoDB status
sudo systemctl status mongod

# Restart MongoDB
sudo systemctl restart mongod

# Check logs
tail -f /var/log/mongodb/mongod.log
```

#### Redis Connection Issues
```bash
# Check Redis status
sudo systemctl status redis

# Restart Redis
sudo systemctl restart redis

# Test Redis connection
redis-cli ping
```

#### Port Already in Use
```bash
# Find process using port
sudo lsof -i :5000

# Kill process
sudo kill -9 <PID>
```

### Log Files
- Backend: `backend/logs/`
- Frontend: Browser console
- Mobile: Device logs
- Nginx: `/var/log/nginx/`

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📞 Support

- **Email**: support@fleetflex.com
- **Documentation**: [docs.fleetflex.com](https://docs.fleetflex.com)
- **API Docs**: [api.fleetflex.com/docs](https://api.fleetflex.com/docs)
- **Status Page**: [status.fleetflex.com](https://status.fleetflex.com)

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with modern web technologies
- Inspired by leading logistics platforms
- Special thanks to all contributors
- Powered by open-source community

---

## 🚀 Quick Commands Reference

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run test` | Run tests |
| `npm run lint` | Run linter |
| `docker-compose up` | Start all services |
| `docker-compose down` | Stop all services |
| `docker-compose logs -f` | View logs |
| `npm run install:all` | Install all dependencies |
| `npm run seed` | Seed database |
| `npm run migrate` | Run migrations |

For more detailed documentation, visit our [documentation site](https://docs.fleetflex.com).