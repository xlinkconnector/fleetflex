# FleetFlex Mobile App

The FleetFlex Mobile App is a cross-platform mobile application built with React Native for the FleetFlex multi-service logistics platform. It provides users with access to food delivery, rideshare, shipping, moving, and freight services on iOS and Android devices.

## Features

### Core Features
- **Cross-platform compatibility**: iOS 14+ and Android 8+
- **Offline functionality** with data synchronization
- **Push notifications** with deep linking
- **Real-time GPS tracking** for orders and rides
- **Camera integration** for order verification
- **Biometric authentication** for secure access
- **In-app payments** with saved payment methods
- **Multi-language support** for global users

### Service-Specific Features

#### Food Delivery
- Restaurant browsing with search and filters
- Menu viewing with customization options
- Cart management and checkout
- Real-time order tracking
- Rating and review system

#### Rideshare
- Ride booking with location selection
- Driver/passenger matching
- Route optimization and fare calculation
- Real-time ride tracking
- Driver rating system

#### Shipping
- Package booking with size and weight options
- Pickup and delivery location selection
- Shipping cost calculation
- Package tracking
- Delivery confirmation

#### Moving
- Quote requests with inventory management
- Service booking with date and time selection
- Professional movers assignment
- Moving day tracking
- Service rating system

#### Freight
- Load posting with details and requirements
- Carrier matching based on availability
- Shipment tracking with real-time updates
- Delivery confirmation
- Rating and review system

## Technology Stack

- **Framework**: React Native with TypeScript
- **Navigation**: React Navigation v6
- **State Management**: Redux Toolkit
- **Maps**: React Native Maps
- **Push Notifications**: Firebase Cloud Messaging
- **Camera**: React Native Image Picker
- **Location**: React Native Geolocation
- **Payments**: Stripe React Native SDK
- **Offline Storage**: AsyncStorage and Redux Persist
- **Networking**: Axios with offline queue
- **UI Components**: Custom component library
- **Authentication**: JWT with secure storage
- **Analytics**: Firebase Analytics
- **Crash Reporting**: Firebase Crashlytics

## Getting Started

### Prerequisites
- Node.js 16+
- npm 8+ or Yarn 1.22+
- React Native CLI
- Xcode 13+ (for iOS development)
- Android Studio (for Android development)
- CocoaPods (for iOS dependencies)

### Installation

1. Clone the repository
```bash
git clone https://github.com/your-org/fleetflex.git
cd fleetflex/mobile
```

2. Install dependencies
```bash
npm install
# or
yarn install
```

3. Install iOS dependencies
```bash
cd ios && pod install && cd ..
```

4. Set up environment variables
```bash
cp .env.example .env
```

5. Start the development server
```bash
npm start
# or
yarn start
```

6. Run on iOS
```bash
npm run ios
# or
yarn ios
```

7. Run on Android
```bash
npm run android
# or
yarn android
```

## Project Structure

```
mobile/
├── android/
├── ios/
├── src/
│   ├── assets/
│   │   ├── fonts/
│   │   ├── images/
│   │   └── animations/
│   ├── components/
│   │   ├── common/
│   │   ├── food/
│   │   ├── ride/
│   │   ├── shipping/
│   │   ├── moving/
│   │   ├── freight/
│   │   └── ui/
│   ├── hooks/
│   ├── navigation/
│   │   ├── stacks/
│   │   ├── tabs/
│   │   └── index.tsx
│   ├── screens/
│   │   ├── auth/
│   │   ├── food/
│   │   ├── ride/
│   │   ├── shipping/
│   │   ├── moving/
│   │   ├── freight/
│   │   ├── profile/
│   │   └── common/
│   ├── services/
│   │   ├── api/
│   │   ├── location/
│   │   ├── notification/
│   │   └── storage/
│   ├── store/
│   │   ├── slices/
│   │   └── index.ts
│   ├── theme/
│   ├── utils/
│   └── App.tsx
├── .env.example
├── app.json
├── babel.config.js
├── index.js
├── metro.config.js
├── package.json
└── tsconfig.json
```

## Key Features Implementation

### Authentication Flow
The app implements a secure authentication flow with JWT tokens, refresh tokens, and biometric authentication. Users can sign up, log in, and recover their passwords through a user-friendly interface.

### Offline Support
The app provides offline support through a combination of Redux Persist for state persistence and a custom offline queue for API requests. Users can continue using the app even when offline, and changes are synchronized when the connection is restored.

### Real-time Tracking
The app uses a combination of React Native Maps, Geolocation API, and Socket.io to provide real-time tracking for orders, rides, and shipments. Users can track their orders on a map and receive real-time updates on their status.

### Push Notifications
The app uses Firebase Cloud Messaging to deliver push notifications to users. Notifications include order updates, ride confirmations, and promotional messages. Deep linking is implemented to navigate users to the relevant screen when they tap on a notification.

### Multi-language Support
The app supports multiple languages through a localization system. Users can select their preferred language in the app settings, and the app will display content in that language.

### Payment Processing
The app integrates with Stripe to provide secure payment processing. Users can save their payment methods for future use and make payments directly within the app.

## App Variants

### Customer App
The main app for end users to access all FleetFlex services. Users can order food, book rides, ship packages, schedule moving services, and arrange freight shipments.

### Driver App
A specialized version for drivers with features for accepting ride requests, navigation, earnings tracking, and schedule management. Drivers can toggle their availability and view their performance metrics.

### Restaurant App
A dedicated app for restaurant owners to manage their menu, accept orders, track deliveries, and view analytics. Restaurant owners can update their menu, prices, and availability in real-time.

## Building for Production

### iOS
```bash
npm run build:ios
# or
yarn build:ios
```

### Android
```bash
npm run build:android
# or
yarn build:android
```

## Testing

### Unit Tests
```bash
npm test
# or
yarn test
```

### E2E Tests
```bash
npm run e2e
# or
yarn e2e
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.