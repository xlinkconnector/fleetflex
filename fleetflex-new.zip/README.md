# FleetFlex Multi-Service Logistics Platform

<div align="center">
  <img src="docs/images/fleetflex-logo.png" alt="FleetFlex Logo" width="300"/>
  <h3>A comprehensive multi-service logistics platform</h3>
</div>

## 🚀 Overview

FleetFlex is an enterprise-grade multi-service logistics platform that provides food delivery, rideshare, shipping, moving, and freight services all in one unified system. The platform is designed to handle 10,000+ concurrent users and 1000+ orders per minute with 99.9% uptime.

### Core Services

- **🍔 Food Delivery**: Restaurant ordering with real-time tracking
- **🚗 Rideshare**: Driver/passenger matching with route optimization
- **📦 Shipping**: Package delivery with tracking and insurance
- **🏠 Moving**: Professional moving services with inventory management
- **🚚 Freight**: Heavy-duty cargo and freight logistics

## 🏗️ Architecture

FleetFlex is built with a modern microservices architecture using the following technologies:

### Backend
- **Framework**: Node.js with Express.js
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT with refresh tokens
- **Real-time**: Socket.io for live tracking
- **Caching**: Redis
- **File Storage**: Cloudinary
- **Payment**: Stripe integration
- **Email**: Nodemailer with templates

### Frontend
- **Framework**: React 18 with TypeScript
- **State Management**: Redux Toolkit
- **Styling**: Tailwind CSS
- **Routing**: React Router v6
- **Forms**: React Hook Form
- **Maps**: Google Maps integration
- **Charts**: Recharts for analytics

### Mobile
- **Framework**: React Native
- **Navigation**: React Navigation
- **State**: Redux Toolkit
- **Maps**: React Native Maps
- **Notifications**: Firebase Cloud Messaging

### DevOps
- **Containerization**: Docker & Docker Compose
- **Reverse Proxy**: Nginx
- **SSL**: Let's Encrypt
- **CI/CD**: GitHub Actions
- **Monitoring**: Winston logging

## 📋 Features

### User Management
- Multi-role system (customer, driver, restaurant, admin)
- JWT authentication with refresh tokens
- Email verification and password reset
- Profile management with avatar upload
- Address management with Google Maps integration
- KYC verification system

### Food Delivery
- Restaurant browsing and searching
- Menu management with categories and options
- Cart management and checkout
- Real-time order tracking
- Rating and review system

### Rideshare
- Driver/passenger matching
- Route optimization
- Fare calculation
- Real-time tracking
- Driver rating system

### Shipping
- Package booking and tracking
- Delivery confirmation
- Insurance options
- Pricing based on weight and dimensions

### Moving
- Quote requests
- Inventory management
- Service booking
- Professional movers assignment

### Freight
- Load posting
- Carrier matching
- Shipment tracking
- Heavy cargo handling

### Payment Processing
- Secure payment with Stripe
- Multiple payment methods
- Automatic receipts
- Refund processing
- Driver/restaurant payouts

### Admin Dashboard
- Comprehensive management system
- User management
- Order tracking and management
- Restaurant approval workflow
- Driver verification
- Analytics and reporting
- Content management

## 🚀 Getting Started

### Prerequisites
- Docker and Docker Compose
- Node.js 18+ (for development)
- MongoDB 6+ (handled by Docker)
- Redis 7+ (handled by Docker)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/fleetflex.git
   cd fleetflex
   ```

2. **Run the installation script**
   ```bash
   ./install.sh
   ```

3. **Access the applications**
   - Frontend: http://localhost:3000
   - Admin Dashboard: http://localhost:3001
   - API: http://localhost:5000

### Manual Installation

1. **Copy environment variables**
   ```bash
   cp .env.example .env
   ```

2. **Update environment variables**
   Edit the `.env` file with your configuration

3. **Start the services**
   ```bash
   docker-compose up -d
   ```

## 💻 Development

### Backend Development
```bash
cd backend
npm install
npm run dev
```

### Frontend Development
```bash
cd frontend
npm install
npm run dev
```

### Admin Dashboard Development
```bash
cd admin
npm install
npm run dev
```

## 🧪 Testing

### Backend Tests
```bash
cd backend
npm test
```

### Frontend Tests
```bash
cd frontend
npm test
```

## 📚 Documentation

- [API Documentation](docs/api.md)
- [User Manual](docs/user-manual.md)
- [Admin Manual](docs/admin-manual.md)
- [Developer Guide](docs/developer-guide.md)
- [Deployment Guide](docs/deployment-guide.md)

## 🔧 Configuration

### Environment Variables

Key environment variables include:

```
# Application
NODE_ENV=development

# MongoDB
MONGODB_URI=mongodb://localhost:27017/fleetflex

# JWT
JWT_SECRET=your_jwt_secret
JWT_EXPIRES_IN=1d

# Stripe
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret

# Cloudinary
CLOUDINARY_CLOUD_NAME=your_cloudinary_cloud_name
CLOUDINARY_API_KEY=your_cloudinary_api_key
CLOUDINARY_API_SECRET=your_cloudinary_api_secret

# Google Maps
GOOGLE_MAPS_API_KEY=your_google_maps_api_key
```

See `.env.example` for a complete list of environment variables.

## 🚢 Deployment

### Docker Deployment
```bash
docker-compose -f docker-compose.prod.yml up -d
```

### Manual Deployment
See the [Deployment Guide](docs/deployment-guide.md) for detailed instructions.

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with modern web technologies
- Inspired by leading logistics platforms
- Special thanks to all contributors

---

<div align="center">
  <p>© 2025 FleetFlex. All rights reserved.</p>
</div>