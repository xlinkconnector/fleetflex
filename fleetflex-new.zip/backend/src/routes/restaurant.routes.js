const express = require('express');
const { body } = require('express-validator');
const restaurantController = require('../controllers/restaurant.controller');
const { protect, restrictTo, isVerified, checkOwnership } = require('../middleware/auth.middleware');

const router = express.Router();

// Validate restaurant creation/update
const validateRestaurant = [
  body('name')
    .notEmpty()
    .withMessage('Restaurant name is required')
    .trim(),
  body('description')
    .optional()
    .trim(),
  body('cuisine')
    .isArray({ min: 1 })
    .withMessage('At least one cuisine type is required'),
  body('address.street')
    .notEmpty()
    .withMessage('Street address is required')
    .trim(),
  body('address.city')
    .notEmpty()
    .withMessage('City is required')
    .trim(),
  body('address.state')
    .notEmpty()
    .withMessage('State is required')
    .trim(),
  body('address.zipCode')
    .notEmpty()
    .withMessage('ZIP code is required')
    .trim(),
  body('address.coordinates.lat')
    .isNumeric()
    .withMessage('Valid latitude is required'),
  body('address.coordinates.lng')
    .isNumeric()
    .withMessage('Valid longitude is required'),
  body('contactInfo.phone')
    .notEmpty()
    .withMessage('Phone number is required')
    .matches(/^\+?[1-9]\d{1,14}$/)
    .withMessage('Please provide a valid phone number')
    .trim(),
  body('contactInfo.email')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  body('operatingHours')
    .isArray({ min: 1 })
    .withMessage('Operating hours are required')
];

// Validate menu item
const validateMenuItem = [
  body('name')
    .notEmpty()
    .withMessage('Item name is required')
    .trim(),
  body('price')
    .isNumeric()
    .withMessage('Valid price is required'),
  body('category')
    .notEmpty()
    .withMessage('Category is required')
    .trim()
];

// Public routes
router.get('/', restaurantController.getAllRestaurants);
router.get('/featured', restaurantController.getFeaturedRestaurants);
router.get('/nearby', restaurantController.getNearbyRestaurants);
router.get('/search', restaurantController.searchRestaurants);
router.get('/cuisines', restaurantController.getAllCuisines);
router.get('/:id', restaurantController.getRestaurant);
router.get('/:id/menu', restaurantController.getRestaurantMenu);
router.get('/:id/reviews', restaurantController.getRestaurantReviews);

// Protected routes
router.use(protect);

// Customer routes
router.post('/:id/reviews', isVerified, restaurantController.addRestaurantReview);

// Restaurant owner routes
router.post('/', restrictTo('restaurant'), isVerified, validateRestaurant, restaurantController.createRestaurant);
router.patch('/:id', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), validateRestaurant, restaurantController.updateRestaurant);
router.patch('/:id/status', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), restaurantController.updateRestaurantStatus);
router.post('/:id/menu', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), validateMenuItem, restaurantController.addMenuItem);
router.patch('/:id/menu/:itemId', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), validateMenuItem, restaurantController.updateMenuItem);
router.delete('/:id/menu/:itemId', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), restaurantController.deleteMenuItem);
router.post('/:id/images', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), restaurantController.uploadRestaurantImages);
router.patch('/:id/logo', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), restaurantController.updateRestaurantLogo);
router.patch('/:id/hours', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), restaurantController.updateOperatingHours);
router.get('/:id/orders', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), restaurantController.getRestaurantOrders);
router.get('/:id/analytics', restrictTo('restaurant', 'admin'), checkOwnership('restaurant'), restaurantController.getRestaurantAnalytics);

// Admin routes
router.use(restrictTo('admin'));
router.patch('/:id/verify', restaurantController.verifyRestaurant);
router.delete('/:id', restaurantController.deleteRestaurant);
router.get('/admin/pending', restaurantController.getPendingRestaurants);
router.patch('/:id/feature', restaurantController.toggleFeaturedRestaurant);

module.exports = router;