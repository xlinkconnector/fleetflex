const express = require('express');
const { body } = require('express-validator');
const vehicleController = require('../controllers/vehicle.controller');
const { protect, restrictTo, isVerified, checkOwnership } = require('../middleware/auth.middleware');

const router = express.Router();

// Protect all vehicle routes
router.use(protect);

// Validate vehicle creation/update
const validateVehicle = [
  body('type')
    .isIn(['car', 'suv', 'van', 'truck', 'motorcycle', 'bicycle', 'scooter', 'semi-truck', 'box-truck', 'refrigerated-truck'])
    .withMessage('Invalid vehicle type'),
  body('serviceType')
    .isArray({ min: 1 })
    .withMessage('At least one service type is required'),
  body('serviceType.*')
    .isIn(['ride', 'food', 'shipping', 'moving', 'freight'])
    .withMessage('Invalid service type'),
  body('make')
    .notEmpty()
    .withMessage('Make is required')
    .trim(),
  body('model')
    .notEmpty()
    .withMessage('Model is required')
    .trim(),
  body('year')
    .isInt({ min: 1900, max: new Date().getFullYear() + 1 })
    .withMessage('Valid year is required'),
  body('color')
    .notEmpty()
    .withMessage('Color is required')
    .trim(),
  body('licensePlate')
    .notEmpty()
    .withMessage('License plate is required')
    .trim()
];

// Validate vehicle documents
const validateVehicleDocuments = [
  body('type')
    .isIn(['registration', 'insurance', 'inspection', 'permit', 'other'])
    .withMessage('Invalid document type'),
  body('number')
    .notEmpty()
    .withMessage('Document number is required')
    .trim(),
  body('expiryDate')
    .isISO8601()
    .withMessage('Valid expiry date is required')
];

// Validate vehicle location update
const validateLocationUpdate = [
  body('coordinates.lat')
    .isNumeric()
    .withMessage('Valid latitude is required'),
  body('coordinates.lng')
    .isNumeric()
    .withMessage('Valid longitude is required'),
  body('address')
    .optional()
    .trim()
];

// Driver routes
router.get('/my-vehicles', restrictTo('driver'), vehicleController.getMyVehicles);
router.post('/', restrictTo('driver'), isVerified, validateVehicle, vehicleController.createVehicle);
router.get('/:id', checkOwnership('vehicle'), vehicleController.getVehicle);
router.patch('/:id', restrictTo('driver', 'admin'), checkOwnership('vehicle'), validateVehicle, vehicleController.updateVehicle);
router.delete('/:id', restrictTo('driver', 'admin'), checkOwnership('vehicle'), vehicleController.deleteVehicle);
router.post('/:id/documents', restrictTo('driver', 'admin'), checkOwnership('vehicle'), validateVehicleDocuments, vehicleController.addVehicleDocument);
router.patch('/:id/documents/:documentId', restrictTo('driver', 'admin'), checkOwnership('vehicle'), vehicleController.updateVehicleDocument);
router.delete('/:id/documents/:documentId', restrictTo('driver', 'admin'), checkOwnership('vehicle'), vehicleController.deleteVehicleDocument);
router.post('/:id/images', restrictTo('driver', 'admin'), checkOwnership('vehicle'), vehicleController.uploadVehicleImages);
router.delete('/:id/images/:imageId', restrictTo('driver', 'admin'), checkOwnership('vehicle'), vehicleController.deleteVehicleImage);
router.patch('/:id/status', restrictTo('driver', 'admin'), checkOwnership('vehicle'), vehicleController.updateVehicleStatus);
router.patch('/:id/location', restrictTo('driver'), checkOwnership('vehicle'), validateLocationUpdate, vehicleController.updateVehicleLocation);
router.patch('/:id/availability', restrictTo('driver'), checkOwnership('vehicle'), vehicleController.updateVehicleAvailability);
router.post('/:id/maintenance', restrictTo('driver', 'admin'), checkOwnership('vehicle'), vehicleController.addMaintenanceRecord);

// Admin routes
router.use(restrictTo('admin'));
router.get('/', vehicleController.getAllVehicles);
router.get('/pending', vehicleController.getPendingVehicles);
router.patch('/:id/verify', vehicleController.verifyVehicle);
router.get('/analytics', vehicleController.getVehicleAnalytics);

module.exports = router;