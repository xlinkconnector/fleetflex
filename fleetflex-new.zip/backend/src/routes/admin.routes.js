const express = require('express');
const adminController = require('../controllers/admin.controller');
const { protect, restrictTo } = require('../middleware/auth.middleware');

const router = express.Router();

// Protect all admin routes and restrict to admin role
router.use(protect, restrictTo('admin'));

// Dashboard and analytics
router.get('/dashboard', adminController.getDashboard);
router.get('/analytics/overview', adminController.getAnalyticsOverview);
router.get('/analytics/users', adminController.getUserAnalytics);
router.get('/analytics/orders', adminController.getOrderAnalytics);
router.get('/analytics/revenue', adminController.getRevenueAnalytics);
router.get('/analytics/restaurants', adminController.getRestaurantAnalytics);
router.get('/analytics/drivers', adminController.getDriverAnalytics);

// User management
router.get('/users', adminController.getAllUsers);
router.get('/users/:id', adminController.getUser);
router.patch('/users/:id', adminController.updateUser);
router.delete('/users/:id', adminController.deleteUser);
router.patch('/users/:id/status', adminController.updateUserStatus);
router.patch('/users/:id/role', adminController.updateUserRole);

// KYC management
router.get('/kyc/pending', adminController.getPendingKycDocuments);
router.get('/kyc/verified', adminController.getVerifiedKycDocuments);
router.get('/kyc/rejected', adminController.getRejectedKycDocuments);
router.patch('/kyc/:id/verify', adminController.verifyKycDocument);
router.patch('/kyc/:id/reject', adminController.rejectKycDocument);

// Restaurant management
router.get('/restaurants', adminController.getAllRestaurants);
router.get('/restaurants/pending', adminController.getPendingRestaurants);
router.get('/restaurants/:id', adminController.getRestaurant);
router.patch('/restaurants/:id', adminController.updateRestaurant);
router.patch('/restaurants/:id/verify', adminController.verifyRestaurant);
router.patch('/restaurants/:id/reject', adminController.rejectRestaurant);
router.patch('/restaurants/:id/status', adminController.updateRestaurantStatus);
router.delete('/restaurants/:id', adminController.deleteRestaurant);

// Vehicle management
router.get('/vehicles', adminController.getAllVehicles);
router.get('/vehicles/pending', adminController.getPendingVehicles);
router.get('/vehicles/:id', adminController.getVehicle);
router.patch('/vehicles/:id/verify', adminController.verifyVehicle);
router.patch('/vehicles/:id/reject', adminController.rejectVehicle);
router.patch('/vehicles/:id/status', adminController.updateVehicleStatus);

// Order management
router.get('/orders', adminController.getAllOrders);
router.get('/orders/:id', adminController.getOrder);
router.patch('/orders/:id/status', adminController.updateOrderStatus);
router.patch('/orders/:id/assign', adminController.assignOrderToDriver);
router.delete('/orders/:id', adminController.deleteOrder);

// Payment management
router.get('/payments', adminController.getAllPayments);
router.get('/payments/:id', adminController.getPayment);
router.post('/payments/refund', adminController.processRefund);
router.get('/payouts', adminController.getAllPayouts);
router.patch('/payouts/:id/status', adminController.updatePayoutStatus);

// Content management
router.get('/content/banners', adminController.getAllBanners);
router.post('/content/banners', adminController.createBanner);
router.patch('/content/banners/:id', adminController.updateBanner);
router.delete('/content/banners/:id', adminController.deleteBanner);
router.get('/content/promotions', adminController.getAllPromotions);
router.post('/content/promotions', adminController.createPromotion);
router.patch('/content/promotions/:id', adminController.updatePromotion);
router.delete('/content/promotions/:id', adminController.deletePromotion);

// Settings management
router.get('/settings', adminController.getSettings);
router.patch('/settings', adminController.updateSettings);
router.get('/settings/fees', adminController.getFeeSettings);
router.patch('/settings/fees', adminController.updateFeeSettings);
router.get('/settings/service-areas', adminController.getServiceAreas);
router.post('/settings/service-areas', adminController.addServiceArea);
router.patch('/settings/service-areas/:id', adminController.updateServiceArea);
router.delete('/settings/service-areas/:id', adminController.deleteServiceArea);

// System management
router.get('/system/logs', adminController.getSystemLogs);
router.get('/system/health', adminController.getSystemHealth);
router.post('/system/backup', adminController.createBackup);
router.get('/system/backups', adminController.getBackups);
router.post('/system/restore', adminController.restoreBackup);

module.exports = router;