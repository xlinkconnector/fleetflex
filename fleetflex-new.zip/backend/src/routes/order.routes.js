const express = require('express');
const { body } = require('express-validator');
const orderController = require('../controllers/order.controller');
const { protect, restrictTo, isVerified } = require('../middleware/auth.middleware');

const router = express.Router();

// Protect all order routes
router.use(protect);

// Validate order creation
const validateOrder = [
  body('serviceType')
    .isIn(['food', 'ride', 'shipping', 'moving', 'freight'])
    .withMessage('Invalid service type'),
  body('paymentMethod')
    .isIn(['card', 'cash', 'wallet', 'paypal'])
    .withMessage('Invalid payment method')
];

// Validate food order
const validateFoodOrder = [
  body('restaurant')
    .isMongoId()
    .withMessage('Invalid restaurant ID'),
  body('items')
    .isArray({ min: 1 })
    .withMessage('At least one item is required'),
  body('items.*.quantity')
    .isInt({ min: 1 })
    .withMessage('Quantity must be at least 1')
];

// Validate ride order
const validateRideOrder = [
  body('ride.pickupLocation')
    .notEmpty()
    .withMessage('Pickup location is required'),
  body('ride.dropoffLocation')
    .notEmpty()
    .withMessage('Dropoff location is required'),
  body('ride.rideType')
    .isIn(['economy', 'comfort', 'premium', 'xl'])
    .withMessage('Invalid ride type')
];

// Validate shipping order
const validateShippingOrder = [
  body('shipping.packageDetails')
    .notEmpty()
    .withMessage('Package details are required'),
  body('shipping.pickupLocation')
    .notEmpty()
    .withMessage('Pickup location is required'),
  body('shipping.deliveryLocation')
    .notEmpty()
    .withMessage('Delivery location is required')
];

// Validate moving order
const validateMovingOrder = [
  body('moving.propertySize')
    .notEmpty()
    .withMessage('Property size is required'),
  body('moving.moveDate')
    .isISO8601()
    .withMessage('Valid move date is required'),
  body('moving.originAddress')
    .notEmpty()
    .withMessage('Origin address is required'),
  body('moving.destinationAddress')
    .notEmpty()
    .withMessage('Destination address is required')
];

// Validate freight order
const validateFreightOrder = [
  body('freight.cargoType')
    .notEmpty()
    .withMessage('Cargo type is required'),
  body('freight.weight')
    .isNumeric()
    .withMessage('Valid weight is required'),
  body('freight.pickupDate')
    .isISO8601()
    .withMessage('Valid pickup date is required'),
  body('freight.originAddress')
    .notEmpty()
    .withMessage('Origin address is required'),
  body('freight.destinationAddress')
    .notEmpty()
    .withMessage('Destination address is required')
];

// Customer routes
router.get('/my-orders', orderController.getMyOrders);
router.get('/:id', orderController.getOrder);
router.post('/', isVerified, validateOrder, orderController.createOrder);
router.post('/food', isVerified, [...validateOrder, ...validateFoodOrder], orderController.createFoodOrder);
router.post('/ride', isVerified, [...validateOrder, ...validateRideOrder], orderController.createRideOrder);
router.post('/shipping', isVerified, [...validateOrder, ...validateShippingOrder], orderController.createShippingOrder);
router.post('/moving', isVerified, [...validateOrder, ...validateMovingOrder], orderController.createMovingOrder);
router.post('/freight', isVerified, [...validateOrder, ...validateFreightOrder], orderController.createFreightOrder);
router.patch('/:id/cancel', orderController.cancelOrder);
router.post('/:id/payment', orderController.processPayment);
router.post('/:id/rating', orderController.rateOrder);

// Driver routes
router.use(restrictTo('driver', 'admin'));
router.get('/available', orderController.getAvailableOrders);
router.patch('/:id/accept', orderController.acceptOrder);
router.patch('/:id/pickup', orderController.pickupOrder);
router.patch('/:id/complete', orderController.completeOrder);
router.patch('/:id/location', orderController.updateOrderLocation);

// Restaurant routes
router.use(restrictTo('restaurant', 'admin'));
router.get('/restaurant/pending', orderController.getRestaurantPendingOrders);
router.patch('/:id/confirm', orderController.confirmOrder);
router.patch('/:id/ready', orderController.markOrderReady);

// Admin routes
router.use(restrictTo('admin'));
router.get('/', orderController.getAllOrders);
router.patch('/:id', orderController.updateOrder);
router.delete('/:id', orderController.deleteOrder);

module.exports = router;