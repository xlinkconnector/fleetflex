const express = require('express');
const { body } = require('express-validator');
const userController = require('../controllers/user.controller');
const { protect, restrictTo, isVerified } = require('../middleware/auth.middleware');

const router = express.Router();

// Protect all user routes
router.use(protect);

// Validate profile update
const validateProfileUpdate = [
  body('firstName')
    .optional()
    .notEmpty()
    .withMessage('First name cannot be empty')
    .trim(),
  body('lastName')
    .optional()
    .notEmpty()
    .withMessage('Last name cannot be empty')
    .trim(),
  body('phone')
    .optional()
    .matches(/^\+?[1-9]\d{1,14}$/)
    .withMessage('Please provide a valid phone number')
    .trim(),
  body('profile.address')
    .optional(),
  body('profile.dateOfBirth')
    .optional()
    .isISO8601()
    .withMessage('Please provide a valid date'),
  body('profile.preferences')
    .optional()
];

// Validate driver profile
const validateDriverProfile = [
  body('driver.license.number')
    .notEmpty()
    .withMessage('License number is required')
    .trim(),
  body('driver.license.expiry')
    .isISO8601()
    .withMessage('Valid license expiry date is required')
];

// Validate KYC document
const validateKycDocument = [
  body('type')
    .isIn(['id', 'license', 'address', 'vehicle', 'insurance'])
    .withMessage('Invalid document type')
];

// User profile routes
router.get('/profile', userController.getProfile);
router.patch('/profile', validateProfileUpdate, userController.updateProfile);
router.patch('/avatar', userController.updateAvatar);
router.patch('/preferences', userController.updatePreferences);
router.get('/addresses', userController.getUserAddresses);
router.post('/addresses', userController.addUserAddress);
router.patch('/addresses/:addressId', userController.updateUserAddress);
router.delete('/addresses/:addressId', userController.deleteUserAddress);

// Payment methods
router.get('/payment-methods', userController.getPaymentMethods);
router.post('/payment-methods', userController.addPaymentMethod);
router.delete('/payment-methods/:id', userController.deletePaymentMethod);
router.patch('/payment-methods/:id/default', userController.setDefaultPaymentMethod);

// Order history
router.get('/orders', userController.getUserOrders);
router.get('/orders/:id', userController.getUserOrder);

// Driver specific routes
router.patch('/driver-profile', restrictTo('driver'), isVerified, validateDriverProfile, userController.updateDriverProfile);
router.patch('/driver-status', restrictTo('driver'), isVerified, userController.updateDriverStatus);
router.get('/driver-analytics', restrictTo('driver'), userController.getDriverAnalytics);
router.get('/driver-earnings', restrictTo('driver'), userController.getDriverEarnings);

// KYC verification
router.post('/kyc/documents', validateKycDocument, userController.uploadKycDocument);
router.get('/kyc/status', userController.getKycStatus);

// Restaurant owner specific routes
router.get('/restaurants', restrictTo('restaurant'), userController.getUserRestaurants);

// Admin routes
router.use(restrictTo('admin'));
router.get('/', userController.getAllUsers);
router.get('/:id', userController.getUser);
router.patch('/:id', userController.updateUser);
router.delete('/:id', userController.deleteUser);
router.patch('/:id/status', userController.updateUserStatus);
router.get('/kyc/pending', userController.getPendingKycDocuments);
router.patch('/kyc/:id/verify', userController.verifyKycDocument);
router.patch('/kyc/:id/reject', userController.rejectKycDocument);

module.exports = router;