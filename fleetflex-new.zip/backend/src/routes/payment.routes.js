const express = require('express');
const { body } = require('express-validator');
const paymentController = require('../controllers/payment.controller');
const { protect, restrictTo } = require('../middleware/auth.middleware');

const router = express.Router();

// Protect all payment routes
router.use(protect);

// Validate payment intent creation
const validatePaymentIntent = [
  body('amount')
    .isNumeric()
    .withMessage('Valid amount is required'),
  body('currency')
    .isLength({ min: 3, max: 3 })
    .withMessage('Valid currency code is required (e.g., USD)')
    .default('USD'),
  body('paymentMethodId')
    .optional()
    .isString()
    .withMessage('Valid payment method ID is required'),
  body('orderId')
    .optional()
    .isMongoId()
    .withMessage('Valid order ID is required')
];

// Validate payment method
const validatePaymentMethod = [
  body('type')
    .isIn(['card', 'bank_account'])
    .withMessage('Invalid payment method type'),
  body('token')
    .isString()
    .withMessage('Valid token is required')
];

// Validate payout
const validatePayout = [
  body('amount')
    .isNumeric()
    .withMessage('Valid amount is required'),
  body('destination')
    .isString()
    .withMessage('Valid destination is required'),
  body('currency')
    .isLength({ min: 3, max: 3 })
    .withMessage('Valid currency code is required (e.g., USD)')
    .default('USD')
];

// Customer routes
router.post('/create-payment-intent', validatePaymentIntent, paymentController.createPaymentIntent);
router.post('/confirm-payment', paymentController.confirmPayment);
router.post('/payment-methods', validatePaymentMethod, paymentController.createPaymentMethod);
router.get('/payment-methods', paymentController.getPaymentMethods);
router.delete('/payment-methods/:id', paymentController.deletePaymentMethod);
router.get('/transactions', paymentController.getUserTransactions);
router.get('/transactions/:id', paymentController.getTransaction);

// Driver/Restaurant routes
router.get('/balance', restrictTo('driver', 'restaurant'), paymentController.getBalance);
router.post('/payout', restrictTo('driver', 'restaurant'), validatePayout, paymentController.createPayout);
router.get('/payouts', restrictTo('driver', 'restaurant'), paymentController.getPayouts);
router.get('/earnings', restrictTo('driver', 'restaurant'), paymentController.getEarnings);

// Webhook handler (unprotected)
router.post('/webhook', paymentController.handleWebhook);

// Admin routes
router.use(restrictTo('admin'));
router.get('/admin/transactions', paymentController.getAllTransactions);
router.get('/admin/payouts', paymentController.getAllPayouts);
router.post('/admin/refund', paymentController.processRefund);
router.get('/admin/analytics', paymentController.getPaymentAnalytics);
router.patch('/admin/transaction/:id', paymentController.updateTransactionStatus);

module.exports = router;