const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema({
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    enum: ['car', 'suv', 'van', 'truck', 'motorcycle', 'bicycle', 'scooter', 'semi-truck', 'box-truck', 'refrigerated-truck'],
    required: true
  },
  serviceType: [{
    type: String,
    enum: ['ride', 'food', 'shipping', 'moving', 'freight'],
    required: true
  }],
  make: {
    type: String,
    required: true,
    trim: true
  },
  model: {
    type: String,
    required: true,
    trim: true
  },
  year: {
    type: Number,
    required: true,
    min: 1900,
    max: new Date().getFullYear() + 1
  },
  color: {
    type: String,
    required: true,
    trim: true
  },
  licensePlate: {
    type: String,
    required: true,
    trim: true,
    uppercase: true
  },
  vin: {
    type: String,
    trim: true,
    uppercase: true
  },
  images: [{
    type: String,
    required: true
  }],
  documents: [{
    type: {
      type: String,
      enum: ['registration', 'insurance', 'inspection', 'permit', 'other'],
      required: true
    },
    number: String,
    issuedBy: String,
    issuedDate: Date,
    expiryDate: Date,
    image: String,
    isVerified: {
      type: Boolean,
      default: false
    },
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    verifiedAt: Date
  }],
  specifications: {
    // Common specs
    seats: {
      type: Number,
      min: 1,
      max: 100
    },
    doors: Number,
    transmission: {
      type: String,
      enum: ['automatic', 'manual', 'semi-automatic', 'n/a']
    },
    fuelType: {
      type: String,
      enum: ['gasoline', 'diesel', 'electric', 'hybrid', 'natural-gas', 'propane', 'n/a']
    },
    
    // Cargo specs
    cargoCapacity: {
      volume: Number, // cubic feet
      weight: Number, // pounds
      length: Number, // feet
      width: Number, // feet
      height: Number // feet
    },
    
    // Truck specs
    truckSpecifications: {
      axles: Number,
      gvwr: Number, // Gross Vehicle Weight Rating
      class: {
        type: String,
        enum: ['1', '2', '3', '4', '5', '6', '7', '8']
      },
      bedLength: Number, // feet
      bedType: {
        type: String,
        enum: ['flatbed', 'enclosed', 'refrigerated', 'dump', 'tank', 'car-carrier', 'logging', 'other']
      },
      liftgate: Boolean,
      towingCapacity: Number // pounds
    },
    
    // Features
    features: [{
      type: String,
      enum: [
        'air-conditioning', 'heating', 'gps', 'bluetooth', 'wifi', 'wheelchair-accessible',
        'child-seat', 'pet-friendly', 'sunroof', 'leather-seats', 'backup-camera',
        'cruise-control', 'entertainment-system', 'cargo-barrier', 'roof-rack',
        'refrigeration', 'hazmat-certified', 'liftgate', 'pallet-jack', 'loading-ramp'
      ]
    }]
  },
  status: {
    type: String,
    enum: ['active', 'maintenance', 'inactive', 'pending-approval'],
    default: 'pending-approval'
  },
  isAvailable: {
    type: Boolean,
    default: false
  },
  currentLocation: {
    coordinates: {
      lat: Number,
      lng: Number
    },
    address: String,
    updatedAt: Date
  },
  maintenanceHistory: [{
    type: {
      type: String,
      enum: ['routine', 'repair', 'inspection', 'other']
    },
    description: String,
    date: Date,
    mileage: Number,
    cost: Number,
    provider: String,
    documents: [String]
  }],
  mileage: {
    current: Number,
    lastUpdated: Date
  },
  insurance: {
    provider: String,
    policyNumber: String,
    coverageType: String,
    startDate: Date,
    expiryDate: Date,
    image: String,
    isVerified: {
      type: Boolean,
      default: false
    }
  },
  rating: {
    average: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    count: {
      type: Number,
      default: 0
    }
  },
  reviews: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5
    },
    comment: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  pricing: {
    // Ride pricing
    ride: {
      baseRate: Number,
      perMileRate: Number,
      perMinuteRate: Number,
      minimumFare: Number,
      cancellationFee: Number
    },
    
    // Shipping pricing
    shipping: {
      baseRate: Number,
      perMileRate: Number,
      weightMultiplier: Number,
      volumeMultiplier: Number,
      minimumFare: Number
    },
    
    // Moving pricing
    moving: {
      hourlyRate: Number,
      minimumHours: Number,
      travelFee: Number,
      materialsFee: Number
    },
    
    // Freight pricing
    freight: {
      baseRate: Number,
      perMileRate: Number,
      weightMultiplier: Number,
      volumeMultiplier: Number,
      minimumFare: Number,
      additionalStopFee: Number
    }
  },
  availability: {
    schedule: [{
      day: {
        type: String,
        enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
      },
      startTime: String,
      endTime: String,
      isAvailable: {
        type: Boolean,
        default: true
      }
    }],
    customUnavailability: [{
      startDate: Date,
      endDate: Date,
      reason: String
    }]
  },
  verificationStatus: {
    type: String,
    enum: ['pending', 'verified', 'rejected'],
    default: 'pending'
  },
  verificationNotes: String,
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Create indexes for frequently queried fields
vehicleSchema.index({ owner: 1 });
vehicleSchema.index({ type: 1 });
vehicleSchema.index({ serviceType: 1 });
vehicleSchema.index({ status: 1, isAvailable: 1 });
vehicleSchema.index({ 'currentLocation.coordinates': '2dsphere' });
vehicleSchema.index({ licensePlate: 1 });
vehicleSchema.index({ verificationStatus: 1 });

// Update updatedAt timestamp
vehicleSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Calculate average rating when a review is added or updated
vehicleSchema.pre('save', function(next) {
  if (this.isModified('reviews')) {
    const totalRating = this.reviews.reduce((sum, review) => sum + review.rating, 0);
    this.rating.average = this.reviews.length > 0 ? totalRating / this.reviews.length : 0;
    this.rating.count = this.reviews.length;
  }
  next();
});

// Check if insurance is expired
vehicleSchema.virtual('isInsuranceExpired').get(function() {
  if (!this.insurance || !this.insurance.expiryDate) return true;
  return new Date() > new Date(this.insurance.expiryDate);
});

// Check if any document is expired
vehicleSchema.virtual('hasExpiredDocuments').get(function() {
  if (!this.documents || this.documents.length === 0) return true;
  
  const now = new Date();
  return this.documents.some(doc => 
    doc.expiryDate && new Date(doc.expiryDate) < now
  );
});

const Vehicle = mongoose.model('Vehicle', vehicleSchema);

module.exports = Vehicle;