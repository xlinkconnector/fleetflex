const mongoose = require('mongoose');

const menuItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Menu item name is required'],
    trim: true
  },
  description: {
    type: String,
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Price is required'],
    min: [0, 'Price cannot be negative']
  },
  image: String,
  isAvailable: {
    type: Boolean,
    default: true
  },
  preparationTime: {
    type: Number,
    default: 15 // in minutes
  },
  ingredients: [String],
  allergens: [String],
  nutrition: {
    calories: Number,
    protein: Number,
    carbs: Number,
    fat: Number
  },
  options: [{
    name: {
      type: String,
      required: true
    },
    required: {
      type: Boolean,
      default: false
    },
    multiSelect: {
      type: Boolean,
      default: false
    },
    choices: [{
      name: {
        type: String,
        required: true
      },
      price: {
        type: Number,
        default: 0
      }
    }]
  }],
  category: {
    type: String,
    required: true
  },
  tags: [String],
  featured: {
    type: Boolean,
    default: false
  },
  discountPercentage: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

const restaurantSchema = new mongoose.Schema({
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: [true, 'Restaurant name is required'],
    trim: true,
    maxlength: [100, 'Name cannot exceed 100 characters']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [1000, 'Description cannot exceed 1000 characters']
  },
  cuisine: {
    type: [String],
    required: [true, 'At least one cuisine type is required']
  },
  address: {
    street: {
      type: String,
      required: [true, 'Street address is required']
    },
    city: {
      type: String,
      required: [true, 'City is required']
    },
    state: {
      type: String,
      required: [true, 'State is required']
    },
    zipCode: {
      type: String,
      required: [true, 'ZIP code is required']
    },
    country: {
      type: String,
      required: [true, 'Country is required'],
      default: 'USA'
    },
    coordinates: {
      lat: {
        type: Number,
        required: [true, 'Latitude is required']
      },
      lng: {
        type: Number,
        required: [true, 'Longitude is required']
      }
    }
  },
  contactInfo: {
    phone: {
      type: String,
      required: [true, 'Phone number is required']
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email']
    },
    website: String
  },
  images: [String],
  logo: String,
  coverImage: String,
  rating: {
    average: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    count: {
      type: Number,
      default: 0
    }
  },
  reviews: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5
    },
    comment: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  operatingHours: [{
    day: {
      type: String,
      enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
      required: true
    },
    open: {
      type: String,
      required: true
    },
    close: {
      type: String,
      required: true
    },
    isOpen: {
      type: Boolean,
      default: true
    }
  }],
  menu: [menuItemSchema],
  menuCategories: [{
    name: String,
    description: String,
    image: String,
    order: Number
  }],
  isActive: {
    type: Boolean,
    default: true
  },
  isOpen: {
    type: Boolean,
    default: false
  },
  isPaused: {
    type: Boolean,
    default: false
  },
  pauseReason: String,
  delivery: {
    isAvailable: {
      type: Boolean,
      default: true
    },
    radius: {
      type: Number,
      default: 5 // in miles
    },
    minimumOrder: {
      type: Number,
      default: 0
    },
    fee: {
      type: Number,
      default: 0
    },
    estimatedTime: {
      type: Number,
      default: 30 // in minutes
    }
  },
  pickup: {
    isAvailable: {
      type: Boolean,
      default: true
    },
    estimatedTime: {
      type: Number,
      default: 15 // in minutes
    }
  },
  paymentMethods: {
    acceptsCash: {
      type: Boolean,
      default: true
    },
    acceptsCard: {
      type: Boolean,
      default: true
    },
    acceptsWallet: {
      type: Boolean,
      default: false
    }
  },
  settings: {
    autoAcceptOrders: {
      type: Boolean,
      default: false
    },
    preparationTime: {
      type: Number,
      default: 15 // in minutes
    },
    taxRate: {
      type: Number,
      default: 0.0825 // 8.25%
    },
    commissionRate: {
      type: Number,
      default: 0.15 // 15%
    }
  },
  bankInfo: {
    accountHolder: String,
    accountNumber: String,
    routingNumber: String,
    bankName: String
  },
  documents: [{
    type: {
      type: String,
      enum: ['license', 'permit', 'certificate', 'other']
    },
    name: String,
    url: String,
    expiryDate: Date,
    isVerified: {
      type: Boolean,
      default: false
    }
  }],
  verificationStatus: {
    type: String,
    enum: ['pending', 'verified', 'rejected'],
    default: 'pending'
  },
  statistics: {
    totalOrders: {
      type: Number,
      default: 0
    },
    totalRevenue: {
      type: Number,
      default: 0
    },
    averageOrderValue: {
      type: Number,
      default: 0
    },
    popularItems: [{
      itemId: mongoose.Schema.Types.ObjectId,
      count: Number
    }]
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Create indexes for frequently queried fields
restaurantSchema.index({ 'address.coordinates': '2dsphere' });
restaurantSchema.index({ cuisine: 1 });
restaurantSchema.index({ 'rating.average': -1 });
restaurantSchema.index({ isActive: 1, isOpen: 1 });
restaurantSchema.index({ owner: 1 });
restaurantSchema.index({ name: 'text', 'menu.name': 'text', cuisine: 'text' });

// Update updatedAt timestamp
restaurantSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Calculate average rating when a review is added or updated
restaurantSchema.pre('save', function(next) {
  if (this.isModified('reviews')) {
    const totalRating = this.reviews.reduce((sum, review) => sum + review.rating, 0);
    this.rating.average = this.reviews.length > 0 ? totalRating / this.reviews.length : 0;
    this.rating.count = this.reviews.length;
  }
  next();
});

// Virtual for checking if restaurant is currently open
restaurantSchema.virtual('isCurrentlyOpen').get(function() {
  if (!this.isActive || this.isPaused) return false;
  
  const now = new Date();
  const day = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][now.getDay()];
  const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  
  const todayHours = this.operatingHours.find(hours => hours.day === day);
  if (!todayHours || !todayHours.isOpen) return false;
  
  return currentTime >= todayHours.open && currentTime <= todayHours.close;
});

const Restaurant = mongoose.model('Restaurant', restaurantSchema);

module.exports = Restaurant;