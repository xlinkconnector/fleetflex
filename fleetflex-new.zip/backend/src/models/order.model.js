const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  orderNumber: {
    type: String,
    unique: true,
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  serviceType: {
    type: String,
    enum: ['food', 'ride', 'shipping', 'moving', 'freight'],
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'in_progress', 'picked_up', 'in_transit', 'delivered', 'completed', 'cancelled', 'refunded'],
    default: 'pending'
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed', 'refunded'],
    default: 'pending'
  },
  paymentMethod: {
    type: String,
    enum: ['card', 'cash', 'wallet', 'paypal'],
    required: true
  },
  paymentDetails: {
    transactionId: String,
    amount: Number,
    currency: { type: String, default: 'USD' },
    paymentIntentId: String,
    paymentDate: Date
  },
  
  // Food delivery specific fields
  restaurant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant'
  },
  items: [{
    name: String,
    price: Number,
    quantity: Number,
    options: [{
      name: String,
      choice: String,
      price: Number
    }],
    specialInstructions: String,
    subtotal: Number
  }],
  
  // Ride specific fields
  ride: {
    pickupLocation: {
      address: String,
      coordinates: {
        lat: Number,
        lng: Number
      }
    },
    dropoffLocation: {
      address: String,
      coordinates: {
        lat: Number,
        lng: Number
      }
    },
    distance: Number, // in kilometers
    duration: Number, // in minutes
    rideType: {
      type: String,
      enum: ['economy', 'comfort', 'premium', 'xl']
    }
  },
  
  // Shipping specific fields
  shipping: {
    packageDetails: {
      weight: Number, // in kg
      dimensions: {
        length: Number,
        width: Number,
        height: Number
      },
      description: String,
      value: Number,
      isFragile: Boolean
    },
    pickupLocation: {
      address: String,
      coordinates: {
        lat: Number,
        lng: Number
      },
      contactName: String,
      contactPhone: String
    },
    deliveryLocation: {
      address: String,
      coordinates: {
        lat: Number,
        lng: Number
      },
      contactName: String,
      contactPhone: String
    },
    trackingNumber: String,
    estimatedDeliveryDate: Date
  },
  
  // Moving specific fields
  moving: {
    propertySize: String,
    moveDate: Date,
    startTime: String,
    inventory: [{
      item: String,
      quantity: Number,
      isFragile: Boolean,
      specialHandling: Boolean,
      notes: String
    }],
    originAddress: {
      address: String,
      coordinates: {
        lat: Number,
        lng: Number
      },
      floor: Number,
      hasElevator: Boolean,
      parkingAvailable: Boolean
    },
    destinationAddress: {
      address: String,
      coordinates: {
        lat: Number,
        lng: Number
      },
      floor: Number,
      hasElevator: Boolean,
      parkingAvailable: Boolean
    },
    additionalServices: [{
      type: String,
      price: Number
    }],
    crewSize: Number
  },
  
  // Freight specific fields
  freight: {
    cargoType: String,
    weight: Number, // in kg
    volume: Number, // in cubic meters
    pickupDate: Date,
    deliveryDate: Date,
    originAddress: {
      address: String,
      coordinates: {
        lat: Number,
        lng: Number
      },
      contactName: String,
      contactPhone: String
    },
    destinationAddress: {
      address: String,
      coordinates: {
        lat: Number,
        lng: Number
      },
      contactName: String,
      contactPhone: String
    },
    specialRequirements: String,
    hazardousMaterials: Boolean,
    temperatureControlled: Boolean,
    insurance: {
      isInsured: Boolean,
      coverageAmount: Number,
      provider: String
    }
  },
  
  // Common fields for all order types
  driver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  vehicle: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Vehicle'
  },
  pricing: {
    subtotal: Number,
    tax: Number,
    deliveryFee: Number,
    serviceFee: Number,
    discount: Number,
    tip: Number,
    total: Number
  },
  promoCode: {
    code: String,
    discount: Number,
    type: {
      type: String,
      enum: ['percentage', 'fixed']
    }
  },
  estimatedTime: Number, // in minutes
  actualTime: Number, // in minutes
  rating: {
    value: { type: Number, min: 1, max: 5 },
    comment: String,
    createdAt: Date
  },
  tracking: [{
    status: String,
    location: {
      lat: Number,
      lng: Number,
      address: String
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    notes: String
  }],
  notes: String,
  cancellation: {
    reason: String,
    cancelledBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    refundAmount: Number,
    cancelledAt: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Create indexes for frequently queried fields
orderSchema.index({ orderNumber: 1 });
orderSchema.index({ user: 1 });
orderSchema.index({ driver: 1 });
orderSchema.index({ restaurant: 1 });
orderSchema.index({ status: 1 });
orderSchema.index({ serviceType: 1 });
orderSchema.index({ createdAt: -1 });
orderSchema.index({ 'ride.pickupLocation.coordinates': '2dsphere' });
orderSchema.index({ 'ride.dropoffLocation.coordinates': '2dsphere' });
orderSchema.index({ 'shipping.pickupLocation.coordinates': '2dsphere' });
orderSchema.index({ 'shipping.deliveryLocation.coordinates': '2dsphere' });

// Generate unique order number
orderSchema.pre('save', async function(next) {
  if (this.isNew) {
    const date = new Date();
    const year = date.getFullYear().toString().slice(-2);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    
    // Get service type prefix
    let prefix = '';
    switch (this.serviceType) {
      case 'food': prefix = 'FD'; break;
      case 'ride': prefix = 'RD'; break;
      case 'shipping': prefix = 'SH'; break;
      case 'moving': prefix = 'MV'; break;
      case 'freight': prefix = 'FR'; break;
      default: prefix = 'OR';
    }
    
    // Get count of orders for today
    const count = await this.constructor.countDocuments({
      createdAt: {
        $gte: new Date(date.setHours(0, 0, 0, 0)),
        $lt: new Date(date.setHours(23, 59, 59, 999))
      }
    });
    
    // Generate order number: PREFIX-YYMMDD-COUNT
    this.orderNumber = `${prefix}${year}${month}${day}${String(count + 1).padStart(4, '0')}`;
  }
  next();
});

// Update updatedAt timestamp
orderSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// Add tracking entry when status changes
orderSchema.pre('save', function(next) {
  if (this.isModified('status')) {
    this.tracking.push({
      status: this.status,
      timestamp: Date.now(),
      notes: `Order status updated to ${this.status}`
    });
  }
  next();
});

const Order = mongoose.model('Order', orderSchema);

module.exports = Order;