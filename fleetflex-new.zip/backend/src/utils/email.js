const nodemailer = require('nodemailer');
const fs = require('fs').promises;
const path = require('path');
const handlebars = require('handlebars');

/**
 * Email templates
 */
const templates = {
  emailVerification: {
    subject: 'Please verify your email address',
    filename: 'email-verification.html'
  },
  passwordReset: {
    subject: 'Password Reset Request',
    filename: 'password-reset.html'
  },
  orderConfirmation: {
    subject: 'Order Confirmation',
    filename: 'order-confirmation.html'
  },
  orderUpdate: {
    subject: 'Order Status Update',
    filename: 'order-update.html'
  },
  welcome: {
    subject: 'Welcome to FleetFlex',
    filename: 'welcome.html'
  }
};

/**
 * Send email using nodemailer
 * @param {Object} options - Email options
 * @param {string} options.email - Recipient email
 * @param {string} options.subject - Email subject
 * @param {string} options.template - Template name
 * @param {Object} options.data - Template data
 * @returns {Promise} Nodemailer send result
 */
const sendEmail = async options => {
  try {
    // 1) Create transporter
    const transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST || 'smtp.mailtrap.io',
      port: process.env.EMAIL_PORT || 2525,
      auth: {
        user: process.env.EMAIL_USERNAME,
        pass: process.env.EMAIL_PASSWORD
      }
    });

    // 2) Get template
    const template = templates[options.template];
    if (!template) {
      throw new Error(`Email template '${options.template}' not found`);
    }

    // 3) Read template file
    let html;
    try {
      const templatePath = path.join(__dirname, '../templates/emails', template.filename);
      const templateSource = await fs.readFile(templatePath, 'utf-8');
      const compiledTemplate = handlebars.compile(templateSource);
      html = compiledTemplate(options.data);
    } catch (err) {
      // Fallback to basic HTML if template not found
      html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #4f46e5; color: white; padding: 20px; text-align: center;">
            <h1>FleetFlex</h1>
          </div>
          <div style="padding: 20px; background-color: #f9fafb; border-radius: 0 0 5px 5px;">
            <h2>${options.subject}</h2>
            <p>Hello ${options.data.name || 'there'},</p>
            ${options.data.content || ''}
            ${options.data.url ? `<p><a href="${options.data.url}" style="display: inline-block; background-color: #4f46e5; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Click here</a></p>` : ''}
            <p>Thank you,<br>The FleetFlex Team</p>
          </div>
          <div style="text-align: center; padding: 10px; color: #6b7280; font-size: 12px;">
            <p>&copy; ${new Date().getFullYear()} FleetFlex. All rights reserved.</p>
          </div>
        </div>
      `;
    }

    // 4) Define email options
    const mailOptions = {
      from: process.env.EMAIL_FROM || 'FleetFlex <noreply@fleetflex.com>',
      to: options.email,
      subject: options.subject || template.subject,
      html
    };

    // 5) Send email
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent: %s', info.messageId);
    return info;
  } catch (error) {
    console.error('Email error:', error);
    throw error;
  }
};

module.exports = sendEmail;