const jwt = require('jsonwebtoken');
const { promisify } = require('util');
const User = require('../models/user.model');
const AppError = require('../utils/appError');
const catchAsync = require('../utils/catchAsync');

/**
 * Middleware to protect routes - requires authentication
 */
exports.protect = catchAsync(async (req, res, next) => {
  // 1) Get token
  let token;
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.jwt) {
    token = req.cookies.jwt;
  }

  if (!token) {
    return next(new AppError('You are not logged in. Please log in to get access.', 401));
  }

  // 2) Verify token
  const decoded = await promisify(jwt.verify)(
    token,
    process.env.JWT_SECRET || 'fleetflex-secret-key'
  );

  // 3) Check if user still exists
  const user = await User.findById(decoded.id);
  if (!user) {
    return next(new AppError('The user belonging to this token no longer exists.', 401));
  }

  // 4) Check if user is active
  if (!user.isActive) {
    return next(new AppError('This user account has been deactivated.', 401));
  }

  // 5) Grant access to protected route
  req.user = user;
  next();
});

/**
 * Middleware to restrict access to specific roles
 * @param {...string} roles - Allowed roles
 * @returns {Function} Express middleware
 */
exports.restrictTo = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return next(new AppError('You do not have permission to perform this action', 403));
    }
    next();
  };
};

/**
 * Middleware to check if user is verified
 */
exports.isVerified = catchAsync(async (req, res, next) => {
  if (!req.user.isVerified) {
    return next(new AppError('Please verify your email address before proceeding.', 403));
  }
  next();
});

/**
 * Middleware for optional authentication
 * If token exists and is valid, attaches user to req object
 * If not, continues without error
 */
exports.optionalAuth = catchAsync(async (req, res, next) => {
  // 1) Get token
  let token;
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.jwt) {
    token = req.cookies.jwt;
  }

  if (!token) {
    return next();
  }

  try {
    // 2) Verify token
    const decoded = await promisify(jwt.verify)(
      token,
      process.env.JWT_SECRET || 'fleetflex-secret-key'
    );

    // 3) Check if user still exists
    const user = await User.findById(decoded.id);
    if (!user || !user.isActive) {
      return next();
    }

    // 4) Attach user to request
    req.user = user;
    next();
  } catch (err) {
    // Continue without user
    next();
  }
});

/**
 * Middleware to check if user owns the resource or is admin
 * @param {string} modelName - Name of the model to check ownership
 * @param {string} paramName - Name of the parameter containing the resource ID
 */
exports.checkOwnership = (modelName, paramName = 'id') => {
  return catchAsync(async (req, res, next) => {
    // Skip check for admins
    if (req.user.role === 'admin') {
      return next();
    }

    const Model = require(`../models/${modelName}.model`);
    const resourceId = req.params[paramName];
    
    const resource = await Model.findById(resourceId);
    
    if (!resource) {
      return next(new AppError('Resource not found', 404));
    }
    
    // Check if user owns the resource
    const ownerId = resource.owner || resource.user;
    
    if (!ownerId || !ownerId.equals(req.user._id)) {
      return next(new AppError('You do not have permission to perform this action', 403));
    }
    
    next();
  });
};