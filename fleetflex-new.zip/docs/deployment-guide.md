# FleetFlex Deployment Guide

This comprehensive guide outlines the process for deploying the FleetFlex multi-service logistics platform in various environments, from development to production.

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Architecture Overview](#architecture-overview)
3. [Deployment Options](#deployment-options)
4. [Environment Setup](#environment-setup)
5. [Database Setup](#database-setup)
6. [Backend Deployment](#backend-deployment)
7. [Frontend Deployment](#frontend-deployment)
8. [Admin Dashboard Deployment](#admin-dashboard-deployment)
9. [Mobile App Deployment](#mobile-app-deployment)
10. [Nginx Configuration](#nginx-configuration)
11. [SSL/TLS Setup](#ssltls-setup)
12. [Docker Deployment](#docker-deployment)
13. [Kubernetes Deployment](#kubernetes-deployment)
14. [CI/CD Pipeline](#cicd-pipeline)
15. [Monitoring and Logging](#monitoring-and-logging)
16. [Backup and Recovery](#backup-and-recovery)
17. [Scaling Strategies](#scaling-strategies)
18. [Security Best Practices](#security-best-practices)
19. [Troubleshooting](#troubleshooting)
20. [Maintenance Procedures](#maintenance-procedures)

## System Requirements

### Minimum Requirements

- **CPU**: 4 cores
- **RAM**: 8GB
- **Storage**: 50GB SSD
- **Network**: 100Mbps connection
- **OS**: Ubuntu 20.04 LTS or later, CentOS 8+, or any modern Linux distribution

### Recommended Requirements

- **CPU**: 8+ cores
- **RAM**: 16GB+
- **Storage**: 100GB+ SSD
- **Network**: 1Gbps connection
- **OS**: Ubuntu 22.04 LTS

### Software Requirements

- **Node.js**: v18.x or later
- **MongoDB**: v6.0 or later
- **Redis**: v7.0 or later
- **Docker**: v20.10 or later
- **Docker Compose**: v2.0 or later
- **Nginx**: v1.20 or later
- **Let's Encrypt**: For SSL certificates

## Architecture Overview

FleetFlex follows a microservices architecture with the following components:

```
┌─────────────────────────────────────────┐
│              Load Balancer              │
│              (Nginx/HAProxy)            │
└─────────────────┬───────────────────────┘
                  │
    ┌─────────────┴─────────────┐
    │                           │
┌───▼───┐   ┌───▼───┐   ┌───▼───┐
│  API  │   │Admin  │   │  Web  │
│Gateway│   │Service│   │  App  │
└───┬───┘   └───┬───┘   └───┬───┘
    │           │           │
┌───┴───────────┴───────────┴───┐
│         Database Layer         │
│  MongoDB + Redis + Cloudinary  │
└────────────────────────────────┘
```

## Deployment Options

FleetFlex can be deployed using several methods:

1. **Traditional Deployment**: Manual setup on VMs or bare metal
2. **Docker Deployment**: Using Docker and Docker Compose
3. **Kubernetes Deployment**: For large-scale, highly available deployments
4. **Cloud Provider Deployment**: AWS, Google Cloud, or Azure

This guide primarily focuses on Docker-based deployment, which is recommended for most use cases.

## Environment Setup

### Environment Variables

Create a `.env` file in the root directory with the following variables:

```bash
# Application
NODE_ENV=production
PORT=5000

# MongoDB
MONGODB_URI=mongodb://username:password@mongodb:27017/fleetflex?authSource=admin

# Redis
REDIS_URL=redis://redis:6379

# JWT
JWT_SECRET=your_jwt_secret_key_change_this_in_production
JWT_EXPIRES_IN=1d
REFRESH_TOKEN_SECRET=your_refresh_token_secret_key_change_this_in_production
REFRESH_TOKEN_EXPIRES_IN=7d

# Email
EMAIL_HOST=smtp.example.com
EMAIL_PORT=587
EMAIL_USERNAME=your_email@example.com
EMAIL_PASSWORD=your_email_password
EMAIL_FROM=FleetFlex <noreply@fleetflex.com>

# Stripe
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret

# Cloudinary
CLOUDINARY_CLOUD_NAME=your_cloudinary_cloud_name
CLOUDINARY_API_KEY=your_cloudinary_api_key
CLOUDINARY_API_SECRET=your_cloudinary_api_secret

# Google Maps
GOOGLE_MAPS_API_KEY=your_google_maps_api_key

# Frontend URLs
FRONTEND_URL=https://fleetflex.com
ADMIN_URL=https://admin.fleetflex.com
API_URL=https://api.fleetflex.com
```

### Directory Structure

Ensure your deployment directory is structured as follows:

```
fleetflex/
├── backend/
├── frontend/
├── admin/
├── mobile/
├── nginx/
│   ├── conf.d/
│   └── ssl/
├── .env
├── docker-compose.yml
└── docker-compose.prod.yml
```

## Database Setup

### MongoDB Setup

#### Using Docker

MongoDB is included in the Docker Compose configuration. For production, consider using MongoDB Atlas or a managed MongoDB service.

#### Manual Setup

1. Install MongoDB:
   ```bash
   sudo apt update
   sudo apt install -y mongodb
   ```

2. Create database and user:
   ```bash
   mongo
   > use fleetflex
   > db.createUser({
       user: "fleetflex_user",
       pwd: "secure_password",
       roles: [{ role: "readWrite", db: "fleetflex" }]
     })
   ```

3. Enable authentication in `/etc/mongod.conf`:
   ```yaml
   security:
     authorization: enabled
   ```

4. Restart MongoDB:
   ```bash
   sudo systemctl restart mongod
   ```

### Redis Setup

#### Using Docker

Redis is included in the Docker Compose configuration.

#### Manual Setup

1. Install Redis:
   ```bash
   sudo apt update
   sudo apt install -y redis-server
   ```

2. Configure Redis in `/etc/redis/redis.conf`:
   ```
   bind 127.0.0.1
   requirepass your_redis_password
   ```

3. Restart Redis:
   ```bash
   sudo systemctl restart redis
   ```

## Backend Deployment

### Using Docker (Recommended)

1. Navigate to the project directory:
   ```bash
   cd fleetflex
   ```

2. Build and start the backend service:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d backend
   ```

### Manual Deployment

1. Install Node.js:
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt install -y nodejs
   ```

2. Navigate to the backend directory:
   ```bash
   cd fleetflex/backend
   ```

3. Install dependencies:
   ```bash
   npm install --production
   ```

4. Start the server:
   ```bash
   npm start
   ```

5. For production, use a process manager like PM2:
   ```bash
   npm install -g pm2
   pm2 start src/server.js --name fleetflex-backend
   pm2 save
   pm2 startup
   ```

## Frontend Deployment

### Using Docker (Recommended)

1. Build and start the frontend service:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d frontend
   ```

### Manual Deployment

1. Navigate to the frontend directory:
   ```bash
   cd fleetflex/frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Build the production bundle:
   ```bash
   npm run build
   ```

4. Serve the built files using Nginx:
   ```bash
   sudo cp -r dist/* /var/www/fleetflex/
   ```

## Admin Dashboard Deployment

### Using Docker (Recommended)

1. Build and start the admin service:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d admin
   ```

### Manual Deployment

1. Navigate to the admin directory:
   ```bash
   cd fleetflex/admin
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Build the production bundle:
   ```bash
   npm run build
   ```

4. Serve the built files using Nginx:
   ```bash
   sudo cp -r dist/* /var/www/admin.fleetflex/
   ```

## Mobile App Deployment

### iOS App

1. Navigate to the mobile directory:
   ```bash
   cd fleetflex/mobile
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Install iOS dependencies:
   ```bash
   cd ios && pod install && cd ..
   ```

4. Build the iOS app:
   ```bash
   npm run build:ios
   ```

5. Archive and upload to App Store Connect using Xcode.

### Android App

1. Navigate to the mobile directory:
   ```bash
   cd fleetflex/mobile
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Build the Android app:
   ```bash
   npm run build:android
   ```

4. Sign the APK and upload to Google Play Console.

## Nginx Configuration

### Main Configuration

Create a file at `nginx/nginx.conf`:

```nginx
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
    multi_accept on;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    access_log /var/log/nginx/access.log main;

    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;

    gzip on;
    gzip_disable "msie6";
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_buffers 16 8k;
    gzip_http_version 1.1;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    include /etc/nginx/conf.d/*.conf;
}
```

### Site Configuration

Create a file at `nginx/conf.d/default.conf`:

```nginx
server {
    listen 80;
    server_name fleetflex.com www.fleetflex.com;
    
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name fleetflex.com www.fleetflex.com;
    
    ssl_certificate /etc/nginx/ssl/fleetflex.crt;
    ssl_certificate_key /etc/nginx/ssl/fleetflex.key;
    
    location / {
        proxy_pass http://frontend:80;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}

server {
    listen 80;
    server_name admin.fleetflex.com;
    
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name admin.fleetflex.com;
    
    ssl_certificate /etc/nginx/ssl/fleetflex.crt;
    ssl_certificate_key /etc/nginx/ssl/fleetflex.key;
    
    location / {
        proxy_pass http://admin:80;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}

server {
    listen 80;
    server_name api.fleetflex.com;
    
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name api.fleetflex.com;
    
    ssl_certificate /etc/nginx/ssl/fleetflex.crt;
    ssl_certificate_key /etc/nginx/ssl/fleetflex.key;
    
    location / {
        proxy_pass http://backend:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /socket.io/ {
        proxy_pass http://backend:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## SSL/TLS Setup

### Using Let's Encrypt (Recommended)

1. Install Certbot:
   ```bash
   sudo apt update
   sudo apt install -y certbot python3-certbot-nginx
   ```

2. Obtain certificates:
   ```bash
   sudo certbot --nginx -d fleetflex.com -d www.fleetflex.com -d api.fleetflex.com -d admin.fleetflex.com
   ```

3. Set up auto-renewal:
   ```bash
   sudo systemctl enable certbot.timer
   sudo systemctl start certbot.timer
   ```

### Using Self-Signed Certificates (Development Only)

1. Generate self-signed certificates:
   ```bash
   mkdir -p nginx/ssl
   openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
     -keyout nginx/ssl/fleetflex.key \
     -out nginx/ssl/fleetflex.crt \
     -subj "/C=US/ST=State/L=City/O=FleetFlex/CN=fleetflex.com"
   ```

## Docker Deployment

### Docker Compose Configuration

Create a file at `docker-compose.prod.yml`:

```yaml
version: '3.8'

services:
  # Backend API
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: fleetflex-backend
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - MONGODB_URI=${MONGODB_URI}
      - REDIS_URL=${REDIS_URL}
      - JWT_SECRET=${JWT_SECRET}
      - JWT_EXPIRES_IN=${JWT_EXPIRES_IN}
      - REFRESH_TOKEN_SECRET=${REFRESH_TOKEN_SECRET}
      - REFRESH_TOKEN_EXPIRES_IN=${REFRESH_TOKEN_EXPIRES_IN}
      - EMAIL_HOST=${EMAIL_HOST}
      - EMAIL_PORT=${EMAIL_PORT}
      - EMAIL_USERNAME=${EMAIL_USERNAME}
      - EMAIL_PASSWORD=${EMAIL_PASSWORD}
      - EMAIL_FROM=${EMAIL_FROM}
      - STRIPE_SECRET_KEY=${STRIPE_SECRET_KEY}
      - STRIPE_WEBHOOK_SECRET=${STRIPE_WEBHOOK_SECRET}
      - CLOUDINARY_CLOUD_NAME=${CLOUDINARY_CLOUD_NAME}
      - CLOUDINARY_API_KEY=${CLOUDINARY_API_KEY}
      - CLOUDINARY_API_SECRET=${CLOUDINARY_API_SECRET}
    volumes:
      - ./backend/uploads:/app/uploads
      - ./backend/logs:/app/logs
    depends_on:
      - mongodb
      - redis
    networks:
      - fleetflex-network

  # Frontend Web App
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
      args:
        - VITE_API_URL=${API_URL}
        - VITE_STRIPE_PUBLISHABLE_KEY=${STRIPE_PUBLISHABLE_KEY}
        - VITE_GOOGLE_MAPS_API_KEY=${GOOGLE_MAPS_API_KEY}
    container_name: fleetflex-frontend
    restart: unless-stopped
    depends_on:
      - backend
    networks:
      - fleetflex-network

  # Admin Dashboard
  admin:
    build:
      context: ./admin
      dockerfile: Dockerfile
      args:
        - VITE_API_URL=${API_URL}
        - VITE_STRIPE_PUBLISHABLE_KEY=${STRIPE_PUBLISHABLE_KEY}
        - VITE_GOOGLE_MAPS_API_KEY=${GOOGLE_MAPS_API_KEY}
    container_name: fleetflex-admin
    restart: unless-stopped
    depends_on:
      - backend
    networks:
      - fleetflex-network

  # MongoDB Database
  mongodb:
    image: mongo:6.0
    container_name: fleetflex-mongodb
    restart: unless-stopped
    environment:
      - MONGO_INITDB_ROOT_USERNAME=${MONGO_USERNAME}
      - MONGO_INITDB_ROOT_PASSWORD=${MONGO_PASSWORD}
    volumes:
      - mongodb_data:/data/db
    networks:
      - fleetflex-network

  # Redis Cache
  redis:
    image: redis:7-alpine
    container_name: fleetflex-redis
    restart: unless-stopped
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
    networks:
      - fleetflex-network

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: fleetflex-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./nginx/conf.d:/etc/nginx/conf.d
      - ./nginx/ssl:/etc/nginx/ssl
      - ./nginx/logs:/var/log/nginx
    depends_on:
      - backend
      - frontend
      - admin
    networks:
      - fleetflex-network

volumes:
  mongodb_data:
  redis_data:

networks:
  fleetflex-network:
    driver: bridge
```

### Deployment Steps

1. Create the necessary directories:
   ```bash
   mkdir -p nginx/conf.d nginx/ssl nginx/logs
   ```

2. Copy the Nginx configuration files to the appropriate directories.

3. Deploy the stack:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d
   ```

4. Check the status:
   ```bash
   docker-compose -f docker-compose.prod.yml ps
   ```

5. View logs:
   ```bash
   docker-compose -f docker-compose.prod.yml logs -f
   ```

## Kubernetes Deployment

For large-scale deployments, Kubernetes provides better scalability and management capabilities.

### Prerequisites

- Kubernetes cluster (e.g., EKS, GKE, AKS, or self-hosted)
- kubectl configured to access your cluster
- Helm (optional, for package management)

### Deployment Steps

1. Create namespace:
   ```bash
   kubectl create namespace fleetflex
   ```

2. Create ConfigMap and Secrets:
   ```bash
   kubectl create configmap fleetflex-config --from-env-file=.env -n fleetflex
   kubectl create secret generic fleetflex-secrets --from-literal=JWT_SECRET=your_jwt_secret --from-literal=MONGODB_URI=your_mongodb_uri -n fleetflex
   ```

3. Apply Kubernetes manifests:
   ```bash
   kubectl apply -f k8s/mongodb.yaml -n fleetflex
   kubectl apply -f k8s/redis.yaml -n fleetflex
   kubectl apply -f k8s/backend.yaml -n fleetflex
   kubectl apply -f k8s/frontend.yaml -n fleetflex
   kubectl apply -f k8s/admin.yaml -n fleetflex
   kubectl apply -f k8s/ingress.yaml -n fleetflex
   ```

4. Check deployment status:
   ```bash
   kubectl get pods -n fleetflex
   ```

## CI/CD Pipeline

### GitHub Actions

Create a file at `.github/workflows/deploy.yml`:

```yaml
name: Deploy FleetFlex

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v2
      
      - name: Login to DockerHub
        uses: docker/login-action@v2
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}
      
      - name: Build and push backend
        uses: docker/build-push-action@v4
        with:
          context: ./backend
          push: true
          tags: yourusername/fleetflex-backend:latest
      
      - name: Build and push frontend
        uses: docker/build-push-action@v4
        with:
          context: ./frontend
          push: true
          tags: yourusername/fleetflex-frontend:latest
      
      - name: Build and push admin
        uses: docker/build-push-action@v4
        with:
          context: ./admin
          push: true
          tags: yourusername/fleetflex-admin:latest
      
      - name: Deploy to server
        uses: appleboy/ssh-action@master
        with:
          host: ${{ secrets.SSH_HOST }}
          username: ${{ secrets.SSH_USERNAME }}
          key: ${{ secrets.SSH_PRIVATE_KEY }}
          script: |
            cd /opt/fleetflex
            docker-compose pull
            docker-compose -f docker-compose.prod.yml up -d
```

## Monitoring and Logging

### Prometheus and Grafana

1. Add Prometheus and Grafana to your Docker Compose file:
   ```yaml
   prometheus:
     image: prom/prometheus
     container_name: prometheus
     volumes:
       - ./prometheus:/etc/prometheus
       - prometheus_data:/prometheus
     command:
       - '--config.file=/etc/prometheus/prometheus.yml'
     networks:
       - fleetflex-network

   grafana:
     image: grafana/grafana
     container_name: grafana
     volumes:
       - grafana_data:/var/lib/grafana
     environment:
       - GF_SECURITY_ADMIN_PASSWORD=admin_password
     ports:
       - "3000:3000"
     networks:
       - fleetflex-network
   ```

2. Create a Prometheus configuration file at `prometheus/prometheus.yml`:
   ```yaml
   global:
     scrape_interval: 15s

   scrape_configs:
     - job_name: 'prometheus'
       static_configs:
         - targets: ['localhost:9090']

     - job_name: 'backend'
       static_configs:
         - targets: ['backend:5000']
   ```

### ELK Stack (Elasticsearch, Logstash, Kibana)

1. Add ELK stack to your Docker Compose file:
   ```yaml
   elasticsearch:
     image: docker.elastic.co/elasticsearch/elasticsearch:7.17.0
     container_name: elasticsearch
     environment:
       - discovery.type=single-node
     volumes:
       - elasticsearch_data:/usr/share/elasticsearch/data
     networks:
       - fleetflex-network

   logstash:
     image: docker.elastic.co/logstash/logstash:7.17.0
     container_name: logstash
     volumes:
       - ./logstash/pipeline:/usr/share/logstash/pipeline
     depends_on:
       - elasticsearch
     networks:
       - fleetflex-network

   kibana:
     image: docker.elastic.co/kibana/kibana:7.17.0
     container_name: kibana
     ports:
       - "5601:5601"
     depends_on:
       - elasticsearch
     networks:
       - fleetflex-network
   ```

2. Create a Logstash pipeline configuration at `logstash/pipeline/logstash.conf`:
   ```
   input {
     file {
       path => "/var/log/nginx/access.log"
       type => "nginx-access"
     }
     file {
       path => "/var/log/nginx/error.log"
       type => "nginx-error"
     }
   }

   output {
     elasticsearch {
       hosts => ["elasticsearch:9200"]
       index => "fleetflex-logs-%{+YYYY.MM.dd}"
     }
   }
   ```

## Backup and Recovery

### Database Backup

1. Create a backup script at `scripts/backup.sh`:
   ```bash
   #!/bin/bash
   
   # Set variables
   BACKUP_DIR="/backups/mongodb"
   DATE=$(date +%Y%m%d_%H%M%S)
   MONGODB_HOST="mongodb"
   MONGODB_PORT="27017"
   MONGODB_USER="fleetflex_user"
   MONGODB_PASSWORD="secure_password"
   MONGODB_DATABASE="fleetflex"
   
   # Create backup directory if it doesn't exist
   mkdir -p $BACKUP_DIR
   
   # Perform backup
   mongodump --host $MONGODB_HOST --port $MONGODB_PORT \
     --username $MONGODB_USER --password $MONGODB_PASSWORD \
     --authenticationDatabase admin \
     --db $MONGODB_DATABASE \
     --out $BACKUP_DIR/$DATE
   
   # Compress backup
   tar -czf $BACKUP_DIR/$DATE.tar.gz -C $BACKUP_DIR $DATE
   
   # Remove uncompressed backup
   rm -rf $BACKUP_DIR/$DATE
   
   # Remove backups older than 7 days
   find $BACKUP_DIR -name "*.tar.gz" -type f -mtime +7 -delete
   
   echo "Backup completed: $BACKUP_DIR/$DATE.tar.gz"
   ```

2. Make the script executable:
   ```bash
   chmod +x scripts/backup.sh
   ```

3. Set up a cron job to run the backup script daily:
   ```bash
   0 2 * * * /opt/fleetflex/scripts/backup.sh >> /var/log/fleetflex-backup.log 2>&1
   ```

### Database Restoration

1. Create a restore script at `scripts/restore.sh`:
   ```bash
   #!/bin/bash
   
   # Set variables
   BACKUP_FILE=$1
   MONGODB_HOST="mongodb"
   MONGODB_PORT="27017"
   MONGODB_USER="fleetflex_user"
   MONGODB_PASSWORD="secure_password"
   MONGODB_DATABASE="fleetflex"
   
   # Check if backup file is provided
   if [ -z "$BACKUP_FILE" ]; then
     echo "Usage: $0 <backup_file>"
     exit 1
   fi
   
   # Check if backup file exists
   if [ ! -f "$BACKUP_FILE" ]; then
     echo "Backup file not found: $BACKUP_FILE"
     exit 1
   fi
   
   # Create temporary directory
   TEMP_DIR=$(mktemp -d)
   
   # Extract backup
   tar -xzf $BACKUP_FILE -C $TEMP_DIR
   
   # Restore backup
   mongorestore --host $MONGODB_HOST --port $MONGODB_PORT \
     --username $MONGODB_USER --password $MONGODB_PASSWORD \
     --authenticationDatabase admin \
     --db $MONGODB_DATABASE \
     $TEMP_DIR/*/fleetflex
   
   # Remove temporary directory
   rm -rf $TEMP_DIR
   
   echo "Restoration completed from: $BACKUP_FILE"
   ```

2. Make the script executable:
   ```bash
   chmod +x scripts/restore.sh
   ```

3. To restore from a backup:
   ```bash
   ./scripts/restore.sh /backups/mongodb/20230623_020000.tar.gz
   ```

## Scaling Strategies

### Horizontal Scaling

1. Backend Scaling:
   - Add more backend instances behind a load balancer
   - Update Docker Compose to scale the backend service:
     ```bash
     docker-compose -f docker-compose.prod.yml up -d --scale backend=3
     ```

2. Database Scaling:
   - Set up MongoDB replica sets for high availability
   - Consider MongoDB sharding for horizontal scaling

3. Redis Scaling:
   - Implement Redis Sentinel for high availability
   - Consider Redis Cluster for horizontal scaling

### Vertical Scaling

1. Increase resources for existing instances:
   - Upgrade CPU, memory, and storage
   - Update Docker Compose resource limits:
     ```yaml
     services:
       backend:
         deploy:
           resources:
             limits:
               cpus: '2'
               memory: 2G
     ```

## Security Best Practices

### Network Security

1. Use a firewall to restrict access:
   ```bash
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   sudo ufw allow 22/tcp
   sudo ufw enable
   ```

2. Set up a VPN for administrative access.

3. Use private networks for internal communication.

### Application Security

1. Keep dependencies updated:
   ```bash
   npm audit fix
   ```

2. Implement rate limiting and request validation.

3. Use HTTPS for all communications.

4. Implement proper authentication and authorization.

5. Sanitize user inputs to prevent injection attacks.

### Data Security

1. Encrypt sensitive data at rest and in transit.

2. Implement regular security audits and penetration testing.

3. Follow the principle of least privilege for database users.

4. Regularly rotate secrets and credentials.

## Troubleshooting

### Common Issues

1. **Connection Refused**:
   - Check if the service is running: `docker-compose ps`
   - Check if the port is exposed: `netstat -tulpn | grep <port>`
   - Check firewall rules: `sudo ufw status`

2. **Database Connection Issues**:
   - Check MongoDB connection string
   - Verify MongoDB is running: `docker-compose logs mongodb`
   - Check MongoDB authentication: `mongo -u <username> -p <password> --authenticationDatabase admin`

3. **Application Errors**:
   - Check application logs: `docker-compose logs backend`
   - Verify environment variables: `docker-compose exec backend env`
   - Check for JavaScript errors in the browser console

### Debugging Tools

1. **Docker Logs**:
   ```bash
   docker-compose logs -f [service]
   ```

2. **Container Shell Access**:
   ```bash
   docker-compose exec [service] sh
   ```

3. **Database Shell**:
   ```bash
   docker-compose exec mongodb mongo -u fleetflex_user -p secure_password --authenticationDatabase admin fleetflex
   ```

4. **Network Debugging**:
   ```bash
   docker network inspect fleetflex-network
   ```

## Maintenance Procedures

### Regular Maintenance Tasks

1. **Update Dependencies**:
   ```bash
   cd backend && npm update
   cd ../frontend && npm update
   cd ../admin && npm update
   ```

2. **Backup Database**:
   ```bash
   ./scripts/backup.sh
   ```

3. **Check Disk Space**:
   ```bash
   df -h
   ```

4. **Clean Docker Resources**:
   ```bash
   docker system prune -a
   ```

5. **Rotate Logs**:
   ```bash
   logrotate /etc/logrotate.d/fleetflex
   ```

### Upgrade Procedures

1. **Backend Upgrade**:
   ```bash
   cd backend
   git pull
   npm install
   docker-compose -f docker-compose.prod.yml up -d --build backend
   ```

2. **Frontend Upgrade**:
   ```bash
   cd frontend
   git pull
   npm install
   docker-compose -f docker-compose.prod.yml up -d --build frontend
   ```

3. **Admin Dashboard Upgrade**:
   ```bash
   cd admin
   git pull
   npm install
   docker-compose -f docker-compose.prod.yml up -d --build admin
   ```

4. **Database Upgrade**:
   - Backup the database
   - Update the MongoDB image version in docker-compose.yml
   - Restart the MongoDB container

### Rollback Procedures

1. **Service Rollback**:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d --build <service> <previous_image_tag>
   ```

2. **Database Rollback**:
   ```bash
   ./scripts/restore.sh <backup_file>
   ```

## Conclusion

This deployment guide provides comprehensive instructions for deploying and maintaining the FleetFlex multi-service logistics platform. By following these guidelines, you can ensure a secure, scalable, and reliable deployment.

For additional support or questions, please contact the FleetFlex development team.