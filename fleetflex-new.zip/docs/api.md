# FleetFlex API Documentation

This document provides comprehensive documentation for the FleetFlex API, which powers the multi-service logistics platform including food delivery, rideshare, shipping, moving, and freight services.

## Base URL

```
https://api.fleetflex.com
```

For development:
```
http://localhost:5000
```

## Authentication

The FleetFlex API uses JWT (JSON Web Tokens) for authentication. Most endpoints require authentication.

### Authentication Headers

```
Authorization: Bearer <token>
```

### Authentication Endpoints

#### Register User

```
POST /api/auth/register
```

Create a new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+12345678901",
  "role": "customer" // Optional: "customer", "driver", "restaurant"
}
```

**Response:**
```json
{
  "success": true,
  "message": "User registered successfully. Please check your email to verify your account.",
  "data": {
    "user": {
      "id": "60d21b4667d0d8992e610c85",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "customer"
    }
  }
}
```

#### Login

```
POST /api/auth/login
```

Authenticate a user and get access token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "data": {
    "user": {
      "id": "60d21b4667d0d8992e610c85",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "customer",
      "isVerified": true
    }
  }
}
```

#### Refresh Token

```
POST /api/auth/refresh-token
```

Get a new access token using a refresh token.

**Request Body:**
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

#### Logout

```
POST /api/auth/logout
```

Invalidate the current user's tokens.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

#### Get Current User

```
GET /api/auth/me
```

Get the currently authenticated user's information.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "60d21b4667d0d8992e610c85",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "phone": "+12345678901",
      "role": "customer",
      "isVerified": true,
      "profile": {
        "avatar": "https://example.com/avatar.jpg",
        "address": {
          "street": "123 Main St",
          "city": "New York",
          "state": "NY",
          "zipCode": "10001",
          "country": "USA"
        },
        "preferences": {
          "language": "en",
          "currency": "USD",
          "notifications": {
            "email": true,
            "sms": true,
            "push": true
          }
        }
      },
      "createdAt": "2023-06-21T14:30:00.000Z",
      "updatedAt": "2023-06-21T14:30:00.000Z"
    }
  }
}
```

#### Forgot Password

```
POST /api/auth/forgot-password
```

Send a password reset email.

**Request Body:**
```json
{
  "email": "user@example.com"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Email sent successfully"
}
```

#### Reset Password

```
PATCH /api/auth/reset-password/:token
```

Reset password using a token received via email.

**Request Body:**
```json
{
  "password": "NewSecurePassword123!"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Password reset successful"
}
```

#### Verify Email

```
GET /api/auth/verify-email/:token
```

Verify a user's email address.

**Response:**
```json
{
  "success": true,
  "message": "Email verified successfully"
}
```

## User Management

### User Endpoints

#### Update User Profile

```
PATCH /api/users/profile
```

Update the current user's profile information.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Smith",
  "phone": "+12345678901",
  "profile": {
    "address": {
      "street": "456 Oak St",
      "city": "San Francisco",
      "state": "CA",
      "zipCode": "94103",
      "country": "USA"
    },
    "preferences": {
      "language": "en",
      "currency": "USD",
      "notifications": {
        "email": true,
        "sms": false,
        "push": true
      }
    }
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "60d21b4667d0d8992e610c85",
      "firstName": "John",
      "lastName": "Smith",
      "phone": "+12345678901",
      "profile": {
        "address": {
          "street": "456 Oak St",
          "city": "San Francisco",
          "state": "CA",
          "zipCode": "94103",
          "country": "USA"
        },
        "preferences": {
          "language": "en",
          "currency": "USD",
          "notifications": {
            "email": true,
            "sms": false,
            "push": true
          }
        }
      },
      "updatedAt": "2023-06-22T10:15:00.000Z"
    }
  }
}
```

#### Update Avatar

```
PATCH /api/users/avatar
```

Update the user's profile picture.

**Headers:**
```
Authorization: Bearer <token>
Content-Type: multipart/form-data
```

**Request Body:**
```
Form data with key "avatar" containing the image file
```

**Response:**
```json
{
  "success": true,
  "data": {
    "avatar": "https://example.com/avatars/user123.jpg"
  }
}
```

#### Get User Addresses

```
GET /api/users/addresses
```

Get the user's saved addresses.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "addresses": [
      {
        "id": "60d21b4667d0d8992e610c86",
        "name": "Home",
        "street": "123 Main St",
        "city": "New York",
        "state": "NY",
        "zipCode": "10001",
        "country": "USA",
        "coordinates": {
          "lat": 40.7128,
          "lng": -74.006
        },
        "isDefault": true
      },
      {
        "id": "60d21b4667d0d8992e610c87",
        "name": "Work",
        "street": "456 Park Ave",
        "city": "New York",
        "state": "NY",
        "zipCode": "10022",
        "country": "USA",
        "coordinates": {
          "lat": 40.7580,
          "lng": -73.9855
        },
        "isDefault": false
      }
    ]
  }
}
```

#### Add User Address

```
POST /api/users/addresses
```

Add a new address for the user.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "name": "Office",
  "street": "789 Broadway",
  "city": "New York",
  "state": "NY",
  "zipCode": "10003",
  "country": "USA",
  "coordinates": {
    "lat": 40.7352,
    "lng": -73.9911
  },
  "isDefault": false
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "address": {
      "id": "60d21b4667d0d8992e610c88",
      "name": "Office",
      "street": "789 Broadway",
      "city": "New York",
      "state": "NY",
      "zipCode": "10003",
      "country": "USA",
      "coordinates": {
        "lat": 40.7352,
        "lng": -73.9911
      },
      "isDefault": false
    }
  }
}
```

#### Update User Address

```
PATCH /api/users/addresses/:addressId
```

Update an existing address.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "name": "New Office",
  "street": "789 Broadway",
  "city": "New York",
  "state": "NY",
  "zipCode": "10003",
  "isDefault": true
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "address": {
      "id": "60d21b4667d0d8992e610c88",
      "name": "New Office",
      "street": "789 Broadway",
      "city": "New York",
      "state": "NY",
      "zipCode": "10003",
      "country": "USA",
      "coordinates": {
        "lat": 40.7352,
        "lng": -73.9911
      },
      "isDefault": true
    }
  }
}
```

#### Delete User Address

```
DELETE /api/users/addresses/:addressId
```

Delete an address.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "message": "Address deleted successfully"
}
```

#### Get Payment Methods

```
GET /api/users/payment-methods
```

Get the user's saved payment methods.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "paymentMethods": [
      {
        "id": "pm_1234567890",
        "type": "card",
        "card": {
          "brand": "visa",
          "last4": "4242",
          "expMonth": 12,
          "expYear": 2025
        },
        "isDefault": true
      },
      {
        "id": "pm_0987654321",
        "type": "card",
        "card": {
          "brand": "mastercard",
          "last4": "5555",
          "expMonth": 10,
          "expYear": 2024
        },
        "isDefault": false
      }
    ]
  }
}
```

#### Add Payment Method

```
POST /api/users/payment-methods
```

Add a new payment method.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "paymentMethodId": "pm_1234567890",
  "isDefault": true
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "paymentMethod": {
      "id": "pm_1234567890",
      "type": "card",
      "card": {
        "brand": "visa",
        "last4": "4242",
        "expMonth": 12,
        "expYear": 2025
      },
      "isDefault": true
    }
  }
}
```

#### Delete Payment Method

```
DELETE /api/users/payment-methods/:paymentMethodId
```

Delete a payment method.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "message": "Payment method deleted successfully"
}
```

#### Set Default Payment Method

```
PATCH /api/users/payment-methods/:paymentMethodId/default
```

Set a payment method as default.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "message": "Default payment method updated successfully"
}
```

## Restaurant Management

### Restaurant Endpoints

#### Get All Restaurants

```
GET /api/restaurants
```

Get a list of restaurants with optional filtering.

**Query Parameters:**
- `page` (optional): Page number for pagination (default: 1)
- `limit` (optional): Number of restaurants per page (default: 10)
- `sort` (optional): Sort field (e.g., 'rating', 'name', 'distance')
- `order` (optional): Sort order ('asc' or 'desc')
- `cuisine` (optional): Filter by cuisine type
- `search` (optional): Search term for restaurant name or cuisine
- `lat` (optional): Latitude for location-based search
- `lng` (optional): Longitude for location-based search
- `radius` (optional): Search radius in miles (default: 5)

**Response:**
```json
{
  "success": true,
  "data": {
    "restaurants": [
      {
        "id": "60d21b4667d0d8992e610c89",
        "name": "Pizza Palace",
        "description": "Best pizza in town",
        "cuisine": ["Italian", "Pizza"],
        "address": {
          "street": "123 Main St",
          "city": "New York",
          "state": "NY",
          "zipCode": "10001",
          "country": "USA",
          "coordinates": {
            "lat": 40.7128,
            "lng": -74.006
          }
        },
        "rating": 4.5,
        "totalReviews": 120,
        "isOpen": true,
        "delivery": {
          "isAvailable": true,
          "fee": 2.99,
          "minimumOrder": 10,
          "estimatedTime": 30
        },
        "images": [
          "https://example.com/restaurants/pizza-palace-1.jpg",
          "https://example.com/restaurants/pizza-palace-2.jpg"
        ],
        "logo": "https://example.com/restaurants/pizza-palace-logo.jpg"
      },
      // More restaurants...
    ],
    "pagination": {
      "page": 1,
      "limit": 10,
      "totalPages": 5,
      "totalResults": 48
    }
  }
}
```

#### Get Restaurant by ID

```
GET /api/restaurants/:id
```

Get detailed information about a specific restaurant.

**Response:**
```json
{
  "success": true,
  "data": {
    "restaurant": {
      "id": "60d21b4667d0d8992e610c89",
      "name": "Pizza Palace",
      "description": "Best pizza in town",
      "cuisine": ["Italian", "Pizza"],
      "address": {
        "street": "123 Main St",
        "city": "New York",
        "state": "NY",
        "zipCode": "10001",
        "country": "USA",
        "coordinates": {
          "lat": 40.7128,
          "lng": -74.006
        }
      },
      "contactInfo": {
        "phone": "+12345678901",
        "email": "info@pizzapalace.com",
        "website": "https://pizzapalace.com"
      },
      "rating": 4.5,
      "totalReviews": 120,
      "isOpen": true,
      "operatingHours": [
        {
          "day": "Monday",
          "open": "11:00",
          "close": "22:00",
          "isOpen": true
        },
        // Other days...
      ],
      "delivery": {
        "isAvailable": true,
        "radius": 5,
        "fee": 2.99,
        "minimumOrder": 10,
        "estimatedTime": 30
      },
      "pickup": {
        "isAvailable": true,
        "estimatedTime": 15
      },
      "images": [
        "https://example.com/restaurants/pizza-palace-1.jpg",
        "https://example.com/restaurants/pizza-palace-2.jpg"
      ],
      "logo": "https://example.com/restaurants/pizza-palace-logo.jpg",
      "coverImage": "https://example.com/restaurants/pizza-palace-cover.jpg"
    }
  }
}
```

#### Get Restaurant Menu

```
GET /api/restaurants/:id/menu
```

Get the menu for a specific restaurant.

**Response:**
```json
{
  "success": true,
  "data": {
    "menu": [
      {
        "category": "Appetizers",
        "items": [
          {
            "id": "60d21b4667d0d8992e610c8a",
            "name": "Garlic Bread",
            "description": "Freshly baked bread with garlic butter",
            "price": 4.99,
            "image": "https://example.com/menu/garlic-bread.jpg",
            "isAvailable": true,
            "options": [
              {
                "name": "Size",
                "choices": [
                  {
                    "name": "Small",
                    "price": 0
                  },
                  {
                    "name": "Large",
                    "price": 2
                  }
                ]
              },
              {
                "name": "Add Cheese",
                "choices": [
                  {
                    "name": "Yes",
                    "price": 1
                  },
                  {
                    "name": "No",
                    "price": 0
                  }
                ]
              }
            ]
          },
          // More menu items...
        ]
      },
      {
        "category": "Pizzas",
        "items": [
          {
            "id": "60d21b4667d0d8992e610c8b",
            "name": "Margherita",
            "description": "Classic pizza with tomato sauce, mozzarella, and basil",
            "price": 12.99,
            "image": "https://example.com/menu/margherita.jpg",
            "isAvailable": true,
            "options": [
              {
                "name": "Size",
                "choices": [
                  {
                    "name": "Small",
                    "price": 0
                  },
                  {
                    "name": "Medium",
                    "price": 2
                  },
                  {
                    "name": "Large",
                    "price": 4
                  }
                ]
              },
              {
                "name": "Crust",
                "choices": [
                  {
                    "name": "Thin",
                    "price": 0
                  },
                  {
                    "name": "Thick",
                    "price": 1
                  },
                  {
                    "name": "Stuffed",
                    "price": 2
                  }
                ]
              }
            ]
          },
          // More menu items...
        ]
      },
      // More categories...
    ]
  }
}
```

#### Get Restaurant Reviews

```
GET /api/restaurants/:id/reviews
```

Get reviews for a specific restaurant.

**Query Parameters:**
- `page` (optional): Page number for pagination (default: 1)
- `limit` (optional): Number of reviews per page (default: 10)
- `sort` (optional): Sort field (e.g., 'createdAt', 'rating')
- `order` (optional): Sort order ('asc' or 'desc')

**Response:**
```json
{
  "success": true,
  "data": {
    "reviews": [
      {
        "id": "60d21b4667d0d8992e610c8c",
        "user": {
          "id": "60d21b4667d0d8992e610c85",
          "firstName": "John",
          "lastName": "D.",
          "avatar": "https://example.com/avatars/john.jpg"
        },
        "rating": 5,
        "comment": "Amazing pizza! Fast delivery and great service.",
        "createdAt": "2023-06-20T14:30:00.000Z"
      },
      // More reviews...
    ],
    "pagination": {
      "page": 1,
      "limit": 10,
      "totalPages": 3,
      "totalResults": 25
    }
  }
}
```

#### Add Restaurant Review

```
POST /api/restaurants/:id/reviews
```

Add a review for a restaurant.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "rating": 4,
  "comment": "Great food and quick delivery. Highly recommended!"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "review": {
      "id": "60d21b4667d0d8992e610c8d",
      "user": {
        "id": "60d21b4667d0d8992e610c85",
        "firstName": "John",
        "lastName": "D.",
        "avatar": "https://example.com/avatars/john.jpg"
      },
      "rating": 4,
      "comment": "Great food and quick delivery. Highly recommended!",
      "createdAt": "2023-06-23T15:45:00.000Z"
    }
  }
}
```

#### Create Restaurant (Restaurant Owner)

```
POST /api/restaurants
```

Create a new restaurant (for restaurant owners).

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "name": "Burger Joint",
  "description": "Gourmet burgers and fries",
  "cuisine": ["American", "Burgers"],
  "address": {
    "street": "456 Oak St",
    "city": "Los Angeles",
    "state": "CA",
    "zipCode": "90001",
    "country": "USA",
    "coordinates": {
      "lat": 34.0522,
      "lng": -118.2437
    }
  },
  "contactInfo": {
    "phone": "+12345678902",
    "email": "info@burgerjoint.com",
    "website": "https://burgerjoint.com"
  },
  "operatingHours": [
    {
      "day": "Monday",
      "open": "11:00",
      "close": "22:00",
      "isOpen": true
    },
    // Other days...
  ],
  "delivery": {
    "isAvailable": true,
    "radius": 5,
    "fee": 3.99,
    "minimumOrder": 15,
    "estimatedTime": 35
  },
  "pickup": {
    "isAvailable": true,
    "estimatedTime": 20
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "restaurant": {
      "id": "60d21b4667d0d8992e610c8e",
      "name": "Burger Joint",
      "description": "Gourmet burgers and fries",
      "cuisine": ["American", "Burgers"],
      "address": {
        "street": "456 Oak St",
        "city": "Los Angeles",
        "state": "CA",
        "zipCode": "90001",
        "country": "USA",
        "coordinates": {
          "lat": 34.0522,
          "lng": -118.2437
        }
      },
      "contactInfo": {
        "phone": "+12345678902",
        "email": "info@burgerjoint.com",
        "website": "https://burgerjoint.com"
      },
      "operatingHours": [
        {
          "day": "Monday",
          "open": "11:00",
          "close": "22:00",
          "isOpen": true
        },
        // Other days...
      ],
      "delivery": {
        "isAvailable": true,
        "radius": 5,
        "fee": 3.99,
        "minimumOrder": 15,
        "estimatedTime": 35
      },
      "pickup": {
        "isAvailable": true,
        "estimatedTime": 20
      },
      "owner": "60d21b4667d0d8992e610c85",
      "verificationStatus": "pending",
      "createdAt": "2023-06-23T16:00:00.000Z",
      "updatedAt": "2023-06-23T16:00:00.000Z"
    }
  }
}
```

## Order Management

### Order Endpoints

#### Get User Orders

```
GET /api/orders/my-orders
```

Get orders for the current user.

**Headers:**
```
Authorization: Bearer <token>
```

**Query Parameters:**
- `page` (optional): Page number for pagination (default: 1)
- `limit` (optional): Number of orders per page (default: 10)
- `status` (optional): Filter by order status
- `serviceType` (optional): Filter by service type
- `sort` (optional): Sort field (default: 'createdAt')
- `order` (optional): Sort order (default: 'desc')

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "60d21b4667d0d8992e610c8f",
      "orderNumber": "FD230623001",
      "serviceType": "food",
      "status": "delivered",
      "restaurant": {
        "id": "60d21b4667d0d8992e610c89",
        "name": "Pizza Palace",
        "logo": "https://example.com/restaurants/pizza-palace-logo.jpg"
      },
      "items": [
        {
          "name": "Margherita",
          "quantity": 1,
          "price": 12.99,
          "options": [
            {
              "name": "Size",
              "choice": "Medium",
              "price": 2
            },
            {
              "name": "Crust",
              "choice": "Thin",
              "price": 0
            }
          ]
        },
        {
          "name": "Garlic Bread",
          "quantity": 1,
          "price": 4.99,
          "options": []
        }
      ],
      "total": 19.98,
      "createdAt": "2023-06-23T12:30:00.000Z",
      "deliveredAt": "2023-06-23T13:15:00.000Z"
    },
    // More orders...
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "totalPages": 2,
    "totalResults": 15
  }
}
```

#### Get Order by ID

```
GET /api/orders/:id
```

Get detailed information about a specific order.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "order": {
      "id": "60d21b4667d0d8992e610c8f",
      "orderNumber": "FD230623001",
      "user": {
        "id": "60d21b4667d0d8992e610c85",
        "firstName": "John",
        "lastName": "Doe",
        "phone": "+12345678901"
      },
      "serviceType": "food",
      "restaurant": {
        "id": "60d21b4667d0d8992e610c89",
        "name": "Pizza Palace",
        "address": {
          "street": "123 Main St",
          "city": "New York",
          "state": "NY",
          "zipCode": "10001",
          "country": "USA"
        },
        "phone": "+12345678901",
        "logo": "https://example.com/restaurants/pizza-palace-logo.jpg"
      },
      "items": [
        {
          "name": "Margherita",
          "quantity": 1,
          "price": 12.99,
          "options": [
            {
              "name": "Size",
              "choice": "Medium",
              "price": 2
            },
            {
              "name": "Crust",
              "choice": "Thin",
              "price": 0
            }
          ],
          "specialInstructions": "Extra cheese please"
        },
        {
          "name": "Garlic Bread",
          "quantity": 1,
          "price": 4.99,
          "options": []
        }
      ],
      "status": "delivered",
      "paymentStatus": "completed",
      "paymentMethod": "card",
      "paymentDetails": {
        "transactionId": "ch_1234567890",
        "amount": 19.98,
        "currency": "USD",
        "paymentDate": "2023-06-23T12:30:00.000Z"
      },
      "pricing": {
        "subtotal": 19.98,
        "tax": 1.65,
        "deliveryFee": 2.99,
        "serviceFee": 1.99,
        "discount": 0,
        "tip": 3,
        "total": 29.61
      },
      "deliveryAddress": {
        "street": "456 Park Ave",
        "city": "New York",
        "state": "NY",
        "zipCode": "10022",
        "country": "USA",
        "coordinates": {
          "lat": 40.7580,
          "lng": -73.9855
        }
      },
      "estimatedTime": 30,
      "actualTime": 45,
      "tracking": [
        {
          "status": "pending",
          "timestamp": "2023-06-23T12:30:00.000Z",
          "notes": "Order placed"
        },
        {
          "status": "confirmed",
          "timestamp": "2023-06-23T12:32:00.000Z",
          "notes": "Order confirmed by restaurant"
        },
        {
          "status": "in_progress",
          "timestamp": "2023-06-23T12:45:00.000Z",
          "notes": "Order is being prepared"
        },
        {
          "status": "picked_up",
          "timestamp": "2023-06-23T13:00:00.000Z",
          "notes": "Order picked up by driver",
          "location": {
            "lat": 40.7128,
            "lng": -74.006,
            "address": "123 Main St, New York, NY 10001"
          }
        },
        {
          "status": "delivered",
          "timestamp": "2023-06-23T13:15:00.000Z",
          "notes": "Order delivered",
          "location": {
            "lat": 40.7580,
            "lng": -73.9855,
            "address": "456 Park Ave, New York, NY 10022"
          }
        }
      ],
      "driver": {
        "id": "60d21b4667d0d8992e610c90",
        "firstName": "Mike",
        "lastName": "J.",
        "phone": "+12345678903",
        "avatar": "https://example.com/avatars/mike.jpg"
      },
      "rating": {
        "value": 5,
        "comment": "Great service and delicious food!",
        "createdAt": "2023-06-23T14:00:00.000Z"
      },
      "createdAt": "2023-06-23T12:30:00.000Z",
      "updatedAt": "2023-06-23T14:00:00.000Z"
    }
  }
}
```

#### Create Food Order

```
POST /api/orders/food
```

Create a new food delivery order.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "restaurant": "60d21b4667d0d8992e610c89",
  "items": [
    {
      "itemId": "60d21b4667d0d8992e610c8b",
      "name": "Margherita",
      "quantity": 1,
      "price": 12.99,
      "options": [
        {
          "name": "Size",
          "choice": "Medium",
          "price": 2
        },
        {
          "name": "Crust",
          "choice": "Thin",
          "price": 0
        }
      ],
      "specialInstructions": "Extra cheese please"
    },
    {
      "itemId": "60d21b4667d0d8992e610c8a",
      "name": "Garlic Bread",
      "quantity": 1,
      "price": 4.99,
      "options": []
    }
  ],
  "deliveryAddress": {
    "street": "456 Park Ave",
    "city": "New York",
    "state": "NY",
    "zipCode": "10022",
    "country": "USA",
    "coordinates": {
      "lat": 40.7580,
      "lng": -73.9855
    }
  },
  "paymentMethod": "card",
  "paymentIntent": "pi_1234567890",
  "tip": 3,
  "notes": "Please ring the doorbell"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "order": {
      "id": "60d21b4667d0d8992e610c8f",
      "orderNumber": "FD230623001",
      "serviceType": "food",
      "status": "pending",
      "paymentStatus": "completed",
      "estimatedTime": 30,
      "tracking": [
        {
          "status": "pending",
          "timestamp": "2023-06-23T12:30:00.000Z",
          "notes": "Order placed"
        }
      ],
      "createdAt": "2023-06-23T12:30:00.000Z"
    }
  }
}
```

#### Create Ride Order

```
POST /api/orders/ride
```

Create a new rideshare order.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "ride": {
    "pickupLocation": {
      "address": "123 Main St, New York, NY 10001",
      "coordinates": {
        "lat": 40.7128,
        "lng": -74.006
      }
    },
    "dropoffLocation": {
      "address": "456 Park Ave, New York, NY 10022",
      "coordinates": {
        "lat": 40.7580,
        "lng": -73.9855
      }
    },
    "distance": 3.2,
    "duration": 15,
    "rideType": "comfort"
  },
  "paymentMethod": "card",
  "paymentIntent": "pi_1234567891",
  "notes": "I have a small suitcase"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "order": {
      "id": "60d21b4667d0d8992e610c91",
      "orderNumber": "RD230623001",
      "serviceType": "ride",
      "status": "pending",
      "paymentStatus": "completed",
      "estimatedTime": 5,
      "tracking": [
        {
          "status": "pending",
          "timestamp": "2023-06-23T14:30:00.000Z",
          "notes": "Looking for a driver"
        }
      ],
      "createdAt": "2023-06-23T14:30:00.000Z"
    }
  }
}
```

#### Cancel Order

```
PATCH /api/orders/:id/cancel
```

Cancel an order.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "reason": "Changed my mind"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "order": {
      "id": "60d21b4667d0d8992e610c8f",
      "orderNumber": "FD230623001",
      "status": "cancelled",
      "cancellation": {
        "reason": "Changed my mind",
        "cancelledBy": "60d21b4667d0d8992e610c85",
        "cancelledAt": "2023-06-23T12:35:00.000Z"
      },
      "updatedAt": "2023-06-23T12:35:00.000Z"
    }
  }
}
```

#### Rate Order

```
POST /api/orders/:id/rating
```

Rate an order after completion.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "rating": 5,
  "comment": "Great service and delicious food!"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "rating": {
      "value": 5,
      "comment": "Great service and delicious food!",
      "createdAt": "2023-06-23T14:00:00.000Z"
    }
  }
}
```

## Payment Processing

### Payment Endpoints

#### Create Payment Intent

```
POST /api/payments/create-payment-intent
```

Create a payment intent for processing payment.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "amount": 2961,
  "currency": "USD",
  "paymentMethodId": "pm_1234567890",
  "orderId": "60d21b4667d0d8992e610c8f"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "clientSecret": "pi_1234567890_secret_1234567890",
    "paymentIntentId": "pi_1234567890"
  }
}
```

#### Confirm Payment

```
POST /api/payments/confirm-payment
```

Confirm a payment after processing.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "paymentIntentId": "pi_1234567890",
  "orderId": "60d21b4667d0d8992e610c8f"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "status": "succeeded",
    "orderId": "60d21b4667d0d8992e610c8f"
  }
}
```

## Vehicle Management

### Vehicle Endpoints

#### Get Driver Vehicles

```
GET /api/vehicles/my-vehicles
```

Get vehicles for the current driver.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "vehicles": [
      {
        "id": "60d21b4667d0d8992e610c92",
        "type": "car",
        "serviceType": ["ride", "food"],
        "make": "Toyota",
        "model": "Camry",
        "year": 2020,
        "color": "Silver",
        "licensePlate": "ABC123",
        "images": [
          "https://example.com/vehicles/car1.jpg",
          "https://example.com/vehicles/car2.jpg"
        ],
        "status": "active",
        "isAvailable": true,
        "verificationStatus": "verified",
        "createdAt": "2023-06-20T10:00:00.000Z",
        "updatedAt": "2023-06-20T10:00:00.000Z"
      },
      // More vehicles...
    ]
  }
}
```

#### Create Vehicle

```
POST /api/vehicles
```

Create a new vehicle for a driver.

**Headers:**
```
Authorization: Bearer <token>
Content-Type: multipart/form-data
```

**Request Body:**
```
Form data with vehicle details and images
```

**Response:**
```json
{
  "success": true,
  "data": {
    "vehicle": {
      "id": "60d21b4667d0d8992e610c93",
      "type": "car",
      "serviceType": ["ride", "food"],
      "make": "Honda",
      "model": "Accord",
      "year": 2021,
      "color": "Black",
      "licensePlate": "XYZ789",
      "images": [
        "https://example.com/vehicles/honda1.jpg",
        "https://example.com/vehicles/honda2.jpg"
      ],
      "status": "pending-approval",
      "isAvailable": false,
      "verificationStatus": "pending",
      "createdAt": "2023-06-23T16:30:00.000Z",
      "updatedAt": "2023-06-23T16:30:00.000Z"
    }
  }
}
```

## Real-time Communication

### Socket.io Events

#### Connection

```javascript
// Client-side
const socket = io('https://api.fleetflex.com', {
  auth: { token: 'your-jwt-token' }
});

socket.on('connect', () => {
  console.log('Connected to socket server');
});

socket.on('disconnect', () => {
  console.log('Disconnected from socket server');
});
```

#### Join Order Room

```javascript
// Client-side
socket.emit('join_room', orderId);
```

#### Order Status Updates

```javascript
// Client-side
socket.on('order_status', (data) => {
  console.log('Order status updated:', data);
  // data = { orderId, status, timestamp, notes, location? }
});
```

#### Driver Location Updates

```javascript
// Client-side
socket.on('driver_location', (data) => {
  console.log('Driver location updated:', data);
  // data = { orderId, driverId, location: { lat, lng } }
});
```

#### Send Location Update (Driver)

```javascript
// Client-side (Driver app)
socket.emit('location_update', {
  orderId: 'order-id',
  location: {
    lat: 40.7128,
    lng: -74.006
  }
});
```

## Error Handling

### Error Response Format

```json
{
  "success": false,
  "error": "Error message",
  "code": "ERROR_CODE",
  "details": {} // Optional additional details
}
```

### Common Error Codes

- `INVALID_CREDENTIALS`: Invalid email or password
- `UNAUTHORIZED`: Not authorized to access the resource
- `FORBIDDEN`: Forbidden access to the resource
- `NOT_FOUND`: Resource not found
- `VALIDATION_ERROR`: Validation error in request data
- `PAYMENT_ERROR`: Error processing payment
- `SERVER_ERROR`: Internal server error

## Rate Limiting

The API implements rate limiting to prevent abuse. Rate limits vary by endpoint:

- Authentication endpoints: 5 requests per minute
- General API endpoints: 60 requests per minute
- Search endpoints: 30 requests per minute

When rate limit is exceeded, the API returns a 429 Too Many Requests response with a Retry-After header indicating when to retry.

## Versioning

The API uses URL versioning. The current version is v1:

```
https://api.fleetflex.com/v1/...
```

## Conclusion

This documentation covers the core functionality of the FleetFlex API. For additional endpoints or more detailed information, please contact the development team.