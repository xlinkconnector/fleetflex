import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { RootState } from '../store';

// Define base query with auth header
const baseQuery = fetchBaseQuery({
  baseUrl: import.meta.env.VITE_API_URL || 'http://localhost:5000',
  prepareHeaders: (headers, { getState }) => {
    // Get token from state
    const token = (getState() as RootState).auth.token;
    
    // If token exists, add it to the headers
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    
    return headers;
  },
  credentials: 'include',
});

// Create API service
export const api = createApi({
  reducerPath: 'api',
  baseQuery,
  tagTypes: [
    'User', 
    'Restaurant', 
    'Order', 
    'Menu', 
    'Vehicle', 
    'Address', 
    'PaymentMethod',
    'Review',
    'Notification'
  ],
  endpoints: (builder) => ({
    // User endpoints
    getUser: builder.query({
      query: () => '/api/users/profile',
      providesTags: ['User'],
    }),
    updateUser: builder.mutation({
      query: (userData) => ({
        url: '/api/users/profile',
        method: 'PATCH',
        body: userData,
      }),
      invalidatesTags: ['User'],
    }),
    updateAvatar: builder.mutation({
      query: (formData) => ({
        url: '/api/users/avatar',
        method: 'PATCH',
        body: formData,
        formData: true,
      }),
      invalidatesTags: ['User'],
    }),
    
    // Address endpoints
    getUserAddresses: builder.query({
      query: () => '/api/users/addresses',
      providesTags: ['Address'],
    }),
    addAddress: builder.mutation({
      query: (addressData) => ({
        url: '/api/users/addresses',
        method: 'POST',
        body: addressData,
      }),
      invalidatesTags: ['Address'],
    }),
    updateAddress: builder.mutation({
      query: ({ addressId, addressData }) => ({
        url: `/api/users/addresses/${addressId}`,
        method: 'PATCH',
        body: addressData,
      }),
      invalidatesTags: ['Address'],
    }),
    deleteAddress: builder.mutation({
      query: (addressId) => ({
        url: `/api/users/addresses/${addressId}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['Address'],
    }),
    
    // Payment method endpoints
    getPaymentMethods: builder.query({
      query: () => '/api/users/payment-methods',
      providesTags: ['PaymentMethod'],
    }),
    addPaymentMethod: builder.mutation({
      query: (paymentMethodData) => ({
        url: '/api/users/payment-methods',
        method: 'POST',
        body: paymentMethodData,
      }),
      invalidatesTags: ['PaymentMethod'],
    }),
    deletePaymentMethod: builder.mutation({
      query: (paymentMethodId) => ({
        url: `/api/users/payment-methods/${paymentMethodId}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['PaymentMethod'],
    }),
    setDefaultPaymentMethod: builder.mutation({
      query: (paymentMethodId) => ({
        url: `/api/users/payment-methods/${paymentMethodId}/default`,
        method: 'PATCH',
      }),
      invalidatesTags: ['PaymentMethod'],
    }),
    
    // Restaurant endpoints
    getRestaurants: builder.query({
      query: (params) => ({
        url: '/api/restaurants',
        params,
      }),
      providesTags: ['Restaurant'],
    }),
    getRestaurant: builder.query({
      query: (id) => `/api/restaurants/${id}`,
      providesTags: (result, error, id) => [{ type: 'Restaurant', id }],
    }),
    getRestaurantMenu: builder.query({
      query: (id) => `/api/restaurants/${id}/menu`,
      providesTags: (result, error, id) => [{ type: 'Menu', id }],
    }),
    getRestaurantReviews: builder.query({
      query: (id) => `/api/restaurants/${id}/reviews`,
      providesTags: (result, error, id) => [{ type: 'Review', id }],
    }),
    addRestaurantReview: builder.mutation({
      query: ({ restaurantId, reviewData }) => ({
        url: `/api/restaurants/${restaurantId}/reviews`,
        method: 'POST',
        body: reviewData,
      }),
      invalidatesTags: (result, error, { restaurantId }) => [
        { type: 'Review', id: restaurantId },
        { type: 'Restaurant', id: restaurantId },
      ],
    }),
    
    // Order endpoints
    getUserOrders: builder.query({
      query: (params) => ({
        url: '/api/orders/my-orders',
        params,
      }),
      providesTags: ['Order'],
    }),
    getOrder: builder.query({
      query: (id) => `/api/orders/${id}`,
      providesTags: (result, error, id) => [{ type: 'Order', id }],
    }),
    createFoodOrder: builder.mutation({
      query: (orderData) => ({
        url: '/api/orders/food',
        method: 'POST',
        body: orderData,
      }),
      invalidatesTags: ['Order'],
    }),
    createRideOrder: builder.mutation({
      query: (orderData) => ({
        url: '/api/orders/ride',
        method: 'POST',
        body: orderData,
      }),
      invalidatesTags: ['Order'],
    }),
    createShippingOrder: builder.mutation({
      query: (orderData) => ({
        url: '/api/orders/shipping',
        method: 'POST',
        body: orderData,
      }),
      invalidatesTags: ['Order'],
    }),
    createMovingOrder: builder.mutation({
      query: (orderData) => ({
        url: '/api/orders/moving',
        method: 'POST',
        body: orderData,
      }),
      invalidatesTags: ['Order'],
    }),
    createFreightOrder: builder.mutation({
      query: (orderData) => ({
        url: '/api/orders/freight',
        method: 'POST',
        body: orderData,
      }),
      invalidatesTags: ['Order'],
    }),
    cancelOrder: builder.mutation({
      query: (orderId) => ({
        url: `/api/orders/${orderId}/cancel`,
        method: 'PATCH',
      }),
      invalidatesTags: (result, error, orderId) => [{ type: 'Order', id: orderId }],
    }),
    rateOrder: builder.mutation({
      query: ({ orderId, ratingData }) => ({
        url: `/api/orders/${orderId}/rating`,
        method: 'POST',
        body: ratingData,
      }),
      invalidatesTags: (result, error, { orderId }) => [{ type: 'Order', id: orderId }],
    }),
    
    // Payment endpoints
    createPaymentIntent: builder.mutation({
      query: (paymentData) => ({
        url: '/api/payments/create-payment-intent',
        method: 'POST',
        body: paymentData,
      }),
    }),
    confirmPayment: builder.mutation({
      query: (paymentData) => ({
        url: '/api/payments/confirm-payment',
        method: 'POST',
        body: paymentData,
      }),
    }),
    
    // Vehicle endpoints (for drivers)
    getDriverVehicles: builder.query({
      query: () => '/api/vehicles/my-vehicles',
      providesTags: ['Vehicle'],
    }),
    getVehicle: builder.query({
      query: (id) => `/api/vehicles/${id}`,
      providesTags: (result, error, id) => [{ type: 'Vehicle', id }],
    }),
    createVehicle: builder.mutation({
      query: (vehicleData) => ({
        url: '/api/vehicles',
        method: 'POST',
        body: vehicleData,
      }),
      invalidatesTags: ['Vehicle'],
    }),
    updateVehicle: builder.mutation({
      query: ({ vehicleId, vehicleData }) => ({
        url: `/api/vehicles/${vehicleId}`,
        method: 'PATCH',
        body: vehicleData,
      }),
      invalidatesTags: (result, error, { vehicleId }) => [{ type: 'Vehicle', id: vehicleId }],
    }),
    updateVehicleStatus: builder.mutation({
      query: ({ vehicleId, status }) => ({
        url: `/api/vehicles/${vehicleId}/status`,
        method: 'PATCH',
        body: { status },
      }),
      invalidatesTags: (result, error, { vehicleId }) => [{ type: 'Vehicle', id: vehicleId }],
    }),
    
    // Notification endpoints
    getNotifications: builder.query({
      query: () => '/api/notifications',
      providesTags: ['Notification'],
    }),
    markNotificationAsRead: builder.mutation({
      query: (notificationId) => ({
        url: `/api/notifications/${notificationId}/read`,
        method: 'PATCH',
      }),
      invalidatesTags: ['Notification'],
    }),
    markAllNotificationsAsRead: builder.mutation({
      query: () => ({
        url: '/api/notifications/read-all',
        method: 'PATCH',
      }),
      invalidatesTags: ['Notification'],
    }),
    
    // Search endpoints
    searchRestaurants: builder.query({
      query: (searchParams) => ({
        url: '/api/restaurants/search',
        params: searchParams,
      }),
    }),
    
    // Tracking endpoint
    trackOrder: builder.query({
      query: (trackingId) => `/api/tracking/${trackingId}`,
      providesTags: (result, error, trackingId) => [{ type: 'Order', id: trackingId }],
    }),
  }),
});

// Export hooks for usage in components
export const {
  // User hooks
  useGetUserQuery,
  useUpdateUserMutation,
  useUpdateAvatarMutation,
  
  // Address hooks
  useGetUserAddressesQuery,
  useAddAddressMutation,
  useUpdateAddressMutation,
  useDeleteAddressMutation,
  
  // Payment method hooks
  useGetPaymentMethodsQuery,
  useAddPaymentMethodMutation,
  useDeletePaymentMethodMutation,
  useSetDefaultPaymentMethodMutation,
  
  // Restaurant hooks
  useGetRestaurantsQuery,
  useGetRestaurantQuery,
  useGetRestaurantMenuQuery,
  useGetRestaurantReviewsQuery,
  useAddRestaurantReviewMutation,
  
  // Order hooks
  useGetUserOrdersQuery,
  useGetOrderQuery,
  useCreateFoodOrderMutation,
  useCreateRideOrderMutation,
  useCreateShippingOrderMutation,
  useCreateMovingOrderMutation,
  useCreateFreightOrderMutation,
  useCancelOrderMutation,
  useRateOrderMutation,
  
  // Payment hooks
  useCreatePaymentIntentMutation,
  useConfirmPaymentMutation,
  
  // Vehicle hooks
  useGetDriverVehiclesQuery,
  useGetVehicleQuery,
  useCreateVehicleMutation,
  useUpdateVehicleMutation,
  useUpdateVehicleStatusMutation,
  
  // Notification hooks
  useGetNotificationsQuery,
  useMarkNotificationAsReadMutation,
  useMarkAllNotificationsAsReadMutation,
  
  // Search hooks
  useSearchRestaurantsQuery,
  
  // Tracking hooks
  useTrackOrderQuery,
} = api;