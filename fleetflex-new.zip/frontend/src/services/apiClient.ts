import axios, { AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios';
import { store } from '../store';
import { logout, refreshAuth } from '../store/slices/authSlice';

// Create axios instance
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000, // 15 seconds
});

// Request interceptor
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
apiClient.interceptors.response.use(
  (response: AxiosResponse) => {
    return response;
  },
  async (error: AxiosError) => {
    const originalRequest = error.config as AxiosRequestConfig & { _retry?: boolean };
    
    // If error is 401 Unauthorized and not already retrying
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = localStorage.getItem('refreshToken');
        
        // If no refresh token, logout
        if (!refreshToken) {
          store.dispatch(logout());
          return Promise.reject(error);
        }
        
        // Try to refresh the token
        const result = await store.dispatch(refreshAuth(refreshToken));
        
        if (refreshAuth.fulfilled.match(result)) {
          // Retry the original request with new token
          const newToken = result.payload.token;
          originalRequest.headers = {
            ...originalRequest.headers,
            Authorization: `Bearer ${newToken}`,
          };
          
          return apiClient(originalRequest);
        } else {
          // If refresh failed, logout
          store.dispatch(logout());
          return Promise.reject(error);
        }
      } catch (refreshError) {
        // If refresh failed, logout
        store.dispatch(logout());
        return Promise.reject(error);
      }
    }
    
    // Handle network errors
    if (error.message === 'Network Error') {
      console.error('Network Error: Please check your internet connection');
    }
    
    // Handle timeout errors
    if (error.code === 'ECONNABORTED') {
      console.error('Request timeout: The server took too long to respond');
    }
    
    return Promise.reject(error);
  }
);

export default apiClient;