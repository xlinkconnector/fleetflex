import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { RootState } from '../store';
import { fetchCurrentUser, login, logout, register, User } from '../store/slices/authSlice';
import { AppDispatch } from '../store';
import { isTokenExpired } from '../utils/auth';
import toast from 'react-hot-toast';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}

interface AuthProviderProps {
  children: ReactNode;
}

interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  role?: 'customer' | 'driver' | 'restaurant';
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const { user, isAuthenticated, isLoading, error, token, refreshToken } = useSelector(
    (state: RootState) => state.auth
  );
  const [initialized, setInitialized] = useState(false);

  // Initialize auth state
  useEffect(() => {
    const initAuth = async () => {
      // Check if token exists and is valid
      if (token && !isTokenExpired(token)) {
        try {
          // Fetch current user data
          await dispatch(fetchCurrentUser()).unwrap();
        } catch (error) {
          console.error('Failed to fetch user data:', error);
        }
      } else if (refreshToken) {
        // If token is expired but refresh token exists, try to refresh
        try {
          // Refresh token logic is handled by API interceptors
        } catch (error) {
          console.error('Failed to refresh token:', error);
        }
      }
      
      setInitialized(true);
    };
    
    initAuth();
  }, [dispatch, token, refreshToken]);

  // Handle login
  const handleLogin = async (email: string, password: string) => {
    try {
      await dispatch(login({ email, password })).unwrap();
      toast.success('Login successful');
      navigate('/dashboard');
    } catch (error) {
      console.error('Login failed:', error);
      toast.error(typeof error === 'string' ? error : 'Login failed. Please try again.');
    }
  };

  // Handle register
  const handleRegister = async (userData: RegisterData) => {
    try {
      await dispatch(register(userData)).unwrap();
      toast.success('Registration successful! Please check your email to verify your account.');
      navigate('/dashboard');
    } catch (error) {
      console.error('Registration failed:', error);
      toast.error(typeof error === 'string' ? error : 'Registration failed. Please try again.');
    }
  };

  // Handle logout
  const handleLogout = async () => {
    try {
      await dispatch(logout()).unwrap();
      toast.success('Logged out successfully');
      navigate('/');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  // Clear error
  const clearError = () => {
    dispatch({ type: 'auth/clearError' });
  };

  // Context value
  const value = {
    user,
    isAuthenticated,
    isLoading: isLoading || !initialized,
    error,
    login: handleLogin,
    register: handleRegister,
    logout: handleLogout,
    clearError,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};