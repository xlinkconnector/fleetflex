import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { 
  TruckIcon, 
  ShoppingBagIcon, 
  UserGroupIcon, 
  HomeIcon, 
  CurrencyDollarIcon 
} from '@heroicons/react/24/outline';

const HomePage: React.FC = () => {
  // Animation variants
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  // Services data
  const services = [
    {
      id: 'food',
      title: 'Food Delivery',
      description: 'Order from your favorite restaurants and get food delivered to your doorstep',
      icon: ShoppingBagIcon,
      color: 'bg-red-500',
      link: '/restaurants'
    },
    {
      id: 'ride',
      title: 'Rideshare',
      description: 'Get reliable rides to anywhere you need to go with professional drivers',
      icon: UserGroupIcon,
      color: 'bg-blue-500',
      link: '/ride'
    },
    {
      id: 'shipping',
      title: 'Shipping',
      description: 'Send packages anywhere with real-time tracking and secure delivery',
      icon: TruckIcon,
      color: 'bg-green-500',
      link: '/shipping'
    },
    {
      id: 'moving',
      title: 'Moving Services',
      description: 'Professional moving services for homes and businesses',
      icon: HomeIcon,
      color: 'bg-purple-500',
      link: '/moving'
    },
    {
      id: 'freight',
      title: 'Freight',
      description: 'Heavy-duty freight services for large shipments and cargo',
      icon: TruckIcon,
      color: 'bg-orange-500',
      link: '/freight'
    }
  ];

  return (
    <>
      <Helmet>
        <title>FleetFlex - Multi-Service Logistics Platform</title>
        <meta name="description" content="Food delivery, rideshare, shipping, moving, and freight services all in one platform." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary-600 to-secondary-600 text-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-20"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={fadeIn}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              All Your Logistics Needs in One Platform
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              Food delivery, rideshare, shipping, moving, and freight services at your fingertips.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/restaurants"
                className="btn btn-lg bg-white text-primary-600 hover:bg-gray-100"
              >
                Order Food
              </Link>
              <Link
                to="/ride"
                className="btn btn-lg bg-primary-700 text-white hover:bg-primary-800 border border-primary-500"
              >
                Book a Ride
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 md:py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
              Our Services
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              From food delivery to freight shipping, we've got all your logistics needs covered.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {services.map((service) => (
              <motion.div
                key={service.id}
                variants={fadeIn}
                className="bg-white dark:bg-gray-700 rounded-lg shadow-lg overflow-hidden transition-transform hover:transform hover:scale-105"
              >
                <div className={`p-6 ${service.color} flex items-center justify-center`}>
                  <service.icon className="h-12 w-12 text-white" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    {service.description}
                  </p>
                  <Link
                    to={service.link}
                    className="inline-flex items-center text-primary-600 dark:text-primary-400 font-medium"
                  >
                    Learn more
                    <svg className="ml-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </Link>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 md:py-24 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Getting started with FleetFlex is simple and straightforward
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid grid-cols-1 md:grid-cols-4 gap-8"
          >
            {[
              {
                step: 1,
                title: 'Choose Service',
                description: 'Select from our range of services',
                icon: ShoppingBagIcon,
              },
              {
                step: 2,
                title: 'Place Order',
                description: 'Provide details and confirm',
                icon: CurrencyDollarIcon,
              },
              {
                step: 3,
                title: 'Track Progress',
                description: 'Follow your order in real-time',
                icon: TruckIcon,
              },
              {
                step: 4,
                title: 'Receive & Enjoy',
                description: 'Get your delivery and enjoy',
                icon: HomeIcon,
              },
            ].map((item) => (
              <motion.div
                key={item.step}
                variants={fadeIn}
                className="text-center"
              >
                <div className="relative">
                  <div className="mx-auto rounded-full bg-primary-100 dark:bg-primary-900 p-4 w-20 h-20 flex items-center justify-center mb-4">
                    <item.icon className="h-10 w-10 text-primary-600 dark:text-primary-400" />
                  </div>
                  <div className="absolute top-10 left-full w-full h-0.5 bg-primary-100 dark:bg-primary-900 hidden md:block" style={{ width: 'calc(100% - 5rem)' }}></div>
                </div>
                <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">{item.title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{item.description}</p>
                <div className="mt-4 text-2xl font-bold text-primary-600 dark:text-primary-400">
                  {item.step}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Get Started?
            </h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Join thousands of satisfied customers using FleetFlex for all their logistics needs.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/auth/register"
                className="btn btn-lg bg-white text-primary-600 hover:bg-gray-100"
              >
                Sign Up Now
              </Link>
              <Link
                to="/about"
                className="btn btn-lg bg-transparent border border-white hover:bg-primary-700"
              >
                Learn More
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* App Download Section */}
      <section className="py-16 md:py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={fadeIn}
              className="md:w-1/2 mb-8 md:mb-0 md:pr-8"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
                Download Our Mobile App
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-6">
                Get the full FleetFlex experience on your mobile device. Available for iOS and Android.
              </p>
              <div className="flex flex-wrap gap-4">
                <a href="#" className="inline-block">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Download_on_the_App_Store_Badge.svg"
                    alt="Download on the App Store"
                    className="h-12"
                  />
                </a>
                <a href="#" className="inline-block">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
                    alt="Get it on Google Play"
                    className="h-12"
                  />
                </a>
              </div>
            </motion.div>
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={fadeIn}
              className="md:w-1/2"
            >
              <div className="relative">
                <div className="absolute -top-4 -left-4 w-full h-full bg-primary-200 dark:bg-primary-900 rounded-xl transform rotate-3"></div>
                <div className="absolute -bottom-4 -right-4 w-full h-full bg-secondary-200 dark:bg-secondary-900 rounded-xl transform -rotate-3"></div>
                <div className="relative bg-white dark:bg-gray-700 p-6 rounded-xl shadow-xl">
                  <img
                    src="https://via.placeholder.com/600x400?text=FleetFlex+Mobile+App"
                    alt="FleetFlex Mobile App"
                    className="w-full h-auto rounded-lg"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;