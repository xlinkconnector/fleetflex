import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import { useUpdateUserMutation, useUpdateAvatarMutation } from '../../services/api';
import toast from 'react-hot-toast';
import { CameraIcon, CheckCircleIcon } from '@heroicons/react/24/outline';

interface ProfileFormData {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  'profile.address.street': string;
  'profile.address.city': string;
  'profile.address.state': string;
  'profile.address.zipCode': string;
  'profile.address.country': string;
  'profile.preferences.language': string;
  'profile.preferences.currency': string;
  'profile.preferences.notifications.email': boolean;
  'profile.preferences.notifications.sms': boolean;
  'profile.preferences.notifications.push': boolean;
}

const ProfilePage: React.FC = () => {
  const { user } = useAuth();
  const [updateUser, { isLoading: isUpdating }] = useUpdateUserMutation();
  const [updateAvatar, { isLoading: isUploadingAvatar }] = useUpdateAvatarMutation();
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  
  const {
    register,
    handleSubmit,
    formState: { errors, isDirty },
    reset,
  } = useForm<ProfileFormData>({
    defaultValues: {
      firstName: user?.firstName || '',
      lastName: user?.lastName || '',
      phone: user?.phone || '',
      email: user?.email || '',
      'profile.address.street': user?.profile?.address?.street || '',
      'profile.address.city': user?.profile?.address?.city || '',
      'profile.address.state': user?.profile?.address?.state || '',
      'profile.address.zipCode': user?.profile?.address?.zipCode || '',
      'profile.address.country': user?.profile?.address?.country || 'USA',
      'profile.preferences.language': user?.profile?.preferences?.language || 'en',
      'profile.preferences.currency': user?.profile?.preferences?.currency || 'USD',
      'profile.preferences.notifications.email': user?.profile?.preferences?.notifications?.email ?? true,
      'profile.preferences.notifications.sms': user?.profile?.preferences?.notifications?.sms ?? true,
      'profile.preferences.notifications.push': user?.profile?.preferences?.notifications?.push ?? true,
    },
  });
  
  // Handle profile update
  const onSubmit = async (data: ProfileFormData) => {
    try {
      // Transform form data to match API expectations
      const userData = {
        firstName: data.firstName,
        lastName: data.lastName,
        phone: data.phone,
        profile: {
          address: {
            street: data['profile.address.street'],
            city: data['profile.address.city'],
            state: data['profile.address.state'],
            zipCode: data['profile.address.zipCode'],
            country: data['profile.address.country'],
          },
          preferences: {
            language: data['profile.preferences.language'],
            currency: data['profile.preferences.currency'],
            notifications: {
              email: data['profile.preferences.notifications.email'],
              sms: data['profile.preferences.notifications.sms'],
              push: data['profile.preferences.notifications.push'],
            },
          },
        },
      };
      
      await updateUser(userData).unwrap();
      toast.success('Profile updated successfully');
    } catch (error) {
      console.error('Failed to update profile:', error);
      toast.error('Failed to update profile. Please try again.');
    }
  };
  
  // Handle avatar upload
  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Preview the image
    const reader = new FileReader();
    reader.onload = () => {
      setAvatarPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    
    // Upload the image
    try {
      const formData = new FormData();
      formData.append('avatar', file);
      
      await updateAvatar(formData).unwrap();
      toast.success('Profile picture updated successfully');
    } catch (error) {
      console.error('Failed to upload avatar:', error);
      toast.error('Failed to upload profile picture. Please try again.');
    }
  };
  
  return (
    <>
      <Helmet>
        <title>Profile - FleetFlex</title>
        <meta name="description" content="Manage your FleetFlex profile" />
      </Helmet>
      
      <div className="space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
        >
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Profile Settings
          </h1>
          <p className="mt-1 text-gray-600 dark:text-gray-300">
            Manage your account information and preferences
          </p>
        </motion.div>
        
        {/* Profile Form */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
          <div className="md:grid md:grid-cols-3 md:gap-6">
            {/* Avatar Section */}
            <div className="md:col-span-1 p-6 border-b md:border-b-0 md:border-r border-gray-200 dark:border-gray-700">
              <div className="px-4 sm:px-0">
                <h3 className="text-lg font-medium leading-6 text-gray-900 dark:text-white">
                  Profile Picture
                </h3>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                  Upload a profile picture to personalize your account.
                </p>
              </div>
              
              <div className="mt-6 flex flex-col items-center">
                <div className="relative">
                  <div className="w-32 h-32 rounded-full overflow-hidden bg-gray-100 dark:bg-gray-700">
                    {avatarPreview || user?.profile?.avatar ? (
                      <img
                        src={avatarPreview || user?.profile?.avatar}
                        alt={`${user?.firstName} ${user?.lastName}`}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-400 dark:text-gray-500">
                        <svg className="h-16 w-16" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                      </div>
                    )}
                  </div>
                  
                  <label
                    htmlFor="avatar-upload"
                    className="absolute bottom-0 right-0 bg-primary-600 rounded-full p-2 text-white cursor-pointer hover:bg-primary-700 transition-colors"
                  >
                    <CameraIcon className="h-5 w-5" />
                  </label>
                  
                  <input
                    id="avatar-upload"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleAvatarChange}
                    disabled={isUploadingAvatar}
                  />
                </div>
                
                {isUploadingAvatar && (
                  <div className="mt-2 flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <div className="spinner-sm mr-2"></div>
                    Uploading...
                  </div>
                )}
              </div>
            </div>
            
            {/* Form Section */}
            <div className="mt-5 md:mt-0 md:col-span-2 p-6">
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="grid grid-cols-6 gap-6">
                  {/* Personal Information */}
                  <div className="col-span-6">
                    <h3 className="text-lg font-medium leading-6 text-gray-900 dark:text-white">
                      Personal Information
                    </h3>
                  </div>
                  
                  {/* First Name */}
                  <div className="col-span-6 sm:col-span-3">
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      First name
                    </label>
                    <input
                      type="text"
                      id="firstName"
                      autoComplete="given-name"
                      className={`form-input mt-1 ${errors.firstName ? 'border-red-500' : ''}`}
                      {...register('firstName', { required: 'First name is required' })}
                    />
                    {errors.firstName && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                        {errors.firstName.message}
                      </p>
                    )}
                  </div>
                  
                  {/* Last Name */}
                  <div className="col-span-6 sm:col-span-3">
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Last name
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      autoComplete="family-name"
                      className={`form-input mt-1 ${errors.lastName ? 'border-red-500' : ''}`}
                      {...register('lastName', { required: 'Last name is required' })}
                    />
                    {errors.lastName && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                        {errors.lastName.message}
                      </p>
                    )}
                  </div>
                  
                  {/* Email */}
                  <div className="col-span-6 sm:col-span-3">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Email address
                    </label>
                    <input
                      type="email"
                      id="email"
                      autoComplete="email"
                      className="form-input mt-1 bg-gray-100 dark:bg-gray-700"
                      {...register('email')}
                      disabled
                    />
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                      Email cannot be changed
                    </p>
                  </div>
                  
                  {/* Phone */}
                  <div className="col-span-6 sm:col-span-3">
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Phone number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      autoComplete="tel"
                      className={`form-input mt-1 ${errors.phone ? 'border-red-500' : ''}`}
                      {...register('phone', {
                        required: 'Phone number is required',
                        pattern: {
                          value: /^\+?[1-9]\d{1,14}$/,
                          message: 'Please enter a valid phone number',
                        },
                      })}
                    />
                    {errors.phone && (
                      <p className="mt-1 text-sm text-red-600 dark:text-red-400">
                        {errors.phone.message}
                      </p>
                    )}
                  </div>
                  
                  {/* Address */}
                  <div className="col-span-6 border-t border-gray-200 dark:border-gray-700 pt-6 mt-4">
                    <h3 className="text-lg font-medium leading-6 text-gray-900 dark:text-white">
                      Address
                    </h3>
                  </div>
                  
                  {/* Street */}
                  <div className="col-span-6">
                    <label htmlFor="street" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Street address
                    </label>
                    <input
                      type="text"
                      id="street"
                      autoComplete="street-address"
                      className="form-input mt-1"
                      {...register('profile.address.street')}
                    />
                  </div>
                  
                  {/* City */}
                  <div className="col-span-6 sm:col-span-2">
                    <label htmlFor="city" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      City
                    </label>
                    <input
                      type="text"
                      id="city"
                      autoComplete="address-level2"
                      className="form-input mt-1"
                      {...register('profile.address.city')}
                    />
                  </div>
                  
                  {/* State */}
                  <div className="col-span-6 sm:col-span-2">
                    <label htmlFor="state" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      State / Province
                    </label>
                    <input
                      type="text"
                      id="state"
                      autoComplete="address-level1"
                      className="form-input mt-1"
                      {...register('profile.address.state')}
                    />
                  </div>
                  
                  {/* ZIP Code */}
                  <div className="col-span-6 sm:col-span-2">
                    <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      ZIP / Postal code
                    </label>
                    <input
                      type="text"
                      id="zipCode"
                      autoComplete="postal-code"
                      className="form-input mt-1"
                      {...register('profile.address.zipCode')}
                    />
                  </div>
                  
                  {/* Country */}
                  <div className="col-span-6">
                    <label htmlFor="country" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Country
                    </label>
                    <select
                      id="country"
                      autoComplete="country-name"
                      className="form-input mt-1"
                      {...register('profile.address.country')}
                    >
                      <option value="USA">United States</option>
                      <option value="CAN">Canada</option>
                      <option value="MEX">Mexico</option>
                      <option value="GBR">United Kingdom</option>
                      <option value="AUS">Australia</option>
                      <option value="DEU">Germany</option>
                      <option value="FRA">France</option>
                      <option value="JPN">Japan</option>
                    </select>
                  </div>
                  
                  {/* Preferences */}
                  <div className="col-span-6 border-t border-gray-200 dark:border-gray-700 pt-6 mt-4">
                    <h3 className="text-lg font-medium leading-6 text-gray-900 dark:text-white">
                      Preferences
                    </h3>
                  </div>
                  
                  {/* Language */}
                  <div className="col-span-6 sm:col-span-3">
                    <label htmlFor="language" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Language
                    </label>
                    <select
                      id="language"
                      className="form-input mt-1"
                      {...register('profile.preferences.language')}
                    >
                      <option value="en">English</option>
                      <option value="es">Spanish</option>
                      <option value="fr">French</option>
                      <option value="de">German</option>
                      <option value="zh">Chinese</option>
                      <option value="ja">Japanese</option>
                    </select>
                  </div>
                  
                  {/* Currency */}
                  <div className="col-span-6 sm:col-span-3">
                    <label htmlFor="currency" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Currency
                    </label>
                    <select
                      id="currency"
                      className="form-input mt-1"
                      {...register('profile.preferences.currency')}
                    >
                      <option value="USD">US Dollar ($)</option>
                      <option value="EUR">Euro (€)</option>
                      <option value="GBP">British Pound (£)</option>
                      <option value="CAD">Canadian Dollar (C$)</option>
                      <option value="AUD">Australian Dollar (A$)</option>
                      <option value="JPY">Japanese Yen (¥)</option>
                    </select>
                  </div>
                  
                  {/* Notification Preferences */}
                  <div className="col-span-6">
                    <fieldset>
                      <legend className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        Notification Preferences
                      </legend>
                      <div className="mt-4 space-y-4">
                        <div className="flex items-start">
                          <div className="flex items-center h-5">
                            <input
                              id="email-notifications"
                              type="checkbox"
                              className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                              {...register('profile.preferences.notifications.email')}
                            />
                          </div>
                          <div className="ml-3 text-sm">
                            <label htmlFor="email-notifications" className="font-medium text-gray-700 dark:text-gray-300">
                              Email Notifications
                            </label>
                            <p className="text-gray-500 dark:text-gray-400">
                              Receive order updates and promotions via email.
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <div className="flex items-center h-5">
                            <input
                              id="sms-notifications"
                              type="checkbox"
                              className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                              {...register('profile.preferences.notifications.sms')}
                            />
                          </div>
                          <div className="ml-3 text-sm">
                            <label htmlFor="sms-notifications" className="font-medium text-gray-700 dark:text-gray-300">
                              SMS Notifications
                            </label>
                            <p className="text-gray-500 dark:text-gray-400">
                              Receive order updates and promotions via SMS.
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start">
                          <div className="flex items-center h-5">
                            <input
                              id="push-notifications"
                              type="checkbox"
                              className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                              {...register('profile.preferences.notifications.push')}
                            />
                          </div>
                          <div className="ml-3 text-sm">
                            <label htmlFor="push-notifications" className="font-medium text-gray-700 dark:text-gray-300">
                              Push Notifications
                            </label>
                            <p className="text-gray-500 dark:text-gray-400">
                              Receive order updates and promotions via push notifications.
                            </p>
                          </div>
                        </div>
                      </div>
                    </fieldset>
                  </div>
                </div>
                
                {/* Form Actions */}
                <div className="flex justify-end mt-8 space-x-3">
                  <button
                    type="button"
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                    onClick={() => reset()}
                    disabled={!isDirty || isUpdating}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={!isDirty || isUpdating}
                  >
                    {isUpdating ? (
                      <span className="flex items-center">
                        <div className="spinner-sm mr-2"></div>
                        Saving...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <CheckCircleIcon className="mr-1.5 h-4 w-4" />
                        Save Changes
                      </span>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfilePage;