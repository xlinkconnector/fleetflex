import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import { useGetUserOrdersQuery } from '../../services/api';

// Icons
import {
  ShoppingBagIcon,
  TruckIcon,
  CreditCardIcon,
  MapPinIcon,
  ClockIcon,
  CheckCircleIcon,
  ExclamationCircleIcon,
  ArrowRightIcon,
} from '@heroicons/react/24/outline';

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const { data: orders, isLoading: isLoadingOrders } = useGetUserOrdersQuery({ limit: 5 });

  // Animation variants
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  // Get greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  // Get user-specific content based on role
  const getUserContent = () => {
    switch (user?.role) {
      case 'driver':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg border border-blue-100 dark:border-blue-800">
              <h3 className="text-lg font-semibold text-blue-800 dark:text-blue-300 mb-2">Driver Dashboard</h3>
              <p className="text-blue-700 dark:text-blue-400 mb-4">Manage your driving activities and earnings.</p>
              <Link
                to="/dashboard/earnings"
                className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
              >
                View earnings
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="bg-green-50 dark:bg-green-900/20 p-6 rounded-lg border border-green-100 dark:border-green-800">
              <h3 className="text-lg font-semibold text-green-800 dark:text-green-300 mb-2">Vehicle Management</h3>
              <p className="text-green-700 dark:text-green-400 mb-4">Manage your vehicles and documentation.</p>
              <Link
                to="/dashboard/vehicles"
                className="inline-flex items-center text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-300"
              >
                Manage vehicles
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        );
      case 'restaurant':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-purple-50 dark:bg-purple-900/20 p-6 rounded-lg border border-purple-100 dark:border-purple-800">
              <h3 className="text-lg font-semibold text-purple-800 dark:text-purple-300 mb-2">Restaurant Dashboard</h3>
              <p className="text-purple-700 dark:text-purple-400 mb-4">Manage your restaurant profile and menu.</p>
              <Link
                to="/dashboard/restaurants"
                className="inline-flex items-center text-purple-600 dark:text-purple-400 hover:text-purple-800 dark:hover:text-purple-300"
              >
                Manage restaurants
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="bg-orange-50 dark:bg-orange-900/20 p-6 rounded-lg border border-orange-100 dark:border-orange-800">
              <h3 className="text-lg font-semibold text-orange-800 dark:text-orange-300 mb-2">Menu Management</h3>
              <p className="text-orange-700 dark:text-orange-400 mb-4">Update your menu items and pricing.</p>
              <Link
                to="/dashboard/menu"
                className="inline-flex items-center text-orange-600 dark:text-orange-400 hover:text-orange-800 dark:hover:text-orange-300"
              >
                Manage menu
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        );
      case 'admin':
        return (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-red-50 dark:bg-red-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800">
              <h3 className="text-lg font-semibold text-red-800 dark:text-red-300 mb-2">User Management</h3>
              <p className="text-red-700 dark:text-red-400 mb-4">Manage users and permissions.</p>
              <Link
                to="/dashboard/users"
                className="inline-flex items-center text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300"
              >
                Manage users
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="bg-amber-50 dark:bg-amber-900/20 p-6 rounded-lg border border-amber-100 dark:border-amber-800">
              <h3 className="text-lg font-semibold text-amber-800 dark:text-amber-300 mb-2">Restaurant Management</h3>
              <p className="text-amber-700 dark:text-amber-400 mb-4">Approve and manage restaurants.</p>
              <Link
                to="/dashboard/restaurants"
                className="inline-flex items-center text-amber-600 dark:text-amber-400 hover:text-amber-800 dark:hover:text-amber-300"
              >
                Manage restaurants
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="bg-emerald-50 dark:bg-emerald-900/20 p-6 rounded-lg border border-emerald-100 dark:border-emerald-800">
              <h3 className="text-lg font-semibold text-emerald-800 dark:text-emerald-300 mb-2">Analytics</h3>
              <p className="text-emerald-700 dark:text-emerald-400 mb-4">View platform analytics and reports.</p>
              <Link
                to="/dashboard/analytics"
                className="inline-flex items-center text-emerald-600 dark:text-emerald-400 hover:text-emerald-800 dark:hover:text-emerald-300"
              >
                View analytics
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        );
      default:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-primary-50 dark:bg-primary-900/20 p-6 rounded-lg border border-primary-100 dark:border-primary-800">
              <h3 className="text-lg font-semibold text-primary-800 dark:text-primary-300 mb-2">Explore Our Services</h3>
              <p className="text-primary-700 dark:text-primary-400 mb-4">Discover all the services FleetFlex has to offer.</p>
              <div className="flex flex-wrap gap-2 mt-2">
                <Link
                  to="/restaurants"
                  className="inline-flex items-center px-3 py-1 bg-primary-100 dark:bg-primary-800 text-primary-700 dark:text-primary-300 rounded-full text-sm"
                >
                  Food Delivery
                </Link>
                <Link
                  to="/ride"
                  className="inline-flex items-center px-3 py-1 bg-primary-100 dark:bg-primary-800 text-primary-700 dark:text-primary-300 rounded-full text-sm"
                >
                  Rideshare
                </Link>
                <Link
                  to="/shipping"
                  className="inline-flex items-center px-3 py-1 bg-primary-100 dark:bg-primary-800 text-primary-700 dark:text-primary-300 rounded-full text-sm"
                >
                  Shipping
                </Link>
              </div>
            </div>
            <div className="bg-secondary-50 dark:bg-secondary-900/20 p-6 rounded-lg border border-secondary-100 dark:border-secondary-800">
              <h3 className="text-lg font-semibold text-secondary-800 dark:text-secondary-300 mb-2">Account Settings</h3>
              <p className="text-secondary-700 dark:text-secondary-400 mb-4">Manage your profile and preferences.</p>
              <Link
                to="/dashboard/profile"
                className="inline-flex items-center text-secondary-600 dark:text-secondary-400 hover:text-secondary-800 dark:hover:text-secondary-300"
              >
                Update profile
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        );
    }
  };

  return (
    <>
      <Helmet>
        <title>Dashboard - FleetFlex</title>
        <meta name="description" content="FleetFlex user dashboard" />
      </Helmet>

      <div className="space-y-8">
        {/* Header */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
        >
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {getGreeting()}, {user?.firstName}!
          </h1>
          <p className="mt-1 text-gray-600 dark:text-gray-300">
            Welcome to your FleetFlex dashboard. Here's an overview of your account.
          </p>
        </motion.div>

        {/* User-specific content */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={fadeIn}
        >
          {getUserContent()}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
        >
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Quick Actions
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <motion.div variants={fadeIn}>
              <Link
                to="/restaurants"
                className="flex flex-col items-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
              >
                <ShoppingBagIcon className="h-8 w-8 text-primary-600 dark:text-primary-400 mb-2" />
                <span className="text-sm font-medium text-gray-900 dark:text-white">Order Food</span>
              </Link>
            </motion.div>
            <motion.div variants={fadeIn}>
              <Link
                to="/dashboard/orders"
                className="flex flex-col items-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
              >
                <TruckIcon className="h-8 w-8 text-primary-600 dark:text-primary-400 mb-2" />
                <span className="text-sm font-medium text-gray-900 dark:text-white">Track Orders</span>
              </Link>
            </motion.div>
            <motion.div variants={fadeIn}>
              <Link
                to="/dashboard/payment-methods"
                className="flex flex-col items-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
              >
                <CreditCardIcon className="h-8 w-8 text-primary-600 dark:text-primary-400 mb-2" />
                <span className="text-sm font-medium text-gray-900 dark:text-white">Payment Methods</span>
              </Link>
            </motion.div>
            <motion.div variants={fadeIn}>
              <Link
                to="/dashboard/addresses"
                className="flex flex-col items-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
              >
                <MapPinIcon className="h-8 w-8 text-primary-600 dark:text-primary-400 mb-2" />
                <span className="text-sm font-medium text-gray-900 dark:text-white">Addresses</span>
              </Link>
            </motion.div>
          </div>
        </motion.div>

        {/* Recent Orders */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
        >
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              Recent Orders
            </h2>
            <Link
              to="/dashboard/orders"
              className="text-sm font-medium text-primary-600 dark:text-primary-400 hover:text-primary-800 dark:hover:text-primary-300"
            >
              View all
            </Link>
          </div>

          {isLoadingOrders ? (
            <div className="flex justify-center items-center h-32">
              <div className="spinner-lg"></div>
            </div>
          ) : orders && orders.data && orders.data.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Order ID
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Service
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Total
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {orders.data.map((order: any) => (
                    <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                        <Link to={`/dashboard/orders/${order.id}`} className="hover:text-primary-600 dark:hover:text-primary-400">
                          {order.orderNumber}
                        </Link>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                        {order.serviceType.charAt(0).toUpperCase() + order.serviceType.slice(1)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          order.status === 'completed' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                            : order.status === 'cancelled' 
                              ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                              : 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300'
                        }`}>
                          {order.status === 'completed' && <CheckCircleIcon className="mr-1 h-3 w-3" />}
                          {order.status === 'cancelled' && <ExclamationCircleIcon className="mr-1 h-3 w-3" />}
                          {order.status !== 'completed' && order.status !== 'cancelled' && <ClockIcon className="mr-1 h-3 w-3" />}
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1).replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                        ${order.total.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">You don't have any orders yet.</p>
              <Link
                to="/restaurants"
                className="mt-2 inline-flex items-center text-primary-600 dark:text-primary-400 hover:text-primary-800 dark:hover:text-primary-300"
              >
                Place your first order
                <ArrowRightIcon className="ml-1 h-4 w-4" />
              </Link>
            </div>
          )}
        </motion.div>
      </div>
    </>
  );
};

export default DashboardPage;