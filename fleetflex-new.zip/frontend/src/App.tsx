import React, { useEffect, lazy, Suspense } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useSelector } from 'react-redux';
import { RootState } from './store';

// Layouts
import MainLayout from './layouts/MainLayout';
import DashboardLayout from './layouts/DashboardLayout';
import AuthLayout from './layouts/AuthLayout';

// Components
import LoadingScreen from './components/common/LoadingScreen';
import ProtectedRoute from './components/auth/ProtectedRoute';
import ScrollToTop from './components/common/ScrollToTop';

// Eager loaded pages
import HomePage from './pages/HomePage';
import NotFoundPage from './pages/NotFoundPage';

// Lazy loaded pages
const LoginPage = lazy(() => import('./pages/auth/LoginPage'));
const RegisterPage = lazy(() => import('./pages/auth/RegisterPage'));
const ForgotPasswordPage = lazy(() => import('./pages/auth/ForgotPasswordPage'));
const ResetPasswordPage = lazy(() => import('./pages/auth/ResetPasswordPage'));
const VerifyEmailPage = lazy(() => import('./pages/auth/VerifyEmailPage'));

const DashboardPage = lazy(() => import('./pages/dashboard/DashboardPage'));
const ProfilePage = lazy(() => import('./pages/dashboard/ProfilePage'));
const OrdersPage = lazy(() => import('./pages/dashboard/OrdersPage'));
const OrderDetailsPage = lazy(() => import('./pages/dashboard/OrderDetailsPage'));
const PaymentMethodsPage = lazy(() => import('./pages/dashboard/PaymentMethodsPage'));
const AddressesPage = lazy(() => import('./pages/dashboard/AddressesPage'));

const RestaurantsPage = lazy(() => import('./pages/food/RestaurantsPage'));
const RestaurantDetailsPage = lazy(() => import('./pages/food/RestaurantDetailsPage'));
const CartPage = lazy(() => import('./pages/food/CartPage'));
const CheckoutPage = lazy(() => import('./pages/food/CheckoutPage'));

const RidePage = lazy(() => import('./pages/ride/RidePage'));
const RideBookingPage = lazy(() => import('./pages/ride/RideBookingPage'));

const ShippingPage = lazy(() => import('./pages/shipping/ShippingPage'));
const ShippingBookingPage = lazy(() => import('./pages/shipping/ShippingBookingPage'));

const MovingPage = lazy(() => import('./pages/moving/MovingPage'));
const MovingBookingPage = lazy(() => import('./pages/moving/MovingBookingPage'));

const FreightPage = lazy(() => import('./pages/freight/FreightPage'));
const FreightBookingPage = lazy(() => import('./pages/freight/FreightBookingPage'));

const TrackingPage = lazy(() => import('./pages/tracking/TrackingPage'));

const AboutPage = lazy(() => import('./pages/AboutPage'));
const ContactPage = lazy(() => import('./pages/ContactPage'));
const HelpCenterPage = lazy(() => import('./pages/HelpCenterPage'));
const TermsPage = lazy(() => import('./pages/legal/TermsPage'));
const PrivacyPage = lazy(() => import('./pages/legal/PrivacyPage'));

const App: React.FC = () => {
  const location = useLocation();
  const { theme } = useSelector((state: RootState) => state.theme);

  // Apply theme class to body
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <>
      <Helmet>
        <title>FleetFlex - Multi-Service Logistics Platform</title>
        <meta name="description" content="Food delivery, rideshare, shipping, moving, and freight services all in one platform." />
      </Helmet>
      
      <ScrollToTop />
      
      <Suspense fallback={<LoadingScreen />}>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<MainLayout />}>
            <Route index element={<HomePage />} />
            <Route path="about" element={<AboutPage />} />
            <Route path="contact" element={<ContactPage />} />
            <Route path="help" element={<HelpCenterPage />} />
            <Route path="terms" element={<TermsPage />} />
            <Route path="privacy" element={<PrivacyPage />} />
            <Route path="tracking/:trackingId" element={<TrackingPage />} />
            
            {/* Food Delivery */}
            <Route path="restaurants" element={<RestaurantsPage />} />
            <Route path="restaurants/:id" element={<RestaurantDetailsPage />} />
            <Route path="cart" element={<CartPage />} />
            
            {/* Service Landing Pages */}
            <Route path="ride" element={<RidePage />} />
            <Route path="shipping" element={<ShippingPage />} />
            <Route path="moving" element={<MovingPage />} />
            <Route path="freight" element={<FreightPage />} />
          </Route>
          
          {/* Auth Routes */}
          <Route path="/auth" element={<AuthLayout />}>
            <Route path="login" element={<LoginPage />} />
            <Route path="register" element={<RegisterPage />} />
            <Route path="forgot-password" element={<ForgotPasswordPage />} />
            <Route path="reset-password/:token" element={<ResetPasswordPage />} />
            <Route path="verify-email/:token" element={<VerifyEmailPage />} />
          </Route>
          
          {/* Protected Routes */}
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }>
            <Route index element={<DashboardPage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="orders" element={<OrdersPage />} />
            <Route path="orders/:id" element={<OrderDetailsPage />} />
            <Route path="payment-methods" element={<PaymentMethodsPage />} />
            <Route path="addresses" element={<AddressesPage />} />
          </Route>
          
          {/* Protected Service Booking Routes */}
          <Route path="/checkout" element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }>
            <Route index element={<CheckoutPage />} />
          </Route>
          
          <Route path="/ride-booking" element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }>
            <Route index element={<RideBookingPage />} />
          </Route>
          
          <Route path="/shipping-booking" element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }>
            <Route index element={<ShippingBookingPage />} />
          </Route>
          
          <Route path="/moving-booking" element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }>
            <Route index element={<MovingBookingPage />} />
          </Route>
          
          <Route path="/freight-booking" element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }>
            <Route index element={<FreightBookingPage />} />
          </Route>
          
          {/* 404 Not Found */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Suspense>
    </>
  );
};

export default App;