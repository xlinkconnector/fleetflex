import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { AxiosError } from 'axios';
import api from '../../services/apiClient';
import { setAuthToken, removeAuthToken } from '../../utils/auth';

// Types
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'customer' | 'driver' | 'restaurant' | 'admin';
  isVerified: boolean;
  profile?: {
    avatar?: string;
    phone?: string;
    address?: {
      street?: string;
      city?: string;
      state?: string;
      zipCode?: string;
      country?: string;
    };
  };
}

export interface AuthState {
  user: User | null;
  token: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

interface LoginCredentials {
  email: string;
  password: string;
}

interface RegisterCredentials {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  role?: 'customer' | 'driver' | 'restaurant';
}

interface AuthResponse {
  token: string;
  refreshToken: string;
  data: {
    user: User;
  };
}

// Async thunks
export const login = createAsyncThunk<
  AuthResponse,
  LoginCredentials,
  { rejectValue: string }
>('auth/login', async (credentials, { rejectWithValue }) => {
  try {
    const response = await api.post<AuthResponse>('/api/auth/login', credentials);
    return response.data;
  } catch (error) {
    const axiosError = error as AxiosError<{ error: string }>;
    return rejectWithValue(
      axiosError.response?.data?.error || 'Failed to login. Please try again.'
    );
  }
});

export const register = createAsyncThunk<
  AuthResponse,
  RegisterCredentials,
  { rejectValue: string }
>('auth/register', async (credentials, { rejectWithValue }) => {
  try {
    const response = await api.post<AuthResponse>('/api/auth/register', credentials);
    return response.data;
  } catch (error) {
    const axiosError = error as AxiosError<{ error: string }>;
    return rejectWithValue(
      axiosError.response?.data?.error || 'Failed to register. Please try again.'
    );
  }
});

export const logout = createAsyncThunk('auth/logout', async (_, { rejectWithValue }) => {
  try {
    await api.post('/api/auth/logout');
    return null;
  } catch (error) {
    const axiosError = error as AxiosError<{ error: string }>;
    return rejectWithValue(
      axiosError.response?.data?.error || 'Failed to logout. Please try again.'
    );
  }
});

export const refreshAuth = createAsyncThunk<
  AuthResponse,
  string,
  { rejectValue: string }
>('auth/refresh', async (refreshToken, { rejectWithValue }) => {
  try {
    const response = await api.post<AuthResponse>('/api/auth/refresh-token', {
      refreshToken,
    });
    return response.data;
  } catch (error) {
    const axiosError = error as AxiosError<{ error: string }>;
    return rejectWithValue(
      axiosError.response?.data?.error || 'Failed to refresh token. Please login again.'
    );
  }
});

export const fetchCurrentUser = createAsyncThunk<
  { user: User },
  void,
  { rejectValue: string }
>('auth/fetchCurrentUser', async (_, { rejectWithValue }) => {
  try {
    const response = await api.get<{ data: { user: User } }>('/api/auth/me');
    return { user: response.data.data.user };
  } catch (error) {
    const axiosError = error as AxiosError<{ error: string }>;
    return rejectWithValue(
      axiosError.response?.data?.error || 'Failed to fetch user data.'
    );
  }
});

// Initial state
const initialState: AuthState = {
  user: null,
  token: localStorage.getItem('token'),
  refreshToken: localStorage.getItem('refreshToken'),
  isAuthenticated: !!localStorage.getItem('token'),
  isLoading: false,
  error: null,
};

// Auth slice
const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    updateUser: (state, action: PayloadAction<Partial<User>>) => {
      if (state.user) {
        state.user = { ...state.user, ...action.payload };
      }
    },
  },
  extraReducers: (builder) => {
    // Login
    builder.addCase(login.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(login.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isAuthenticated = true;
      state.user = action.payload.data.user;
      state.token = action.payload.token;
      state.refreshToken = action.payload.refreshToken;
      
      // Save tokens to localStorage
      localStorage.setItem('token', action.payload.token);
      localStorage.setItem('refreshToken', action.payload.refreshToken);
      
      // Set auth token for API requests
      setAuthToken(action.payload.token);
    });
    builder.addCase(login.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload || 'Failed to login';
    });
    
    // Register
    builder.addCase(register.pending, (state) => {
      state.isLoading = true;
      state.error = null;
    });
    builder.addCase(register.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isAuthenticated = true;
      state.user = action.payload.data.user;
      state.token = action.payload.token;
      state.refreshToken = action.payload.refreshToken;
      
      // Save tokens to localStorage
      localStorage.setItem('token', action.payload.token);
      localStorage.setItem('refreshToken', action.payload.refreshToken);
      
      // Set auth token for API requests
      setAuthToken(action.payload.token);
    });
    builder.addCase(register.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload || 'Failed to register';
    });
    
    // Logout
    builder.addCase(logout.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(logout.fulfilled, (state) => {
      state.isLoading = false;
      state.isAuthenticated = false;
      state.user = null;
      state.token = null;
      state.refreshToken = null;
      
      // Remove tokens from localStorage
      localStorage.removeItem('token');
      localStorage.removeItem('refreshToken');
      
      // Remove auth token from API requests
      removeAuthToken();
    });
    builder.addCase(logout.rejected, (state) => {
      state.isLoading = false;
      // Even if logout fails on the server, we still clear the local state
      state.isAuthenticated = false;
      state.user = null;
      state.token = null;
      state.refreshToken = null;
      
      // Remove tokens from localStorage
      localStorage.removeItem('token');
      localStorage.removeItem('refreshToken');
      
      // Remove auth token from API requests
      removeAuthToken();
    });
    
    // Refresh Auth
    builder.addCase(refreshAuth.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(refreshAuth.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isAuthenticated = true;
      state.token = action.payload.token;
      state.refreshToken = action.payload.refreshToken;
      
      // Save tokens to localStorage
      localStorage.setItem('token', action.payload.token);
      localStorage.setItem('refreshToken', action.payload.refreshToken);
      
      // Set auth token for API requests
      setAuthToken(action.payload.token);
    });
    builder.addCase(refreshAuth.rejected, (state) => {
      state.isLoading = false;
      state.isAuthenticated = false;
      state.user = null;
      state.token = null;
      state.refreshToken = null;
      
      // Remove tokens from localStorage
      localStorage.removeItem('token');
      localStorage.removeItem('refreshToken');
      
      // Remove auth token from API requests
      removeAuthToken();
    });
    
    // Fetch Current User
    builder.addCase(fetchCurrentUser.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(fetchCurrentUser.fulfilled, (state, action) => {
      state.isLoading = false;
      state.user = action.payload.user;
    });
    builder.addCase(fetchCurrentUser.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload || 'Failed to fetch user data';
      
      // If fetching user fails due to auth issues, logout
      if (action.error.message?.includes('401')) {
        state.isAuthenticated = false;
        state.user = null;
        state.token = null;
        state.refreshToken = null;
        
        // Remove tokens from localStorage
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
        
        // Remove auth token from API requests
        removeAuthToken();
      }
    });
  },
});

export const { clearError, updateUser } = authSlice.actions;

export default authSlice.reducer;