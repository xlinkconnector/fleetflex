import { createSlice, PayloadAction } from '@reduxjs/toolkit';

// Types
export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  options?: {
    name: string;
    choice: string;
    price: number;
  }[];
  specialInstructions?: string;
  image?: string;
}

export interface CartState {
  items: CartItem[];
  restaurantId: string | null;
  restaurantName: string | null;
  subtotal: number;
  tax: number;
  deliveryFee: number;
  serviceFee: number;
  discount: number;
  total: number;
}

// Helper functions
const calculateItemTotal = (item: CartItem): number => {
  const basePrice = item.price * item.quantity;
  const optionsPrice = item.options?.reduce((sum, option) => sum + option.price, 0) || 0;
  return basePrice + optionsPrice * item.quantity;
};

const calculateCartTotals = (items: CartItem[], tax = 0.0825, deliveryFee = 3.99, serviceFee = 1.99, discount = 0): {
  subtotal: number;
  tax: number;
  deliveryFee: number;
  serviceFee: number;
  discount: number;
  total: number;
} => {
  const subtotal = items.reduce((sum, item) => sum + calculateItemTotal(item), 0);
  const taxAmount = subtotal * tax;
  const total = subtotal + taxAmount + deliveryFee + serviceFee - discount;
  
  return {
    subtotal,
    tax: taxAmount,
    deliveryFee,
    serviceFee,
    discount,
    total,
  };
};

// Get cart from localStorage
const getCartFromStorage = (): CartState => {
  const savedCart = localStorage.getItem('cart');
  if (savedCart) {
    try {
      return JSON.parse(savedCart);
    } catch (error) {
      console.error('Error parsing cart from localStorage:', error);
    }
  }
  
  return {
    items: [],
    restaurantId: null,
    restaurantName: null,
    subtotal: 0,
    tax: 0,
    deliveryFee: 0,
    serviceFee: 0,
    discount: 0,
    total: 0,
  };
};

// Initial state
const initialState: CartState = getCartFromStorage();

// Cart slice
const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addItem: (state, action: PayloadAction<{
      item: CartItem;
      restaurantId: string;
      restaurantName: string;
    }>) => {
      const { item, restaurantId, restaurantName } = action.payload;
      
      // Check if item is from a different restaurant
      if (state.restaurantId && state.restaurantId !== restaurantId) {
        // Replace cart with new restaurant
        state.items = [item];
        state.restaurantId = restaurantId;
        state.restaurantName = restaurantName;
      } else {
        // Check if item already exists in cart
        const existingItemIndex = state.items.findIndex(cartItem => 
          cartItem.id === item.id && 
          JSON.stringify(cartItem.options) === JSON.stringify(item.options)
        );
        
        if (existingItemIndex !== -1) {
          // Update quantity if item exists
          state.items[existingItemIndex].quantity += item.quantity;
        } else {
          // Add new item
          state.items.push(item);
        }
        
        // Set restaurant info if not set
        if (!state.restaurantId) {
          state.restaurantId = restaurantId;
          state.restaurantName = restaurantName;
        }
      }
      
      // Recalculate totals
      const totals = calculateCartTotals(state.items);
      state.subtotal = totals.subtotal;
      state.tax = totals.tax;
      state.deliveryFee = totals.deliveryFee;
      state.serviceFee = totals.serviceFee;
      state.discount = totals.discount;
      state.total = totals.total;
      
      // Save to localStorage
      localStorage.setItem('cart', JSON.stringify(state));
    },
    
    updateItemQuantity: (state, action: PayloadAction<{
      itemIndex: number;
      quantity: number;
    }>) => {
      const { itemIndex, quantity } = action.payload;
      
      if (itemIndex >= 0 && itemIndex < state.items.length) {
        if (quantity > 0) {
          // Update quantity
          state.items[itemIndex].quantity = quantity;
        } else {
          // Remove item if quantity is 0 or negative
          state.items.splice(itemIndex, 1);
        }
        
        // Recalculate totals
        const totals = calculateCartTotals(state.items);
        state.subtotal = totals.subtotal;
        state.tax = totals.tax;
        state.deliveryFee = totals.deliveryFee;
        state.serviceFee = totals.serviceFee;
        state.discount = totals.discount;
        state.total = totals.total;
        
        // Clear restaurant info if cart is empty
        if (state.items.length === 0) {
          state.restaurantId = null;
          state.restaurantName = null;
        }
        
        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(state));
      }
    },
    
    removeItem: (state, action: PayloadAction<number>) => {
      const itemIndex = action.payload;
      
      if (itemIndex >= 0 && itemIndex < state.items.length) {
        // Remove item
        state.items.splice(itemIndex, 1);
        
        // Recalculate totals
        const totals = calculateCartTotals(state.items);
        state.subtotal = totals.subtotal;
        state.tax = totals.tax;
        state.deliveryFee = totals.deliveryFee;
        state.serviceFee = totals.serviceFee;
        state.discount = totals.discount;
        state.total = totals.total;
        
        // Clear restaurant info if cart is empty
        if (state.items.length === 0) {
          state.restaurantId = null;
          state.restaurantName = null;
        }
        
        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(state));
      }
    },
    
    updateItemInstructions: (state, action: PayloadAction<{
      itemIndex: number;
      instructions: string;
    }>) => {
      const { itemIndex, instructions } = action.payload;
      
      if (itemIndex >= 0 && itemIndex < state.items.length) {
        // Update instructions
        state.items[itemIndex].specialInstructions = instructions;
        
        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(state));
      }
    },
    
    applyDiscount: (state, action: PayloadAction<number>) => {
      state.discount = action.payload;
      
      // Recalculate total
      state.total = state.subtotal + state.tax + state.deliveryFee + state.serviceFee - state.discount;
      
      // Save to localStorage
      localStorage.setItem('cart', JSON.stringify(state));
    },
    
    updateFees: (state, action: PayloadAction<{
      deliveryFee?: number;
      serviceFee?: number;
      tax?: number;
    }>) => {
      const { deliveryFee, serviceFee, tax } = action.payload;
      
      if (deliveryFee !== undefined) {
        state.deliveryFee = deliveryFee;
      }
      
      if (serviceFee !== undefined) {
        state.serviceFee = serviceFee;
      }
      
      if (tax !== undefined) {
        state.tax = state.subtotal * tax;
      }
      
      // Recalculate total
      state.total = state.subtotal + state.tax + state.deliveryFee + state.serviceFee - state.discount;
      
      // Save to localStorage
      localStorage.setItem('cart', JSON.stringify(state));
    },
    
    clearCart: (state) => {
      state.items = [];
      state.restaurantId = null;
      state.restaurantName = null;
      state.subtotal = 0;
      state.tax = 0;
      state.deliveryFee = 0;
      state.serviceFee = 0;
      state.discount = 0;
      state.total = 0;
      
      // Save to localStorage
      localStorage.setItem('cart', JSON.stringify(state));
    },
  },
});

export const {
  addItem,
  updateItemQuantity,
  removeItem,
  updateItemInstructions,
  applyDiscount,
  updateFees,
  clearCart,
} = cartSlice.actions;

export default cartSlice.reducer;