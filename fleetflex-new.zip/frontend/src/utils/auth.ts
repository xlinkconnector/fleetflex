import apiClient from '../services/apiClient';

/**
 * Set the authentication token in axios headers
 * @param token - JWT token
 */
export const setAuthToken = (token: string): void => {
  if (token) {
    apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete apiClient.defaults.headers.common['Authorization'];
  }
};

/**
 * Remove the authentication token from axios headers
 */
export const removeAuthToken = (): void => {
  delete apiClient.defaults.headers.common['Authorization'];
};

/**
 * Check if the current token is expired
 * @param token - JWT token
 * @returns boolean indicating if token is expired
 */
export const isTokenExpired = (token: string): boolean => {
  if (!token) return true;
  
  try {
    // Get the expiration time from the token
    const payload = JSON.parse(atob(token.split('.')[1]));
    const exp = payload.exp * 1000; // Convert to milliseconds
    
    // Check if token is expired
    return Date.now() >= exp;
  } catch (error) {
    return true; // If there's an error parsing the token, consider it expired
  }
};

/**
 * Get user role from token
 * @param token - JWT token
 * @returns user role or null if token is invalid
 */
export const getUserRoleFromToken = (token: string): string | null => {
  if (!token) return null;
  
  try {
    // Get the payload from the token
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.role || null;
  } catch (error) {
    return null;
  }
};

/**
 * Get user ID from token
 * @param token - JWT token
 * @returns user ID or null if token is invalid
 */
export const getUserIdFromToken = (token: string): string | null => {
  if (!token) return null;
  
  try {
    // Get the payload from the token
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.id || null;
  } catch (error) {
    return null;
  }
};

/**
 * Check if user has required role
 * @param userRole - Current user role
 * @param requiredRoles - Array of required roles
 * @returns boolean indicating if user has required role
 */
export const hasRequiredRole = (
  userRole: string | null, 
  requiredRoles: string[]
): boolean => {
  if (!userRole) return false;
  return requiredRoles.includes(userRole);
};