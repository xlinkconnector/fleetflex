import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import { SunIcon, MoonIcon, ComputerDesktopIcon } from '@heroicons/react/24/outline';

const AuthLayout: React.FC = () => {
  const { theme, changeTheme } = useTheme();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col">
      {/* Header */}
      <header className="py-4 px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold text-primary-600 dark:text-primary-400">
              FleetFlex
            </span>
          </Link>

          {/* Theme toggle */}
          <div className="flex space-x-2">
            <button
              type="button"
              onClick={() => changeTheme('light')}
              className={`p-1.5 rounded-md ${
                theme === 'light'
                  ? 'bg-primary-100 text-primary-600 dark:bg-gray-700 dark:text-primary-400'
                  : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
              }`}
            >
              <SunIcon className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => changeTheme('dark')}
              className={`p-1.5 rounded-md ${
                theme === 'dark'
                  ? 'bg-primary-100 text-primary-600 dark:bg-gray-700 dark:text-primary-400'
                  : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
              }`}
            >
              <MoonIcon className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => changeTheme('system')}
              className={`p-1.5 rounded-md ${
                theme === 'system'
                  ? 'bg-primary-100 text-primary-600 dark:bg-gray-700 dark:text-primary-400'
                  : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
              }`}
            >
              <ComputerDesktopIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md">
          <Outlet />
        </div>
      </main>

      {/* Footer */}
      <footer className="py-4 px-4 sm:px-6 lg:px-8 text-center text-sm text-gray-500 dark:text-gray-400">
        <div className="space-x-4">
          <Link to="/terms" className="hover:text-gray-700 dark:hover:text-gray-300">
            Terms of Service
          </Link>
          <Link to="/privacy" className="hover:text-gray-700 dark:hover:text-gray-300">
            Privacy Policy
          </Link>
          <Link to="/help" className="hover:text-gray-700 dark:hover:text-gray-300">
            Help Center
          </Link>
        </div>
        <div className="mt-2">
          &copy; {new Date().getFullYear()} FleetFlex. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default AuthLayout;