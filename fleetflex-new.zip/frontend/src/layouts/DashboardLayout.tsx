import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

// Icons
import {
  Bars3Icon,
  XMarkIcon,
  UserIcon,
  ShoppingBagIcon,
  CreditCardIcon,
  HomeIcon,
  TruckIcon,
  MapPinIcon,
  BellIcon,
  Cog6ToothIcon,
  ArrowRightOnRectangleIcon,
  SunIcon,
  MoonIcon,
  ComputerDesktopIcon,
  BuildingStorefrontIcon,
  UserGroupIcon,
  ChartBarIcon,
  ShieldCheckIcon,
} from '@heroicons/react/24/outline';

const DashboardLayout: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user, logout } = useAuth();
  const { theme, changeTheme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();

  // Handle logout
  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  // Navigation links based on user role
  const getNavLinks = () => {
    // Common links for all users
    const commonLinks = [
      { name: 'Dashboard', path: '/dashboard', icon: HomeIcon },
      { name: 'Orders', path: '/dashboard/orders', icon: ShoppingBagIcon },
      { name: 'Profile', path: '/dashboard/profile', icon: UserIcon },
      { name: 'Payment Methods', path: '/dashboard/payment-methods', icon: CreditCardIcon },
      { name: 'Addresses', path: '/dashboard/addresses', icon: MapPinIcon },
    ];

    // Role-specific links
    if (user?.role === 'driver') {
      return [
        ...commonLinks,
        { name: 'My Vehicles', path: '/dashboard/vehicles', icon: TruckIcon },
        { name: 'Earnings', path: '/dashboard/earnings', icon: ChartBarIcon },
        { name: 'Schedule', path: '/dashboard/schedule', icon: MapPinIcon },
      ];
    } else if (user?.role === 'restaurant') {
      return [
        ...commonLinks,
        { name: 'My Restaurants', path: '/dashboard/restaurants', icon: BuildingStorefrontIcon },
        { name: 'Menu Management', path: '/dashboard/menu', icon: Cog6ToothIcon },
        { name: 'Analytics', path: '/dashboard/analytics', icon: ChartBarIcon },
      ];
    } else if (user?.role === 'admin') {
      return [
        { name: 'Dashboard', path: '/dashboard', icon: HomeIcon },
        { name: 'Users', path: '/dashboard/users', icon: UserGroupIcon },
        { name: 'Restaurants', path: '/dashboard/restaurants', icon: BuildingStorefrontIcon },
        { name: 'Drivers', path: '/dashboard/drivers', icon: TruckIcon },
        { name: 'Orders', path: '/dashboard/orders', icon: ShoppingBagIcon },
        { name: 'Analytics', path: '/dashboard/analytics', icon: ChartBarIcon },
        { name: 'Settings', path: '/dashboard/settings', icon: Cog6ToothIcon },
      ];
    }

    return commonLinks;
  };

  const navLinks = getNavLinks();

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-gray-900 bg-opacity-50 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-30 w-64 transform bg-white dark:bg-gray-800 shadow-lg transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar header */}
          <div className="flex items-center justify-between px-4 py-5 border-b border-gray-200 dark:border-gray-700">
            <Link to="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                FleetFlex
              </span>
            </Link>
            <button
              onClick={() => setIsSidebarOpen(false)}
              className="p-1 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700 lg:hidden"
            >
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>

          {/* User info */}
          <div className="flex items-center space-x-3 px-4 py-5 border-b border-gray-200 dark:border-gray-700">
            <div className="flex-shrink-0">
              {user?.profile?.avatar ? (
                <img
                  src={user.profile.avatar}
                  alt={`${user.firstName} ${user.lastName}`}
                  className="h-10 w-10 rounded-full object-cover"
                />
              ) : (
                <div className="h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                  <UserIcon className="h-6 w-6 text-primary-600 dark:text-primary-400" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                {user?.firstName} {user?.lastName}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                {user?.email}
              </p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  location.pathname === link.path
                    ? 'bg-primary-50 text-primary-700 dark:bg-gray-700 dark:text-primary-400'
                    : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                }`}
              >
                <link.icon className="mr-3 h-5 w-5" />
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Sidebar footer */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Theme
              </span>
              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => changeTheme('light')}
                  className={`p-1.5 rounded-md ${
                    theme === 'light'
                      ? 'bg-primary-100 text-primary-600 dark:bg-gray-700 dark:text-primary-400'
                      : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
                  }`}
                >
                  <SunIcon className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={() => changeTheme('dark')}
                  className={`p-1.5 rounded-md ${
                    theme === 'dark'
                      ? 'bg-primary-100 text-primary-600 dark:bg-gray-700 dark:text-primary-400'
                      : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
                  }`}
                >
                  <MoonIcon className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={() => changeTheme('system')}
                  className={`p-1.5 rounded-md ${
                    theme === 'system'
                      ? 'bg-primary-100 text-primary-600 dark:bg-gray-700 dark:text-primary-400'
                      : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
                  }`}
                >
                  <ComputerDesktopIcon className="h-5 w-5" />
                </button>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center justify-center w-full px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              <ArrowRightOnRectangleIcon className="mr-2 h-5 w-5" />
              Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 shadow-sm z-10">
          <div className="px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              {/* Mobile menu button */}
              <button
                onClick={() => setIsSidebarOpen(true)}
                className="lg:hidden p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700"
              >
                <Bars3Icon className="h-6 w-6" />
              </button>

              {/* Header right */}
              <div className="flex items-center space-x-4">
                {/* Notifications */}
                <button className="p-1 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700 relative">
                  <BellIcon className="h-6 w-6" />
                  <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white dark:ring-gray-800"></span>
                </button>

                {/* Settings */}
                <Link
                  to="/dashboard/settings"
                  className="p-1 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700"
                >
                  <Cog6ToothIcon className="h-6 w-6" />
                </Link>

                {/* Back to main site */}
                <Link
                  to="/"
                  className="hidden sm:inline-flex items-center px-3 py-1 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 dark:text-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600"
                >
                  <HomeIcon className="mr-1 h-4 w-4" />
                  Main Site
                </Link>
              </div>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900 p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;