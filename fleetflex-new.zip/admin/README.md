# FleetFlex Admin Dashboard

The FleetFlex Admin Dashboard is a comprehensive management system for the FleetFlex multi-service logistics platform. It provides administrators with tools to manage users, restaurants, drivers, orders, and system settings.

## Features

### User Management
- User list with search, filter, and pagination
- User details view with edit capabilities
- User creation with role assignment
- Bulk actions (export, edit, notifications)
- User analytics and registration trends
- Permission management with role-based access control

### Registration Approval System
- Pending registrations queue
- Auto-approval rules configuration
- Document verification for KYC
- Email notifications for approvals/rejections
- Audit trail for approval decisions

### KYC Management System
- Document upload and verification
- Multi-step approval process
- Risk assessment scoring
- Manual review capabilities
- Compliance reporting
- Encrypted document storage

### Content Management
- Page builder with drag-and-drop functionality
- Custom CSS/JS injection
- Media library with CDN integration
- Blog system for content marketing
- Legal pages management
- Multilingual content support

### Service Management
- Restaurant onboarding and approval workflow
- Driver verification and vehicle registration
- Service configuration (pricing, availability, service areas)
- Quality control with rating and review moderation
- Service-specific analytics

### Financial Management
- Transaction monitoring in real-time
- Revenue analytics and reporting
- Payout management for drivers and restaurants
- Refund processing
- Commission structure configuration

### System Administration
- Server monitoring dashboard
- API analytics and endpoint usage metrics
- Security logs and access monitoring
- Backup management
- Environment variable configuration

## Technology Stack

- **Frontend**: React 18 with TypeScript
- **State Management**: Redux Toolkit
- **UI Components**: Tailwind CSS, Headless UI
- **Data Visualization**: Recharts
- **Form Handling**: React Hook Form
- **API Communication**: React Query, Axios
- **Authentication**: JWT with refresh tokens
- **Real-time Updates**: Socket.io

## Getting Started

### Prerequisites
- Node.js 16+
- npm 8+

### Installation

1. Clone the repository
```bash
git clone https://github.com/your-org/fleetflex.git
cd fleetflex/admin
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
cp .env.example .env
```

4. Start the development server
```bash
npm run dev
```

5. Build for production
```bash
npm run build
```

## Project Structure

```
admin/
├── public/
├── src/
│   ├── components/
│   │   ├── common/
│   │   ├── dashboard/
│   │   ├── forms/
│   │   ├── layout/
│   │   ├── tables/
│   │   └── ui/
│   ├── hooks/
│   ├── pages/
│   │   ├── analytics/
│   │   ├── auth/
│   │   ├── content/
│   │   ├── dashboard/
│   │   ├── financial/
│   │   ├── restaurants/
│   │   ├── settings/
│   │   ├── system/
│   │   └── users/
│   ├── services/
│   ├── store/
│   │   ├── slices/
│   │   └── index.ts
│   ├── utils/
│   ├── App.tsx
│   └── main.tsx
├── .env.example
├── index.html
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── vite.config.ts
```

## Key Features Implementation

### User Management
The admin dashboard provides a comprehensive user management system with the ability to view, create, edit, and delete users. Administrators can filter users by role, status, and other criteria, and perform bulk actions on selected users.

### KYC Verification
The KYC verification system allows administrators to review and approve user documents for identity verification. The system supports multiple verification levels and provides tools for risk assessment.

### Restaurant Management
Administrators can manage restaurant profiles, menus, and orders. The system provides tools for restaurant approval, menu management, and order tracking.

### Driver Management
The driver management system allows administrators to verify driver documents, manage vehicles, and track driver performance.

### Order Management
The order management system provides tools for tracking orders across all services, managing refunds, and resolving disputes.

### Analytics Dashboard
The analytics dashboard provides insights into platform performance, user behavior, and financial metrics. Administrators can view charts and reports for various metrics and export data for further analysis.

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.