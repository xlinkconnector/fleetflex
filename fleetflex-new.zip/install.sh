#!/bin/bash

# FleetFlex Multi-Service Logistics Platform Installation Script
# This script will install and configure the entire platform

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

info() {
    echo -e "${BLUE}[INFO] $1${NC}"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   warning "This script is being run as root. It's recommended to run as a non-root user with sudo privileges."
fi

# Check system requirements
check_requirements() {
    log "Checking system requirements..."
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        warning "Docker is not installed. Installing Docker..."
        curl -fsSL https://get.docker.com -o get-docker.sh
        sh get-docker.sh
        sudo usermod -aG docker $USER
        info "Docker installed successfully. You may need to log out and back in for group changes to take effect."
    else
        info "Docker is already installed."
    fi
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        warning "Docker Compose is not installed. Installing Docker Compose..."
        sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        sudo chmod +x /usr/local/bin/docker-compose
        info "Docker Compose installed successfully."
    else
        info "Docker Compose is already installed."
    fi
    
    # Check Node.js (for development purposes)
    if ! command -v node &> /dev/null; then
        warning "Node.js is not installed. Installing Node.js 18.x..."
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        sudo apt-get install -y nodejs
        info "Node.js installed successfully."
    else
        info "Node.js is already installed."
    fi
    
    log "System requirements check completed."
}

# Setup environment files
setup_environment() {
    log "Setting up environment files..."
    
    # Copy environment files if they don't exist
    if [ ! -f .env ]; then
        cp .env.example .env
        log "Main .env file created. Please update it with your configuration."
    fi
    
    # Generate random secrets for JWT
    JWT_SECRET=$(openssl rand -hex 32)
    REFRESH_TOKEN_SECRET=$(openssl rand -hex 32)
    
    # Update .env file with generated secrets
    sed -i "s/your_jwt_secret_key_change_this_in_production/$JWT_SECRET/g" .env
    sed -i "s/your_refresh_token_secret_key_change_this_in_production/$REFRESH_TOKEN_SECRET/g" .env
    
    log "Environment setup completed."
}

# Setup SSL certificates
setup_ssl() {
    log "Setting up SSL certificates..."
    
    # Create SSL directory
    mkdir -p nginx/ssl
    
    # Generate self-signed certificates for development
    if [ ! -f nginx/ssl/fleetflex.crt ]; then
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout nginx/ssl/fleetflex.key \
            -out nginx/ssl/fleetflex.crt \
            -subj "/C=US/ST=State/L=City/O=FleetFlex/CN=fleetflex.com"
        
        log "SSL certificates generated for development."
    else
        info "SSL certificates already exist."
    fi
}

# Create necessary directories
create_directories() {
    log "Creating necessary directories..."
    
    # Create directories if they don't exist
    mkdir -p backend/uploads
    mkdir -p backend/logs
    mkdir -p nginx/logs
    
    log "Directories created."
}

# Build and start services
start_services() {
    log "Building and starting services..."
    
    # Build and start all services with Docker Compose
    docker-compose up -d --build
    
    # Wait for services to be ready
    log "Waiting for services to be ready..."
    sleep 10
    
    # Check service health
    log "Checking service health..."
    
    # Check if containers are running
    if [ "$(docker ps -q -f name=fleetflex-backend)" ]; then
        info "Backend service is running."
    else
        error "Backend service failed to start."
    fi
    
    if [ "$(docker ps -q -f name=fleetflex-frontend)" ]; then
        info "Frontend service is running."
    else
        error "Frontend service failed to start."
    fi
    
    if [ "$(docker ps -q -f name=fleetflex-admin)" ]; then
        info "Admin service is running."
    else
        error "Admin service failed to start."
    fi
    
    if [ "$(docker ps -q -f name=fleetflex-mongodb)" ]; then
        info "MongoDB service is running."
    else
        error "MongoDB service failed to start."
    fi
    
    if [ "$(docker ps -q -f name=fleetflex-redis)" ]; then
        info "Redis service is running."
    else
        error "Redis service failed to start."
    fi
    
    log "Services started successfully."
}

# Seed database with initial data
seed_database() {
    log "Seeding database with initial data..."
    
    # Execute seed script inside the backend container
    docker exec fleetflex-backend node src/scripts/seed.js
    
    log "Database seeded successfully."
}

# Setup hosts file for local development
setup_hosts() {
    log "Setting up hosts file for local development..."
    
    # Check if entries already exist
    if grep -q "fleetflex.com" /etc/hosts; then
        info "Host entries already exist."
    else
        # Add entries to hosts file
        echo "127.0.0.1 fleetflex.com www.fleetflex.com api.fleetflex.com admin.fleetflex.com" | sudo tee -a /etc/hosts > /dev/null
        log "Host entries added to /etc/hosts file."
    fi
}

# Display installation summary
display_summary() {
    log "FleetFlex installation completed successfully!"
    echo ""
    echo -e "${GREEN}=== FleetFlex Services ===${NC}"
    echo -e "${BLUE}Frontend:${NC} https://fleetflex.com (http://localhost:3000)"
    echo -e "${BLUE}Admin Dashboard:${NC} https://admin.fleetflex.com (http://localhost:3001)"
    echo -e "${BLUE}API:${NC} https://api.fleetflex.com (http://localhost:5000)"
    echo -e "${BLUE}MongoDB:${NC} mongodb://localhost:27017"
    echo -e "${BLUE}Redis:${NC} redis://localhost:6379"
    echo ""
    echo -e "${YELLOW}Note: For HTTPS access, you'll need to accept the self-signed certificate in your browser.${NC}"
    echo ""
    echo -e "${GREEN}=== Management Commands ===${NC}"
    echo -e "${BLUE}Start services:${NC} docker-compose up -d"
    echo -e "${BLUE}Stop services:${NC} docker-compose down"
    echo -e "${BLUE}View logs:${NC} docker-compose logs -f [service_name]"
    echo -e "${BLUE}Restart a service:${NC} docker-compose restart [service_name]"
    echo ""
    echo -e "${GREEN}Thank you for installing FleetFlex!${NC}"
}

# Main installation function
main() {
    log "Starting FleetFlex installation..."
    
    check_requirements
    setup_environment
    setup_ssl
    create_directories
    start_services
    seed_database
    setup_hosts
    display_summary
}

# Run installation
main "$@"