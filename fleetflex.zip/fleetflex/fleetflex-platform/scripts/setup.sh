#!/bin/bash

echo "🚀 Setting up FleetFlex Multi-Service Logistics Platform..."

# Install backend dependencies
echo "📦 Installing backend dependencies..."
cd backend
npm install

# Create .env file
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo "⚠️  Please update the .env file with your actual configuration"
fi

# Install frontend dependencies
echo "📦 Installing frontend dependencies..."
cd ../frontend
npm install

echo "✅ Setup complete!"
echo ""
echo "🎉 To start the development servers:"
echo "   npm run dev"
echo ""
echo "📋 Available commands:"
echo "   npm run dev          - Start all development servers"
echo "   npm run dev:backend  - Start backend server only"
echo "   npm run dev:frontend - Start frontend server only"
echo "   npm start            - Start production backend server"
echo ""
echo "🔗 Access the application:"
echo "   Frontend: http://localhost:5173"
echo "   Backend:  http://localhost:5000"
echo "   API Docs: http://localhost:5000/api-docs"