import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Star, Truck, Package, Users, Shield } from 'lucide-react';

const Home = () => {
  const services = [
    {
      id: 'food',
      title: 'Food Delivery',
      description: 'Order from your favorite restaurants with fast delivery',
      icon: '🍕',
      color: 'bg-red-500',
      path: '/food',
    },
    {
      id: 'rides',
      title: 'Rideshare',
      description: 'Safe and reliable rides to anywhere you need to go',
      icon: '🚗',
      color: 'bg-blue-500',
      path: '/rides',
    },
    {
      id: 'shipping',
      title: 'Package Shipping',
      description: 'Send and receive packages with real-time tracking',
      icon: '📦',
      color: 'bg-green-500',
      path: '/shipping',
    },
    {
      id: 'moving',
      title: 'Moving Services',
      description: 'Professional movers for your home or office relocation',
      icon: '🏠',
      color: 'bg-purple-500',
      path: '/moving',
    },
    {
      id: 'freight',
      title: 'Freight Transport',
      description: 'Heavy cargo and freight transportation solutions',
      icon: '🚛',
      color: 'bg-orange-500',
      path: '/freight',
    },
  ];

  const features = [
    {
      icon: <Star className="h-8 w-8" />,
      title: 'Unified Platform',
      description: 'Access all services with one account',
    },
    {
      icon: <Truck className="h-8 w-8" />,
      title: 'Real-time Tracking',
      description: 'Track your orders and deliveries in real-time',
    },
    {
      icon: <Package className="h-8 w-8" />,
      title: 'Secure Payments',
      description: 'Safe and secure payment processing',
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: '24/7 Support',
      description: 'Customer support available around the clock',
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: 'Verified Providers',
      description: 'All service providers are background checked',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-6xl font-bold mb-6"
            >
              Your Complete Logistics Platform
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl md:text-2xl mb-8 opacity-90"
            >
              Food delivery, rideshare, shipping, moving, and freight - all in one place
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link
                to="/register"
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Get Started
              </Link>
              <Link
                to="/food"
                className="border-2 border-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
              >
                Explore Services
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              All Your Logistics Needs in One Platform
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Choose from our comprehensive suite of services designed to make your life easier
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow"
              >
                <div className={`${service.color} w-16 h-16 rounded-lg flex items-center justify-center mb-4`}>
                  <span className="text-3xl">{service.icon}</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <Link
                  to={service.path}
                  className="inline-flex items-center text-blue-600 font-semibold hover:text-blue-700"
                >
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose FleetFlex?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience the difference with our unified logistics platform
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-4">
                  <div className="bg-blue-100 text-blue-600 w-16 h-16 rounded-full flex items-center justify-center">
                    {feature.icon}
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-white mb-8 opacity-90">
            Join thousands of satisfied customers using FleetFlex
          </p>
          <Link
            to="/register"
            className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
          >
            Create Your Account
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;