import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Package, Truck, Car, Home, DollarSign, Clock, MapPin, Star } from 'lucide-react';
import api from '../../services/api';

const CustomerDashboard = () => {
  const { user } = useSelector(state => state.auth);
  const [orders, setOrders] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Fetch recent orders from all services
      const [foodOrders, rides, shipping, moving] = await Promise.all([
        api.get('/food/orders?limit=5'),
        api.get('/rides/history?limit=5'),
        api.get('/shipping/orders?limit=5'),
        api.get('/moving/jobs?limit=5')
      ]);

      setOrders({
        food: foodOrders.data.data,
        rides: rides.data.data,
        shipping: shipping.data.data,
        moving: moving.data.data
      });

      setStats({
        totalOrders: [
          ...(foodOrders.data.data || []),
          ...(rides.data.data || []),
          ...(shipping.data.data || []),
          ...(moving.data.data || [])
        ].length
      });

      setLoading(false);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setLoading(false);
    }
  };

  const serviceCards = [
    {
      title: 'Food Delivery',
      icon: '🍕',
      path: '/food',
      description: 'Order from restaurants',
      color: 'bg-red-500'
    },
    {
      title: 'Rideshare',
      icon: '🚗',
      path: '/rides',
      description: 'Book a ride',
      color: 'bg-blue-500'
    },
    {
      title: 'Package Shipping',
      icon: '📦',
      path: '/shipping',
      description: 'Send packages',
      color: 'bg-green-500'
    },
    {
      title: 'Moving Services',
      icon: '🏠',
      path: '/moving',
      description: 'Get moving quotes',
      color: 'bg-purple-500'
    },
    {
      title: 'Freight Transport',
      icon: '🚛',
      path: '/freight',
      description: 'Ship heavy cargo',
      color: 'bg-orange-500'
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user?.firstName}!</h1>
          <p className="text-gray-600 mt-2">Manage all your services in one place</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Orders</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalOrders || 0}</p>
              </div>
              <Package className="h-8 w-8 text-blue-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Orders</p>
                <p className="text-2xl font-bold text-gray-900">3</p>
              </div>
              <Clock className="h-8 w-8 text-green-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Account Balance</p>
                <p className="text-2xl font-bold text-gray-900">$247.50</p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Rating</p>
                <p className="text-2xl font-bold text-gray-900">4.8⭐</p>
              </div>
              <Star className="h-8 w-8 text-yellow-600" />
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {serviceCards.map((service) => (
              <Link
                key={service.title}
                to={service.path}
                className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow"
              >
                <div className="text-center">
                  <div className={`${service.color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <span className="text-2xl">{service.icon}</span>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">{service.title}</h3>
                  <p className="text-sm text-gray-600">{service.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Orders */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Recent Orders</h3>
            <div className="space-y-4">
              {orders.food?.slice(0, 3).map((order) => (
                <div key={order._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">Food Order #{order.orderNumber}</p>
                    <p className="text-sm text-gray-600">{order.status}</p>
                  </div>
                  <span className="text-sm text-gray-500">{new Date(order.createdAt).toLocaleDateString()}</span>
                </div>
              ))}
              
              {orders.rides?.slice(0, 3).map((ride) => (
                <div key={ride._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">Ride #{ride.requestNumber}</p>
                    <p className="text-sm text-gray-600">{ride.status}</p>
                  </div>
                  <span className="text-sm text-gray-500">{new Date(ride.createdAt).toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Service Usage</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Food Orders</span>
                <span className="font-semibold">{orders.food?.length || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Rides</span>
                <span className="font-semibold">{orders.rides?.length || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Shipping Orders</span>
                <span className="font-semibold">{orders.shipping?.length || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Moving Jobs</span>
                <span className="font-semibold">{orders.moving?.length || 0}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Service Provider Dashboard (if applicable) */}
        {user?.roles?.includes('restaurant-owner') && (
          <div className="mt-8 bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Provider Dashboard</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">12</p>
                <p className="text-gray-600">Active Orders</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">4.9⭐</p>
                <p className="text-gray-600">Average Rating</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">$1,247</p>
                <p className="text-gray-600">This Week</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomerDashboard;