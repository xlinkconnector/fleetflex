import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';

const ServiceTabs = () => {
  const location = useLocation();
  const { user } = useSelector(state => state.auth);

  const services = [
    { id: 'food', name: 'Food Delivery', icon: '🍕', path: '/food' },
    { id: 'rides', name: 'Rideshare', icon: '🚗', path: '/rides' },
    { id: 'shipping', name: 'Package Shipping', icon: '📦', path: '/shipping' },
    { id: 'moving', name: 'Moving Services', icon: '🏠', path: '/moving' },
    { id: 'freight', name: 'Freight Transport', icon: '🚛', path: '/freight' },
  ];

  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <div className="bg-white border-b">
      <div className="container mx-auto px-4">
        <div className="flex space-x-8 overflow-x-auto py-2">
          {services.map((service) => (
            <Link
              key={service.id}
              to={service.path}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${
                isActive(service.path)
                  ? 'bg-blue-100 text-blue-700 border-b-2 border-blue-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <span className="text-xl">{service.icon}</span>
              <span>{service.name}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServiceTabs;