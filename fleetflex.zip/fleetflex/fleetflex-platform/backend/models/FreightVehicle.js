const mongoose = require('mongoose');

const freightVehicleSchema = new mongoose.Schema({
  carrierId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  vehicleType: {
    type: String,
    enum: ['dry-van', 'refrigerated', 'flatbed', 'box-truck'],
    required: true
  },
  specifications: {
    length: {
      type: Number,
      required: true
    },
    width: {
      type: Number,
      required: true
    },
    height: {
      type: Number,
      required: true
    },
    maxWeight: {
      type: Number,
      required: true
    },
    features: [{
      type: String
    }]
  },
  currentLocation: {
    lat: Number,
    lng: Number,
    lastUpdated: {
      type: Date,
      default: Date.now
    }
  },
  availability: {
    isAvailable: {
      type: Boolean,
      default: true
    },
    availableDate: {
      type: Date,
      default: Date.now
    },
    currentLocation: String
  },
  documentation: {
    registration: String,
    insurance: String,
    inspection: Date
  },
  images: [{
    type: String
  }],
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('FreightVehicle', freightVehicleSchema);