const mongoose = require('mongoose');

const rideRequestSchema = new mongoose.Schema({
  requestNumber: {
    type: String,
    required: true,
    unique: true
  },
  passengerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  driverId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  rideType: {
    type: String,
    enum: ['standard', 'premium', 'shared', 'xl'],
    required: true
  },
  pickup: {
    address: {
      type: String,
      required: true
    },
    lat: {
      type: Number,
      required: true
    },
    lng: {
      type: Number,
      required: true
    },
    instructions: String
  },
  destination: {
    address: {
      type: String,
      required: true
    },
    lat: {
      type: Number,
      required: true
    },
    lng: {
      type: Number,
      required: true
    },
    instructions: String
  },
  estimatedDistance: {
    type: Number,
    required: true
  },
  estimatedDuration: {
    type: Number,
    required: true
  },
  pricing: {
    baseFare: {
      type: Number,
      required: true
    },
    distanceFare: {
      type: Number,
      required: true
    },
    timeFare: {
      type: Number,
      required: true
    },
    surgePricing: {
      type: Number,
      default: 1
    },
    tip: {
      type: Number,
      default: 0
    },
    total: {
      type: Number,
      required: true
    }
  },
  status: {
    type: String,
    enum: ['requested', 'accepted', 'arriving', 'picked-up', 'in-progress', 'completed', 'cancelled'],
    default: 'requested'
  },
  scheduledTime: Date,
  actualPickupTime: Date,
  actualDropoffTime: Date,
  route: [{
    lat: Number,
    lng: Number,
    timestamp: Date
  }],
  payment: {
    method: {
      type: String,
      enum: ['card', 'cash', 'wallet'],
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'pending'
    },
    transactionId: String,
    stripePaymentIntentId: String
  },
  rating: {
    passenger: {
      rating: Number,
      review: String
    },
    driver: {
      rating: Number,
      review: String
    }
}, {
  timestamps: true
});

// Generate request number before saving
rideRequestSchema.pre('save', function(next) {
  if (this.isNew) {
    this.requestNumber = 'RS' + Date.now().toString().slice(-8) + Math.random().toString(36).substr(2, 4).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('RideRequest', rideRequestSchema);