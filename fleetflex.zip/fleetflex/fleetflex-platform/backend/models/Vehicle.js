const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema({
  driverId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  make: {
    type: String,
    required: true
  },
  model: {
    type: String,
    required: true
  },
  year: {
    type: Number,
    required: true
  },
  color: {
    type: String,
    required: true
  },
  licensePlate: {
    type: String,
    required: true,
    unique: true
  },
  vehicleType: {
    type: String,
    enum: ['sedan', 'suv', 'truck', 'van'],
    required: true
  },
  capacity: {
    type: Number,
    required: true
  },
  features: [{
    type: String
  }],
  inspection: {
    lastInspection: Date,
    nextDue: Date,
    status: {
      type: String,
      enum: ['passed', 'failed', 'pending']
    }
  },
  insurance: {
    provider: String,
    policyNumber: String,
    expiration: Date
  },
  images: [{
    type: String
  }],
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Vehicle', vehicleSchema);