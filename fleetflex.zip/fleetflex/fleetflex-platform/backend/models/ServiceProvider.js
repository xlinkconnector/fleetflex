const mongoose = require('mongoose');

const serviceProviderSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  serviceType: {
    type: String,
    required: true,
    enum: ['restaurant', 'driver', 'mover', 'freight-carrier']
  },
  businessName: {
    type: String,
    required: true
  },
  businessType: {
    type: String,
    required: true
  },
  licenseNumber: {
    type: String,
    required: true
  },
  insuranceInfo: {
    provider: String,
    policyNumber: String,
    expirationDate: Date
  },
  serviceAreas: [{
    type: String
  }],
  isApproved: {
    type: Boolean,
    default: false
  },
  rating: {
    type: Number,
    default: 0
  },
  totalJobs: {
    type: Number,
    default: 0
  },
  documents: [{
    type: {
      type: String,
      enum: ['license', 'insurance', 'registration', 'background-check', 'vehicle-registration']
    },
    url: String,
    verified: {
      type: Boolean,
      default: false
    },
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  availability: {
    status: {
      type: String,
      enum: ['available', 'busy', 'offline'],
      default: 'offline'
    },
    lastUpdated: {
      type: Date,
      default: Date.now
    }
  },
  currentLocation: {
    lat: Number,
    lng: Number,
    lastUpdated: {
      type: Date,
      default: Date.now
    }
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('ServiceProvider', serviceProviderSchema);