# FleetFlex Deployment Guide

## Production Deployment

### 1. Server Requirements
- **OS**: Ubuntu 20.04+ or AlmaLinux 8+
- **Node.js**: 18.x LTS
- **MongoDB**: 5.x+
- **Redis**: 6.x+
- **Nginx**: 1.18+ (reverse proxy)
- **PM2**: Process manager

### 2. Environment Setup

```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install MongoDB
wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list
sudo apt update
sudo apt install -y mongodb-org

# Install Redis
sudo apt install -y redis-server

# Install PM2
npm install -g pm2

# Install Nginx
sudo apt install -y nginx
```

### 3. Application Deployment

```bash
# Clone repository
git clone <repository-url>
cd fleetflex-platform

# Install dependencies
npm run install:all

# Build frontend
cd frontend
npm run build
cd ..

# Configure production environment
cd backend
cp .env.example .env.production
# Edit .env.production with production values

# Start with PM2
pm2 start ecosystem.config.js

# Setup Nginx
sudo nano /etc/nginx/sites-available/fleetflex
```

### 4. Nginx Configuration

```nginx
# /etc/nginx/sites-available/fleetflex
server {
    listen 80;
    server_name fleetflex.app www.fleetflex.app;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name fleetflex.app www.fleetflex.app;

    ssl_certificate /etc/letsencrypt/live/fleetflex.app/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/fleetflex.app/privkey.pem;

    # Frontend
    location / {
        root /var/www/fleetflex/frontend/dist;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # API
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket
    location /socket.io {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

### 5. SSL Certificate (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d fleetflex.app -d www.fleetflex.app
```

### 6. Database Setup

```bash
# Create database
mongo
use fleetflex
db.createUser({
  user: "fleetflex",
  pwd: "secure_password",
  roles: ["readWrite"]
})

# Create indexes
mongo fleetflex
db.users.createIndex({ email: 1 }, { unique: true })
db.restaurants.createIndex({ 'address.lat': 1, 'address.lng': 1 })
```

### 7. Monitoring Setup

```bash
# Install monitoring tools
npm install -g pm2-logrotate
pm2 install pm2-logrotate

# Setup health checks
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 7

# View logs
pm2 logs
pm2 monit
```

### 8. CI/CD Pipeline (GitHub Actions)

```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '18'
    
    - name: Install dependencies
      run: |
        npm run install:all
    
    - name: Run tests
      run: |
        npm test
    
    - name: Build frontend
      run: |
        cd frontend
        npm run build
    
    - name: Deploy to server
      uses: appleboy/ssh-action@master
      with:
        host: ${{ secrets.HOST }}
        username: ${{ secrets.USERNAME }}
        key: ${{ secrets.SSH_KEY }}
        script: |
          cd /var/www/fleetflex
          git pull origin main
          npm run install:all
          npm run build
          pm2 restart all
```

### 9. Environment Variables

```bash
# Production .env
NODE_ENV=production
PORT=5000
HOST=0.0.0.0

# Database
MONGODB_URI=mongodb://fleetflex:password@localhost:27017/fleetflex
REDIS_URL=redis://localhost:6379

# Security
JWT_SECRET=production_jwt_secret_key
JWT_EXPIRES_IN=7d

# Payment
STRIPE_SECRET_KEY=sk_live_your_stripe_key
STRIPE_WEBHOOK_SECRET=whsec_live_webhook_secret

# Maps
GOOGLE_MAPS_API_KEY=your_production_google_maps_key

# Email
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password

# Admin
ADMIN_EMAIL=admin@fleetflex.app
ADMIN_PASSWORD=secure_admin_password
```

### 10. Docker Deployment

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

RUN npm run build

EXPOSE 5000

CMD ["npm", "start"]
```

```yaml
# docker-compose.yml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
    depends_on:
      - mongodb
      - redis

  mongodb:
    image: mongo:5
    ports:
      - "27017:27017"
    environment:
      - MONGO_INITDB_ROOT_USERNAME=admin
      - MONGO_INITDB_ROOT_PASSWORD=password

  redis:
    image: redis:6-alpine
    ports:
      - "6379:6379"

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
```

### 11. Monitoring & Alerts

```bash
# Install monitoring
npm install -g pm2-server-monit

# Setup alerts
pm2 set pm2-server-monit:email alerts@fleetflex.app
pm2 set pm2-server-monit:slack webhook_url
```

### 12. Backup Strategy

```bash
# Database backup
mongodump --host localhost:27017 --db fleetflex --out /backup/

# Files backup
tar -czf /backup/files-$(date +%Y%m%d).tar.gz /var/www/fleetflex/uploads/

# Automated backup script
0 2 * * * /var/www/fleetflex/scripts/backup.sh
```

### 13. Performance Optimization

```bash
# Enable gzip
sudo nano /etc/nginx/nginx.conf
# Add: gzip on; gzip_types *;

# CDN setup
# CloudFlare configuration
# Static assets caching

# Database optimization
# MongoDB indexing
# Redis caching strategy
```

### 14. Security Checklist

- [ ] SSL/TLS certificates
- [ ] Firewall configuration (ufw)
- [ ] Rate limiting
- [ ] Input validation
- [ ] SQL injection prevention
- [ ] XSS protection
- [ ] CSRF tokens
- [ ] File upload restrictions
- [ ] Regular security updates
- [ ] Log monitoring

### 15. Scaling Strategy

```bash
# Load balancer setup
# Horizontal scaling with PM2 cluster mode
# Database sharding
# CDN integration
# Microservices architecture
```

### 16. Health Checks

```bash
# Create health check endpoint
# Monitor with external services
# Setup alerts and notifications
```

This deployment guide provides a complete production-ready setup for the FleetFlex platform.