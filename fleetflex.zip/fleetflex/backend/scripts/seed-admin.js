const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// Connect to database
mongoose.connect('mongodb://localhost:27017/fleetflex', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const seedAdmin = async () => {
  try {
    // Check if admin exists
    let admin = await User.findOne({ email: 'admin@fleetflex.app' });
    
    if (!admin) {
      // Create admin user
      admin = new User({
        email: 'admin@fleetflex.app',
        password: 'Bigship247$$',
        firstName: 'Administrator',
        lastName: 'FleetFlex',
        phone: '+1-555-ADMIN',
        roles: ['admin', 'customer'],
        isActive: true,
        isVerified: true
      });
      
      await admin.save();
      console.log('✅ Admin user created successfully!');
      console.log('Email: admin@fleetflex.app');
      console.log('Password: Bigship247$$');
    } else {
      console.log('✅ Admin user already exists');
    }
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding admin:', error);
    process.exit(1);
  }
};

seedAdmin();