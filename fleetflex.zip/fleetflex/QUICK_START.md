# FleetFlex Quick Start Guide

## 🚀 One-Line Installation

### **SSH Installation (Complete Setup):**
```bash
# Download and install everything in one command:
curl -fsSL https://raw.githubusercontent.com/yourusername/fleetflex/main/install.sh | bash

# Or if you have the zip file:
chmod +x install.sh && ./install.sh
```

### **GitHub Upload (One Command):**
```bash
# Upload to your GitHub repository:
./scripts/upload-to-github.sh https://github.com/yourusername/fleetflex.git
```

### **Direct Download & Install:**
```bash
# Complete installation via SSH:
wget -O fleetflex.zip https://yourdomain.com/fleetflex.zip
unzip fleetflex.zip
cd fleetflex-platform
./install.sh
```

## 📱 **Access Methods:**

### **Web App (Immediate):**
- **URL:** http://localhost:5173
- **Admin Login:** admin@fleetflex.app / Bigship247$$
- **Mobile Responsive:** ✅ Works on all devices

### **SSH Installation Steps:**
1. **Upload to server:** `scp -r fleetflex-platform user@server:/var/www/`
2. **SSH to server:** `ssh user@your-server`
3. **Run install:** `./install.sh`
4. **Access:** http://your-domain.com

## 🎯 **Mobile Solutions:**

### **Immediate Mobile Access:**
- **Web App:** Fully mobile-responsive
- **PWA:** Install as app from browser
- **Cross-platform:** Works on iOS/Android browsers

### **Mobile App Development:**
- **React Native foundation** provided
- **Code structure** ready
- **API endpoints** ready for mobile integration

## 🔗 **Complete Platform:**
- **Backend:** Node.js + Express.js + MongoDB
- **Frontend:** React.js + Tailwind CSS
- **Admin Dashboard:** Complete with login
- **All 5 Services:** Food, Rides, Shipping, Moving, Freight
- **Production Ready:** ✅ Scalable and secure

**Your complete multi-service logistics platform is ready for production deployment!**