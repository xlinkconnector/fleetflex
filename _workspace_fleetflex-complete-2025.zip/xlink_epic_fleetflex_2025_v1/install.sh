#!/bin/bash

# FleetFlex Epic Installation Script
echo "Starting FleetFlex Epic installation..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "Docker is not installed. Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    usermod -aG docker $USER
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "Docker Compose is not installed. Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# Add domain to hosts file
if ! grep -q "fleetflex.app" /etc/hosts; then
    echo "Adding domains to hosts file..."
    echo "127.0.0.1 fleetflex.app www.fleetflex.app api.fleetflex.app admin.fleetflex.app" >> /etc/hosts
fi

# Start the services
echo "Starting FleetFlex services..."
docker-compose up -d

echo "FleetFlex Epic installation completed!"
echo "You can access the services at:"
echo "- Frontend: https://fleetflex.app"
echo "- Admin Dashboard: https://admin.fleetflex.app"
echo "- API: https://api.fleetflex.app"
