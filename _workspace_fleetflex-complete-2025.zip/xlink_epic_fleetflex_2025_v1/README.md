# 🚀 Epic FleetFlex Platform

FleetFlex is a comprehensive multi-service logistics platform that provides food delivery, rideshare, shipping, moving, and freight services all in one unified ecosystem.

## ✨ Features

- **🍔 Food Delivery**: Order from restaurants with real-time tracking
- **🚗 Rideshare**: Book rides with professional drivers
- **📦 Shipping**: Send packages with insurance and tracking
- **🏠 Moving Services**: Professional moving with full-service options
- **🚚 Freight**: Heavy-duty cargo and freight shipping

## 🏗️ Architecture

FleetFlex is built with a modern microservices architecture:

- **Backend**: Node.js with Express.js, MongoDB, Redis
- **Frontend**: React 18 with Redux Toolkit, Material UI
- **Admin Dashboard**: React with Material UI, Recharts
- **DevOps**: Docker, Nginx, SSL

## 🚀 Getting Started

### Prerequisites

- Docker and Docker Compose
- Node.js 18+ (for development)

### Installation

1. Run the installation script:
   ```bash
   chmod +x install.sh
   ./install.sh
   ```

2. Access the applications:
   - Frontend: https://fleetflex.app
   - Admin Dashboard: https://admin.fleetflex.app
   - API: https://api.fleetflex.app

## 🧪 Development

### Backend Development

```bash
cd backend
npm install
npm run dev
```

### Frontend Development

```bash
cd frontend
npm install
npm start
```

### Admin Dashboard Development

```bash
cd admin
npm install
npm start
```

## 🔒 Security

FleetFlex implements multiple security measures:

- JWT authentication with refresh tokens
- HTTPS with SSL/TLS
- Rate limiting
- Security headers
- Input validation and sanitization
- CORS protection

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgements

- Built with modern web technologies
- Inspired by leading logistics platforms
- Special thanks to all contributors
