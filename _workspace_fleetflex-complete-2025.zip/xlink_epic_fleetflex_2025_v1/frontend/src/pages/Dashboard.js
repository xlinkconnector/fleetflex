import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';

const Dashboard = () => {
  const [stats, setStats] = useState({
    orders: 0,
    vehicles: 0,
    drivers: 0,
    revenue: 0
  });
  
  const { user } = useSelector((state) => state.auth);
  
  useEffect(() => {
    // Fetch dashboard stats
    const fetchStats = async () => {
      try {
        // In a real app, this would be an API call
        // For demo purposes, we'll use mock data
        setStats({
          orders: 156,
          vehicles: 42,
          drivers: 38,
          revenue: 24680
        });
      } catch (error) {
        console.error('Error fetching stats:', error);
      }
    };
    
    fetchStats();
  }, []);
  
  return (
    <div className="page-transition">
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Welcome, {user?.name || 'User'}!</h2>
        <p className="text-gray-600">Here's an overview of your logistics operations.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-700">Total Orders</h3>
          <p className="text-3xl font-bold text-blue-600">{stats.orders}</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-700">Active Vehicles</h3>
          <p className="text-3xl font-bold text-green-600">{stats.vehicles}</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-700">Drivers</h3>
          <p className="text-3xl font-bold text-purple-600">{stats.drivers}</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-700">Revenue</h3>
          <p className="text-3xl font-bold text-yellow-600">${stats.revenue.toLocaleString()}</p>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <h3 className="text-xl font-semibold mb-4">Recent Orders</h3>
        <table className="min-w-full">
          <thead>
            <tr>
              <th className="py-2 px-4 border-b text-left">Order ID</th>
              <th className="py-2 px-4 border-b text-left">Customer</th>
              <th className="py-2 px-4 border-b text-left">Status</th>
              <th className="py-2 px-4 border-b text-left">Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="py-2 px-4 border-b">#ORD-12345</td>
              <td className="py-2 px-4 border-b">John Doe</td>
              <td className="py-2 px-4 border-b"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Delivered</span></td>
              <td className="py-2 px-4 border-b">$156.00</td>
            </tr>
            <tr>
              <td className="py-2 px-4 border-b">#ORD-12344</td>
              <td className="py-2 px-4 border-b">Jane Smith</td>
              <td className="py-2 px-4 border-b"><span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">In Transit</span></td>
              <td className="py-2 px-4 border-b">$89.50</td>
            </tr>
            <tr>
              <td className="py-2 px-4 border-b">#ORD-12343</td>
              <td className="py-2 px-4 border-b">Robert Johnson</td>
              <td className="py-2 px-4 border-b"><span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Processing</span></td>
              <td className="py-2 px-4 border-b">$245.75</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
