import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { logout } from '../store/slices/authSlice';

const Sidebar = () => {
  const location = useLocation();
  const dispatch = useDispatch();

  const handleLogout = () => {
    dispatch(logout());
  };

  const isActive = (path) => {
    return location.pathname === path ? 'active' : '';
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <h3>FleetFlex</h3>
      </div>
      <nav className="sidebar-nav">
        <ul>
          <li className={isActive('/')}>
            <Link to="/">Dashboard</Link>
          </li>
          <li className={isActive('/orders')}>
            <Link to="/orders">Orders</Link>
          </li>
          <li className={isActive('/vehicles')}>
            <Link to="/vehicles">Vehicles</Link>
          </li>
          <li className={isActive('/drivers')}>
            <Link to="/drivers">Drivers</Link>
          </li>
          <li className={isActive('/settings')}>
            <Link to="/settings">Settings</Link>
          </li>
          <li>
            <button onClick={handleLogout} className="logout-btn">
              Logout
            </button>
          </li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;