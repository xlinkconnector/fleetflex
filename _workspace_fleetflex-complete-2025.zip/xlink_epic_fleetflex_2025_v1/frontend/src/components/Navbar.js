import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const { user } = useSelector((state) => state.auth);

  return (
    <header className="navbar">
      <div className="navbar-brand">
        <Link to="/">
          <img src="/logo.png" alt="FleetFlex Logo" className="logo" />
        </Link>
      </div>
      <div className="navbar-menu">
        <div className="search-bar">
          <input type="text" placeholder="Search..." />
          <button type="button">
            <i className="fas fa-search"></i>
          </button>
        </div>
        <div className="navbar-end">
          <div className="notifications">
            <i className="fas fa-bell"></i>
            <span className="badge">3</span>
          </div>
          <div className="user-profile">
            <img 
              src={user?.avatar || "https://via.placeholder.com/40"} 
              alt="User" 
              className="avatar" 
            />
            <span>{user?.name || 'User'}</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;