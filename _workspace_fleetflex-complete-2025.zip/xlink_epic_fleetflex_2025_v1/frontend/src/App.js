import React, { useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { io } from 'socket.io-client';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import NotFound from './pages/NotFound';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import { checkAuth } from './store/slices/authSlice';
import './App.css';

const App = () => {
  const dispatch = useDispatch();
  
  useEffect(() => {
    // Check authentication status
    dispatch(checkAuth());
    
    // Connect to Socket.IO
    const socket = io('http://localhost:5000');
    
    socket.on('connect', () => {
      console.log('Connected to Socket.IO server');
    });
    
    socket.on('disconnect', () => {
      console.log('Disconnected from Socket.IO server');
    });
    
    return () => {
      socket.disconnect();
    };
  }, [dispatch]);
  
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route index element={<Dashboard />} />
        <Route path="orders" element={<div>Orders Page</div>} />
        <Route path="vehicles" element={<div>Vehicles Page</div>} />
        <Route path="drivers" element={<div>Drivers Page</div>} />
        <Route path="settings" element={<div>Settings Page</div>} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default App;
