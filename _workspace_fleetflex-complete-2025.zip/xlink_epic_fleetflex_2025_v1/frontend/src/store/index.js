import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import ordersReducer from './slices/ordersSlice';
import vehiclesReducer from './slices/vehiclesSlice';
import driversReducer from './slices/driversSlice';

const store = configureStore({
  reducer: {
    auth: authReducer,
    orders: ordersReducer,
    vehicles: vehiclesReducer,
    drivers: driversReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false
    })
});

export default store;
