import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Async thunks
export const fetchDrivers = createAsyncThunk(
  'drivers/fetchDrivers',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get('/api/users?role=driver');
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const createDriver = createAsyncThunk(
  'drivers/createDriver',
  async (driverData, { rejectWithValue }) => {
    try {
      const response = await axios.post('/api/users', { ...driverData, role: 'driver' });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateDriver = createAsyncThunk(
  'drivers/updateDriver',
  async ({ id, driverData }, { rejectWithValue }) => {
    try {
      const response = await axios.put(`/api/users/${id}`, driverData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const deleteDriver = createAsyncThunk(
  'drivers/deleteDriver',
  async (id, { rejectWithValue }) => {
    try {
      await axios.delete(`/api/users/${id}`);
      return id;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Initial state
const initialState = {
  drivers: [],
  loading: false,
  error: null,
  currentDriver: null
};

// Slice
const driversSlice = createSlice({
  name: 'drivers',
  initialState,
  reducers: {
    setCurrentDriver: (state, action) => {
      state.currentDriver = action.payload;
    },
    clearCurrentDriver: (state) => {
      state.currentDriver = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch drivers
      .addCase(fetchDrivers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDrivers.fulfilled, (state, action) => {
        state.loading = false;
        state.drivers = action.payload;
      })
      .addCase(fetchDrivers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || 'Failed to fetch drivers';
      })
      
      // Create driver
      .addCase(createDriver.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createDriver.fulfilled, (state, action) => {
        state.loading = false;
        state.drivers.push(action.payload);
      })
      .addCase(createDriver.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || 'Failed to create driver';
      })
      
      // Update driver
      .addCase(updateDriver.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateDriver.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.drivers.findIndex(driver => driver._id === action.payload._id);
        if (index !== -1) {
          state.drivers[index] = action.payload;
        }
      })
      .addCase(updateDriver.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || 'Failed to update driver';
      })
      
      // Delete driver
      .addCase(deleteDriver.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteDriver.fulfilled, (state, action) => {
        state.loading = false;
        state.drivers = state.drivers.filter(driver => driver._id !== action.payload);
      })
      .addCase(deleteDriver.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || 'Failed to delete driver';
      });
  }
});

export const { setCurrentDriver, clearCurrentDriver } = driversSlice.actions;

export default driversSlice.reducer;