import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import foodReducer from './slices/foodSlice';
import rideReducer from './slices/rideSlice';
import shippingReducer from './slices/shippingSlice';
import movingReducer from './slices/movingSlice';
import freightReducer from './slices/freightSlice';
import adminReducer from './slices/adminSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    food: foodReducer,
    ride: rideReducer,
    shipping: shippingReducer,
    moving: movingReducer,
    freight: freightReducer,
    admin: adminReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ['persist/PERSIST'],
      },
    }),
});