import React, { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Header from './common/Header';
import ServiceTabs from './common/ServiceTabs';
import Footer from './common/Footer';

const Layout = () => {
  const { isAuthenticated } = useSelector(state => state.auth);
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {isAuthenticated && location.pathname !== '/login' && location.pathname !== '/register' && (
        <ServiceTabs />
      )}
      
      <main className="container mx-auto px-4 py-8">
        <Outlet />
      </main>
      
      <Footer />
    </div>
  );
};

export default Layout;