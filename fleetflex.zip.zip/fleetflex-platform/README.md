# FleetFlex - Multi-Service Logistics Platform

A comprehensive, enterprise-grade logistics platform that unifies food delivery, rideshare, package shipping, moving services, and freight transport into a single ecosystem.

## 🏗️ Architecture Overview

### Backend Architecture
- **Server**: Node.js + Express.js
- **Database**: MongoDB + Redis (caching)
- **Authentication**: JWT tokens with role-based access
- **Real-time**: Socket.io for live tracking
- **Payment**: Stripe integration
- **File Storage**: GridFS for documents/images

### Frontend Architecture
- **Web Platform**: React.js + Redux Toolkit
- **Mobile Apps**: React Native (planned)
- **Styling**: Tailwind CSS
- **Maps**: Google Maps API
- **Real-time**: Socket.io-client

### Service Modules
1. **🍕 Food Delivery** - Restaurant marketplace
2. **🚗 Rideshare** - Passenger transportation
3. **📦 Package Shipping** - On-demand delivery
4. **🏠 Moving Services** - Professional relocation services
5. **🚛 Freight Transport** - Heavy cargo marketplace

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- MongoDB 5+
- Redis
- Stripe account
- Google Maps API key

### Installation

1. **Clone and Setup**
```bash
git clone <repository-url>
cd fleetflex-platform
./scripts/setup.sh
```

2. **Configure Environment**
```bash
cd backend
cp .env.example .env
# Edit .env with your actual configuration
```

3. **Install Dependencies**
```bash
npm run install:all
```

4. **Start Development**
```bash
npm run dev
```

### Environment Variables (.env)

```bash
# Server Configuration
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/fleetflex
REDIS_URL=redis://localhost:6379

# Authentication
JWT_SECRET=your-super-secret-jwt-key

# Payment
STRIPE_SECRET_KEY=sk_test_your_stripe_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret

# Maps & Services
GOOGLE_MAPS_API_KEY=your_google_maps_api_key

# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
```

## 📊 Database Schema

### Core Collections
- **Users**: Customer accounts with roles
- **ServiceProviders**: Restaurant, driver, mover, carrier profiles
- **Orders/Jobs**: Service-specific order/job records
- **Tracking**: Real-time location updates
- **Payments**: Transaction records

### Service-Specific Collections
- **Restaurants**: Food delivery restaurant profiles
- **MenuItems**: Restaurant menu items
- **FoodOrders**: Food delivery orders
- **RideRequests**: Rideshare ride requests
- **Vehicles**: Driver vehicle information
- **ShippingOrders**: Package shipping orders
- **MovingJobs**: Moving service jobs
- **FreightJobs**: Freight transport jobs
- **FreightVehicles**: Carrier vehicle information

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update user profile

### Service Endpoints
- **Food**: `/api/food/*`
- **Rides**: `/api/rides/*`
- **Shipping**: `/api/shipping/*`
- **Moving**: `/api/moving/*`
- **Freight**: `/api/freight/*`

### Admin Endpoints
- `GET /api/admin/dashboard/stats` - Dashboard statistics
- `GET /api/admin/users` - User management
- `GET /api/admin/service-providers` - Provider management
- `PUT /api/admin/service-providers/:id/approve` - Approve providers

## 🎯 Usage Guide

### Customer Flow
1. Register/Login
2. Select service type
3. Request service
4. Track in real-time
5. Rate and review

### Provider Flow
1. Register as service provider
2. Complete verification process
3. Receive service requests
4. Accept and complete jobs
5. Get paid automatically

### Admin Flow
1. Access admin dashboard
2. Manage users and providers
3. Monitor all services
4. Handle disputes and refunds
5. View analytics and reports

## 🔧 Development

### Project Structure
```
fleetflex-platform/
├── backend/
│   ├── controllers/    # Request handlers
│   ├── models/        # Database schemas
│   ├── routes/        # API routes
│   ├── middleware/    # Authentication & validation
│   ├── services/      # Business logic
│   └── config/        # Configuration files
├── frontend/
│   ├── src/
│   │   ├── components/ # Reusable components
│   │   ├── pages/     # Page components
│   │   ├── slices/    # Redux state management
│   │   └── services/  # API service layer
├── mobile/            # React Native app (planned)
└── docs/             # Documentation
```

### Development Commands
```bash
# Start all services
npm run dev

# Start individual services
npm run dev:backend    # Backend only
npm run dev:frontend   # Frontend only

# Build for production
npm run build

# Run tests
npm test

# Seed database
npm run seed
```

## 🔐 Security Features
- JWT token authentication
- Role-based access control
- Input validation and sanitization
- Rate limiting
- HTTPS encryption
- Secure file uploads
- Background checks for providers

## 📈 Performance Features
- Redis caching
- Database indexing
- Image optimization
- CDN integration
- Lazy loading
- Real-time updates
- Mobile responsive

## 🛡️ Monitoring & Logging
- Winston logging
- Error tracking
- Performance monitoring
- User activity logs
- Payment transaction logs
- Real-time alerts

## 📱 Mobile Features (Planned)
- React Native app
- Push notifications
- Offline capability
- GPS tracking
- Camera integration
- Biometric authentication

## 🤝 Contributing
1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📄 License
MIT License - see LICENSE file for details

## 📞 Support
- Email: support@fleetflex.app
- Documentation: docs.fleetflex.app
- API Reference: api.fleetflex.app/docs