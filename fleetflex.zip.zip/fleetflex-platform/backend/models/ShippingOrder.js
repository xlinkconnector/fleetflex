const mongoose = require('mongoose');

const shippingOrderSchema = new mongoose.Schema({
  trackingNumber: {
    type: String,
    required: true,
    unique: true
  },
  senderId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  recipientInfo: {
    name: {
      type: String,
      required: true
    },
    phone: {
      type: String,
      required: true
    },
    email: {
      type: String,
      required: true
    }
  },
  driverId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  packageInfo: {
    description: {
      type: String,
      required: true
    },
    weight: {
      type: Number,
      required: true
    },
    dimensions: {
      length: {
        type: Number,
        required: true
      },
      width: {
        type: Number,
        required: true
      },
      height: {
        type: Number,
        required: true
      }
    },
    value: {
      type: Number,
      default: 0
    },
    fragile: {
      type: Boolean,
      default: false
    },
    requiresSignature: {
      type: Boolean,
      default: false
    }
  },
  pickup: {
    address: {
      type: String,
      required: true
    },
    lat: {
      type: Number,
      required: true
    },
    lng: {
      type: Number,
      required: true
    },
    instructions: String,
    timeWindow: {
      start: {
        type: Date,
        required: true
      },
      end: {
        type: Date,
        required: true
      }
    }
  },
  delivery: {
    address: {
      type: String,
      required: true
    },
    lat: {
      type: Number,
      required: true
    },
    lng: {
      type: Number,
      required: true
    },
    instructions: String,
    timeWindow: {
      start: {
        type: Date,
        required: true
      },
      end: {
        type: Date,
        required: true
      }
    }
  },
  serviceType: {
    type: String,
    enum: ['same-day', 'next-day', 'standard', 'express'],
    required: true
  },
  pricing: {
    baseFee: {
      type: Number,
      required: true
    },
    weightFee: {
      type: Number,
      required: true
    },
    distanceFee: {
      type: Number,
      required: true
    },
    serviceFee: {
      type: Number,
      required: true
    },
    insurance: {
      type: Number,
      default: 0
    },
    total: {
      type: Number,
      required: true
    }
  },
  status: {
    type: String,
    enum: ['created', 'pickup-scheduled', 'picked-up', 'in-transit', 'delivered', 'failed-delivery'],
    default: 'created'
  },
  timeline: [{
    status: {
      type: String,
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    location: {
      lat: Number,
      lng: Number
    },
    notes: String,
    signature: String
  }],
  payment: {
    method: {
      type: String,
      enum: ['card', 'cash', 'wallet'],
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'pending'
    },
    transactionId: String,
    stripePaymentIntentId: String
  },
  rating: {
    sender: {
      rating: Number,
      review: String
    },
    driver: {
      rating: Number,
      review: String
    }
}, {
  timestamps: true
});

// Generate tracking number before saving
shippingOrderSchema.pre('save', function(next) {
  if (this.isNew) {
    this.trackingNumber = 'SH' + Date.now().toString().slice(-8) + Math.random().toString(36).substr(2, 4).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('ShippingOrder', shippingOrderSchema);