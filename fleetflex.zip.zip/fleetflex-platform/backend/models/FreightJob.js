const mongoose = require('mongoose');

const freightJobSchema = new mongoose.Schema({
  jobNumber: {
    type: String,
    required: true,
    unique: true
  },
  shipperId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  carrierId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  freightType: {
    type: String,
    enum: ['full-truckload', 'less-than-truckload', 'expedited', 'temperature-controlled'],
    required: true
  },
  cargo: {
    description: {
      type: String,
      required: true
    },
    weight: {
      type: Number,
      required: true
    },
    dimensions: {
      length: {
        type: Number,
        required: true
      },
      width: {
        type: Number,
        required: true
      },
      height: {
        type: Number,
        required: true
      }
    },
    value: {
      type: Number,
      default: 0
    },
    hazardous: {
      type: Boolean,
      default: false
    },
    temperatureControlled: {
      type: Boolean,
      default: false
    },
    fragile: {
      type: Boolean,
      default: false
    }
  },
  pickup: {
    company: {
      type: String,
      required: true
    },
    address: {
      type: String,
      required: true
    },
    lat: {
      type: Number,
      required: true
    },
    lng: {
      type: Number,
      required: true
    },
    contact: {
      name: {
        type: String,
        required: true
      },
      phone: {
        type: String,
        required: true
      },
      email: {
        type: String,
        required: true
      }
    },
    timeWindow: {
      start: {
        type: Date,
        required: true
      },
      end: {
        type: Date,
        required: true
      }
    },
    dockType: {
      type: String,
      enum: ['dock-high', 'ground-level', 'no-dock'],
      required: true
    },
    loadingEquipment: [{
      type: String
    }]
  },
  delivery: {
    company: {
      type: String,
      required: true
    },
    address: {
      type: String,
      required: true
    },
    lat: {
      type: Number,
      required: true
    },
    lng: {
      type: Number,
      required: true
    },
    contact: {
      name: {
        type: String,
        required: true
      },
      phone: {
        type: String,
        required: true
      },
      email: {
        type: String,
        required: true
      }
    },
    timeWindow: {
      start: {
        type: Date,
        required: true
      },
      end: {
        type: Date,
        required: true
      }
    },
    dockType: {
      type: String,
      enum: ['dock-high', 'ground-level', 'no-dock'],
      required: true
    },
    unloadingEquipment: [{
      type: String
    }]
  },
  distance: {
    type: Number,
    required: true
  },
  estimatedTransitTime: {
    type: Number,
    required: true
  },
  pricing: {
    baseRate: {
      type: Number,
      required: true
    },
    mileageRate: {
      type: Number,
      required: true
    },
    fuelSurcharge: {
      type: Number,
      default: 0
    },
    accessorialCharges: {
      type: Number,
      default: 0
    },
    insurance: {
      type: Number,
      default: 0
    },
    total: {
      type: Number,
      required: true
    }
  },
  status: {
    type: String,
    enum: ['posted', 'bid', 'booked', 'in-transit', 'delivered', 'cancelled'],
    default: 'posted'
  },
  bids: [{
    carrierId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    amount: {
      type: Number,
      required: true
    },
    estimatedPickup: {
      type: Date,
      required: true
    },
    estimatedDelivery: {
      type: Date,
      required: true
    },
    equipment: {
      type: String,
      required: true
    },
    message: String,
    bidDate: {
      type: Date,
      default: Date.now
    }
  }],
  tracking: [{
    location: {
      lat: Number,
      lng: Number
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      required: true
    },
    notes: String
  }],
  documents: [{
    type: {
      type: String,
      enum: ['bill-of-lading', 'proof-of-delivery', 'invoice', 'insurance', 'permit']
    },
    url: {
      type: String,
      required: true
    },
    uploadedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    uploadDate: {
      type: Date,
      default: Date.now
    }
  }],
  payment: {
    method: {
      type: String,
      enum: ['card', 'cash', 'wallet'],
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'pending'
    },
    transactionId: String,
    stripePaymentIntentId: String
  },
  rating: {
    shipper: {
      rating: Number,
      review: String
    },
    carrier: {
      rating: Number,
      review: String
    }
}, {
  timestamps: true
});

// Generate job number before saving
freightJobSchema.pre('save', function(next) {
  if (this.isNew) {
    this.jobNumber = 'FR' + Date.now().toString().slice(-8) + Math.random().toString(36).substr(2, 4).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('FreightJob', freightJobSchema);