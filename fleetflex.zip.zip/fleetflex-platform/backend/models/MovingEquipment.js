const mongoose = require('mongoose');

const movingEquipmentSchema = new mongoose.Schema({
  moverProviderId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ServiceProvider',
    required: true
  },
  equipmentType: {
    type: String,
    enum: ['truck', 'dolly', 'straps', 'blankets', 'boxes', 'tools'],
    required: true
  },
  specifications: {
    size: String,
    capacity: String,
    features: [String]
  },
  availability: [{
    date: {
      type: Date,
      required: true
    },
    available: {
      type: Boolean,
      default: true
    },
    hourlyRate: {
      type: Number,
      required: true
    }
  }],
  condition: {
    type: String,
    enum: ['excellent', 'good', 'fair'],
    default: 'good'
  },
  lastMaintenance: {
    type: Date,
    default: Date.now
  },
  nextMaintenance: {
    type: Date
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('MovingEquipment', movingEquipmentSchema);