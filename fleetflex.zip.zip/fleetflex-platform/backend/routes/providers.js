const express = require('express');
const ServiceProvider = require('../models/ServiceProvider');
const { auth } = require('../middleware/auth');
const router = express.Router();

// Register as service provider
router.post('/register', auth, async (req, res) => {
  try {
    const {
      serviceType,
      businessName,
      businessType,
      licenseNumber,
      insuranceInfo,
      serviceAreas
    } = req.body;

    // Check if already registered as provider
    const existingProvider = await ServiceProvider.findOne({ userId: req.user._id });
    if (existingProvider) {
      return res.status(400).json({ message: 'Already registered as service provider' });
    }

    const provider = new ServiceProvider({
      userId: req.user._id,
      serviceType,
      businessName,
      businessType,
      licenseNumber,
      insuranceInfo,
      serviceAreas
    });

    await provider.save();

    // Update user roles
    const User = require('../models/User');
    await User.findByIdAndUpdate(
      req.user._id,
      { $addToSet: { roles: serviceType } }
    );

    res.status(201).json({
      success: true,
      data: provider
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get service provider profile
router.get('/profile', auth, async (req, res) => {
  try {
    const provider = await ServiceProvider.findOne({ userId: req.user._id });
    
    if (!provider) {
      return res.status(404).json({ message: 'Service provider not found' });
    }

    res.json({
      success: true,
      data: provider
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update service provider profile
router.put('/profile', auth, async (req, res) => {
  try {
    const provider = await ServiceProvider.findOneAndUpdate(
      { userId: req.user._id },
      req.body,
      { new: true, runValidators: true }
    );

    if (!provider) {
      return res.status(404).json({ message: 'Service provider not found' });
    }

    res.json({
      success: true,
      data: provider
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Upload documents
router.post('/documents', auth, async (req, res) => {
  try {
    // In a real app, handle file upload here
    // For now, just update the document metadata
    
    const { type, url } = req.body;

    const provider = await ServiceProvider.findOneAndUpdate(
      { userId: req.user._id },
      { 
        $push: { 
          documents: { type, url, verified: false }
        }
      },
      { new: true }
    );

    res.json({
      success: true,
      data: provider
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get verification status
router.get('/verification-status', auth, async (req, res) => {
  try {
    const provider = await ServiceProvider.findOne({ userId: req.user._id });
    
    if (!provider) {
      return res.status(404).json({ message: 'Service provider not found' });
    }

    res.json({
      success: true,
      data: {
        isApproved: provider.isApproved,
        documents: provider.documents,
        rating: provider.rating,
        totalJobs: provider.totalJobs
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;