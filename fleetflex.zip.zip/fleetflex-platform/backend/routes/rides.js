const express = require('express');
const RideRequest = require('../models/RideRequest');
const Vehicle = require('../models/Vehicle');
const User = require('../models/User');
const { auth, authorize } = require('../middleware/auth');
const router = express.Router();

// Create ride request
router.post('/request', auth, async (req, res) => {
  try {
    const {
      rideType,
      pickup,
      destination,
      payment,
      scheduledTime
    } = req.body;

    // Calculate distance and duration (in a real app, use Google Maps API)
    const distance = calculateDistance(
      pickup.lat, pickup.lng,
      destination.lat, destination.lng
    );
    const duration = Math.round(distance * 3); // Approximate minutes

    // Calculate pricing based on ride type
    const pricing = calculatePricing(rideType, distance, duration);

    const rideRequest = new RideRequest({
      passengerId: req.user._id,
      rideType,
      pickup,
      destination,
      estimatedDistance: distance,
      estimatedDuration: duration,
      pricing,
      payment: {
        method: payment.method,
        status: 'pending'
      },
      scheduledTime: scheduledTime || new Date(),
      status: 'requested'
    });

    await rideRequest.save();

    res.status(201).json({
      success: true,
      data: rideRequest
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get ride estimate
router.get('/estimate', async (req, res) => {
  try {
    const { pickupLat, pickupLng, destinationLat, destinationLng, rideType } = req.query;

    if (!pickupLat || !pickupLng || !destinationLat || !destinationLng || !rideType) {
      return res.status(400).json({ message: 'Missing required parameters' });
    }

    const distance = calculateDistance(
      parseFloat(pickupLat), parseFloat(pickupLng),
      parseFloat(destinationLat), parseFloat(destinationLng)
    );
    const duration = Math.round(distance * 3);

    const pricing = calculatePricing(rideType, distance, duration);

    res.json({
      success: true,
      data: {
        distance,
        duration,
        pricing
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user's ride history
router.get('/history', auth, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    
    let query = { passengerId: req.user._id };
    if (status) {
      query.status = status;
    }
    
    const rides = await RideRequest.find(query)
      .populate('driverId', 'firstName lastName phone')
      .populate('passengerId', 'firstName lastName phone')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);
    
    const total = await RideRequest.countDocuments(query);
    
    res.json({
      success: true,
      count: rides.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: rides
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get ride by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const ride = await RideRequest.findById(req.params.id)
      .populate('driverId', 'firstName lastName phone')
      .populate('passengerId', 'firstName lastName phone');
    
    if (!ride) {
      return res.status(404).json({ message: 'Ride not found' });
    }
    
    // Check if user owns this ride or is the driver
    const canView = ride.passengerId._id.toString() === req.user._id.toString() ||
                   ride.driverId?._id.toString() === req.user._id.toString();
    
    if (!canView) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    res.json({
      success: true,
      data: ride
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Cancel ride
router.put('/:id/cancel', auth, async (req, res) => {
  try {
    const ride = await RideRequest.findById(req.params.id);
    
    if (!ride) {
      return res.status(404).json({ message: 'Ride not found' });
    }
    
    // Check permissions
    const isPassenger = ride.passengerId.toString() === req.user._id.toString();
    const isDriver = ride.driverId?.toString() === req.user._id.toString();
    
    if (!isPassenger && !isDriver) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    // Check if ride can be cancelled
    if (['completed', 'cancelled'].includes(ride.status)) {
      return res.status(400).json({ message: 'Ride cannot be cancelled' });
    }
    
    ride.status = 'cancelled';
    await ride.save();
    
    res.json({
      success: true,
      data: ride
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Driver routes
// Get available ride requests
router.get('/driver/requests', auth, authorize('driver'), async (req, res) => {
  try {
    const { lat, lng, radius = 10 } = req.query;
    
    let query = { status: 'requested' };
    
    const requests = await RideRequest.find(query)
      .populate('passengerId', 'firstName lastName phone')
      .sort({ createdAt: 1 });
    
    // Filter by distance if location provided
    let filteredRequests = requests;
    if (lat && lng) {
      const driverLat = parseFloat(lat);
      const driverLng = parseFloat(lng);
      const radiusKm = parseFloat(radius);
      
      filteredRequests = requests.filter(request => {
        const distance = calculateDistance(
          driverLat, driverLng,
          request.pickup.lat, request.pickup.lng
        );
        return distance <= radiusKm;
      });
    }
    
    res.json({
      success: true,
      count: filteredRequests.length,
      data: filteredRequests
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Accept ride request
router.post('/driver/accept', auth, authorize('driver'), async (req, res) => {
  try {
    const { rideId } = req.body;
    
    const ride = await RideRequest.findById(rideId);
    
    if (!ride) {
      return res.status(404).json({ message: 'Ride not found' });
    }
    
    if (ride.status !== 'requested') {
      return res.status(400).json({ message: 'Ride already accepted' });
    }
    
    ride.driverId = req.user._id;
    ride.status = 'accepted';
    await ride.save();
    
    res.json({
      success: true,
      data: ride
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update driver location
router.put('/driver/location', auth, authorize('driver'), async (req, res) => {
  try {
    const { lat, lng } = req.body;
    
    // Update driver's current location
    // In a real app, this would be stored in Redis or a separate collection
    
    res.json({
      success: true,
      message: 'Location updated'
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update driver status
router.put('/driver/status', auth, authorize('driver'), async (req, res) => {
  try {
    const { status } = req.body;
    
    // Update driver's availability status
    // In a real app, this would be stored in the service provider collection
    
    res.json({
      success: true,
      message: 'Status updated'
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Vehicle management
router.post('/driver/vehicle', auth, authorize('driver'), async (req, res) => {
  try {
    const vehicleData = {
      driverId: req.user._id,
      ...req.body
    };
    
    const vehicle = new Vehicle(vehicleData);
    await vehicle.save();
    
    res.status(201).json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update vehicle
router.put('/driver/vehicle/:id', auth, authorize('driver'), async (req, res) => {
  try {
    const vehicle = await Vehicle.findOneAndUpdate(
      { _id: req.params.id, driverId: req.user._id },
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }
    
    res.json({
      success: true,
      data: vehicle
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Helper functions
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
           Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
           Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function calculatePricing(rideType, distance, duration) {
  const baseRates = {
    standard: 2.50,
    premium: 5.00,
    shared: 1.50,
    xl: 3.50
  };
  
  const distanceRates = {
    standard: 1.50,
    premium: 2.50,
    shared: 1.00,
    xl: 2.00
  };
  
  const timeRates = {
    standard: 0.25,
    premium: 0.50,
    shared: 0.15,
    xl: 0.35
  };
  
  const baseFare = baseRates[rideType];
  const distanceFare = distance * distanceRates[rideType];
  const timeFare = duration * timeRates[rideType];
  
  return {
    baseFare,
    distanceFare,
    timeFare,
    surgePricing: 1,
    tip: 0,
    total: baseFare + distanceFare + timeFare
  };
}

module.exports = router;